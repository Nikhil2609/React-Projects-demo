import * as FlexPlugin from "flex-plugin";
import { CustomerJourneyPlugin } from "./CustomerJourneyPlugin";

FlexPlugin.loadPlugin(CustomerJourneyPlugin);
