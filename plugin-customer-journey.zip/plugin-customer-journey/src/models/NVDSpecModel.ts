export class NVDSpecModel {
  public name: string;

  public desc: string;

  constructor() {
    this.name = "";
    this.desc = "";
  }
}
