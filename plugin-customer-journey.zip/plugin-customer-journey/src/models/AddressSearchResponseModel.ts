export class AddressSearchResponseModel {
  public Address: string;

  public Key: string;

  constructor() {
    this.Address = "";
    this.Key = "";
  }
}
