import { ItemModel } from "@common/components";

export class TimeForPurchaseItemModel extends ItemModel {
  constructor() {
    super();
  }
}
