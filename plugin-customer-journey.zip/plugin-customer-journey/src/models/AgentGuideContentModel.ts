export class AgentGuideContentModel {
  public title: string;

  public content: string;

  public constructor() {
    this.title = "";
    this.content = "";
  }
}
