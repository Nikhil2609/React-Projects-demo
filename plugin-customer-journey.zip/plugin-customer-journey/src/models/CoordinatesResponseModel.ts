export class CoordinatesResponseModel {
  public longitude: number | null;

  public latitude: number | null;

  constructor() {
    this.longitude = null;
    this.latitude = null;
  }
}
