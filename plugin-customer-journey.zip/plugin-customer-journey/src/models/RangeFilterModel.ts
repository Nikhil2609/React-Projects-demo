export class RangeFilterModel {
  public min: number;

  public max: number;

  constructor() {
    this.min = 0;
    this.max = 0;
  }
}
