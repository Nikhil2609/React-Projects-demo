export class ActionTypeModel {
  public id: number;

  public name: string;

  constructor() {
    this.id = -1;
    this.name = "";
  }
}
