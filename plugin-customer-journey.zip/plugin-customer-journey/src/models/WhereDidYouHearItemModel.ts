import { ItemModel } from "@common/components";

export class WhereDidYouHearItemModel extends ItemModel {
  constructor() {
    super();
  }
}
