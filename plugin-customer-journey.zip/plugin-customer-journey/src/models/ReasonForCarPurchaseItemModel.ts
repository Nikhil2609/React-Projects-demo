import { ItemModel } from "@common/components";

export class ReasonForCarPurchaseItemModel extends ItemModel {
  constructor() {
    super();
  }
}
