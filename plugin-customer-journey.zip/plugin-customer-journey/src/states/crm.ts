export interface CrmState {
  phoenixToken: string;
}
