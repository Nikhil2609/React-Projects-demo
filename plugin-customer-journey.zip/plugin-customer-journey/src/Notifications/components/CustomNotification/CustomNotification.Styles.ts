import styled from "react-emotion";

export const CustomNotificationStyles = styled("div")({});
