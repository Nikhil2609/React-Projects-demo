import React from "react";
import { Props } from "../CarDealerInformation";

const CarDealerInformation: React.FC<Props> = (props) => <div />;

export default CarDealerInformation;
