export interface StateToProps {
  canMakeCall: boolean;
}

export interface DispatchToProps {}
