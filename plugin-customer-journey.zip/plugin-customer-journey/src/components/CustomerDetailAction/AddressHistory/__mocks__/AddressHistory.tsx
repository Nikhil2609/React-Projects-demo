import React from "react";
import { AddressHistoryProps } from "../AddressHistory";

const AddressHistory: React.FC<AddressHistoryProps> = (props) => (
  <div className="address-history" />
);

export default AddressHistory;
