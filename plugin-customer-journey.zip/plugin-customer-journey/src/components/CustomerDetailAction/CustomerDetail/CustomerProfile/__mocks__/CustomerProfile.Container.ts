import { CustomerProfile } from "./CustomerProfile";

export default CustomerProfile;
