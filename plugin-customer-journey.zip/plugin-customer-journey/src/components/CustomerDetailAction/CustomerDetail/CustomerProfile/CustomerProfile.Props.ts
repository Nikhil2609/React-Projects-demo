import { CustomerDetailModel } from "@common/components";

export interface StateToProps {
  customer: CustomerDetailModel;
}

export interface DispatchToProps {}
