import { styled } from "@twilio/flex-ui";

export const CustomerDetailWrapperStyles = styled("div")({});
