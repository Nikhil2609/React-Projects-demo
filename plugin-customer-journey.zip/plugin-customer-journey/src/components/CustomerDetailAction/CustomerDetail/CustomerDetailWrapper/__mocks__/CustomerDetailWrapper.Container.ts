import CustomerDetailWrapper from "./CustomerDetailWrapper";

export default CustomerDetailWrapper;
