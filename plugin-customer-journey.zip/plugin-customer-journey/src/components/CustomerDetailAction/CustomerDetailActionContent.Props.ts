export interface StateToProps {
  currentProgressStatus: string;
}

export interface DispatchToProps {}
