import React, { useState } from "react";
import { Manager } from "@twilio/flex-ui";
import { BankDetailModel, BankDetail, Loading } from "@common/components";

import { useApplicationService } from "../../../services/application.service";
import { AppState } from "../../../states";
import { StateToProps, DispatchToProps } from "./BankDetailWrapper.Props";
import { preparePatchData } from "../../../helpers/commonFunctions";
import {
  showMessage,
  showErrorMessage,
  CustomNotificationType,
} from "../../../Notifications/index";
import { UpdateDetailRequestModel } from "../../../models/UpdateDetailRequestModel";

interface BankDetailWrapperProps {
  backToWizardStepper: () => void;
}

export type ComponentProps = StateToProps &
  DispatchToProps &
  BankDetailWrapperProps;

export const BankDetailWrapper: React.FC<ComponentProps> = ({
  applicationId,
  bankDetail,
  setCustomerDetails,
  backToWizardStepper,
}) => {
  const state: AppState = Manager.getInstance().store.getState();
  const applicationService = useApplicationService(
    state.flex.session.ssoTokenPayload.token
  );

  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [isLoading, setIsLoading] = useState(false);
  const propertyList = [
    "bankName",
    "monthsAtBank",
    "nameOnBankAccount",
    "accountNumber",
    "sortCode",
    "netMonthlyIncome",
  ];

  const updateBankDetails = async (bankDetailModel: BankDetailModel) => {
    let hasError = false;
    if (
      bankDetailModel.accountNumber &&
      bankDetailModel.accountNumber.length !== 8
    ) {
      errors.accountNumber = [
        "The account number field must be 8 digits long.",
      ];
      hasError = true;
    }
    if (bankDetailModel.sortCode && bankDetailModel.sortCode.length !== 6) {
      errors.sortCode = ["The sort code field must be valid."];
      hasError = true;
    }
    if (!bankDetailModel.netMonthlyIncome) {
      errors.netMonthlyIncome = ["The Net monthly income field is required."];
      hasError = true;
    }
    setErrors(errors);
    if (!hasError) {
      // prepare patch request data
      const bankInformation = {
        ...bankDetailModel,
        netMonthlyIncome: Number(bankDetailModel.netMonthlyIncome),
        monthsAtBank: Number(bankDetailModel.monthsAtBank),
      };

      const updatedPropertyList = propertyList.filter(
        (property) =>
          JSON.stringify(bankInformation[property as keyof BankDetailModel]) !==
          JSON.stringify(bankDetail[property as keyof BankDetailModel])
      );

      if (!updatedPropertyList.length) {
        // skip api call if detail is not updated
        return;
      }

      // prepare patch request data
      const updateRequestList: UpdateDetailRequestModel[] = [];
      updatedPropertyList.forEach((key) => {
        updateRequestList.push(
          preparePatchData(
            `bankDetails/${key}`,
            bankInformation[key as keyof BankDetailModel]
          )
        );
      });

      try {
        setIsLoading(true);
        await applicationService
          .updateBaseApplicationDetail(applicationId, updateRequestList)
          .then(() => {
            // show success notification
            showMessage(
              CustomNotificationType.SuccessNotification,
              "Customer bank detail updated successfully!"
            );
            // update bank detail in redux
            setCustomerDetails("bankDetails", bankInformation);
            // wait till detail updated in redux
            setTimeout(() => {
              // return to wizard
              backToWizardStepper();
            }, 0);
          });
      } catch (error) {
        setErrors({});
        showErrorMessage(
          "Error in updating bank detail, please try again!",
          "",
          true
        );
      } finally {
        setIsLoading(false);
      }
    }
  };

  return (
    <div>
      {isLoading && <Loading />}
      <BankDetail
        bankDetail={bankDetail}
        errorList={errors}
        updateBankDetails={updateBankDetails}
      />
    </div>
  );
};
