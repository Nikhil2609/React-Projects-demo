import Component from "./DPADialogContent";

export default Component;
