import React from "react";
import { DealerStateSnackbarProps } from "../DealerStateSnackbar.Props";

export const DealerStateSnackbar: React.FC<DealerStateSnackbarProps> = (
  props
) => {
  return <div className="dealer-state-snackbar">DealerStateSnackbar</div>;
};
