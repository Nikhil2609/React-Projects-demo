export interface StateToProps {
  postCode: string;
}

export interface DispatchToProps {}
