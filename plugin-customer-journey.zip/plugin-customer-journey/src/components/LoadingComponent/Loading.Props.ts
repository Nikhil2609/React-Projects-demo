export interface StateToProps {}

export interface DispatchToProps {}

export interface LoadingProps {
  size?: "small" | "medium" | "large";
}
