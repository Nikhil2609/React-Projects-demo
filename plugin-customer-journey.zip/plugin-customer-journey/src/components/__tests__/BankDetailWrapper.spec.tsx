import React from "react";
import { create } from "react-test-renderer";
import flushPromises from "flush-promises";
import { mount } from "enzyme";
import { act } from "react-dom/test-utils";
import { Manager } from "@twilio/flex-ui";
import { showErrorMessage, showMessage } from "../../Notifications";

import { flexManagerMock } from "../__mocks__/MockData";
import {
  BankDetailWrapper,
  ComponentProps,
} from "../CustomerDetailAction/BankDetailWrapper/BankDetailWrapper";

jest.mock("../../services/application.service");

jest.mock("../../Notifications", () => {
  return {
    showErrorMessage: jest.fn(() => {}),
    showMessage: jest.fn(() => {}),
    CustomNotificationType: { SuccessNotification: "successNotification" },
  };
});

const mockUpdateBaseApplicationDetail = jest.fn();

jest.mock("../../services/application.service", () => ({
  useApplicationService: jest.fn(() => ({
    updateBaseApplicationDetail: mockUpdateBaseApplicationDetail,
  })),
}));

jest.mock("@common/components", () => {
  const components = jest.requireActual("@common/components");
  return {
    ...components,
    Loading: () => {
      return <div>Loading</div>;
    },
    BankDetail: jest.fn(({ updateBankDetails }) => {
      return (
        <div className="bank-detail">
          <button
            type="button"
            className="update-btn"
            onClick={() =>
              updateBankDetails({
                bankName: "Bank of England",
                monthsAtBank: 11,
                nameOnBankAccount: "Edward Gibbs",
                accountNumber: "31510602",
                sortCode: "565778",
                netMonthlyIncome: 30000,
              })
            }
          >
            Update Details
          </button>
        </div>
      );
    }),
  };
});

Manager.getInstance = flexManagerMock;

const props: ComponentProps = {
  applicationId: 1,
  bankDetail: {
    bankName: "Bank of England",
    monthsAtBank: 11,
    nameOnBankAccount: "Edward Gibbs",
    accountNumber: "31510604",
    sortCode: "565777",
    netMonthlyIncome: 30000,
  },
  setCustomerDetails: jest.fn(() => {}),
  backToWizardStepper: jest.fn(() => {}),
};

describe("BankDetailWrapper", () => {
  afterEach(() => {
    jest.clearAllMocks();
    jest.clearAllTimers();
  });

  it("renders correctly", async () => {
    const wrapper = create(<BankDetailWrapper {...props} />).toJSON();
    await flushPromises();

    expect(wrapper).toMatchSnapshot();
  });

  it("when update detail button is clicked, should update bank detail and show success notification", async () => {
    mockUpdateBaseApplicationDetail.mockImplementationOnce(() =>
      Promise.resolve(undefined)
    );

    await act(async () => {
      const wrapper = mount(<BankDetailWrapper {...props} />);
      wrapper.update();

      wrapper.find(".update-btn").at(0).simulate("click");
      await flushPromises();
      wrapper.update();

      expect(mockUpdateBaseApplicationDetail).toHaveBeenCalledTimes(1);
      expect(showMessage).toHaveBeenCalledWith(
        "successNotification",
        "Customer bank detail updated successfully!"
      );
      expect(props.setCustomerDetails).toHaveBeenCalled();
      expect(props.backToWizardStepper).toHaveBeenCalled();
    });
  });

  it("should show error message, if getting error while update bank details", async () => {
    mockUpdateBaseApplicationDetail.mockImplementationOnce(() =>
      Promise.reject()
    );

    await act(async () => {
      const wrapper = mount(<BankDetailWrapper {...props} />);

      wrapper.find(".update-btn").at(0).simulate("click");
      await flushPromises();
      wrapper.update();

      expect(showErrorMessage).toHaveBeenCalledWith(
        "Error in updating bank detail, please try again!",
        "",
        true
      );
    });
  });
});
