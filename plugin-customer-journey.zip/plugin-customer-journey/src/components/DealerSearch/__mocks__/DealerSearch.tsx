import React from "react";

export const DealerSearch: React.FC = () => <div className="dealer-search" />;
