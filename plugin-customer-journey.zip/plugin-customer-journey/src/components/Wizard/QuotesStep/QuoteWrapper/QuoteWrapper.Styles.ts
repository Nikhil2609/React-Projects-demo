import styled from "react-emotion";

export const QuoteWrapperStyles = styled("div")({
  position: "relative",
  minHeight: 100,
  "div > .progress": {
    left: "50% !important",
  },
});
