import React from "react";
import { ComponentProps } from "../SavedQuoteList";

const SavedQuoteList: React.FC<ComponentProps> = (props) => <div />;

export default SavedQuoteList;
