import SavedQuoteList from "./SavedQuoteList";

export default SavedQuoteList;
