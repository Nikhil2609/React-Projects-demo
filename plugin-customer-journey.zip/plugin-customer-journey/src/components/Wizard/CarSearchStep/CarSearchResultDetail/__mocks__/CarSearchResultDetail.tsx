import React from "react";

import { CarSearchResultDetailProp } from "../CarSearchResultDetail";

const CarSearchResultDetail: React.FC<CarSearchResultDetailProp> = (props) => (
  <div />
);

export default CarSearchResultDetail;
