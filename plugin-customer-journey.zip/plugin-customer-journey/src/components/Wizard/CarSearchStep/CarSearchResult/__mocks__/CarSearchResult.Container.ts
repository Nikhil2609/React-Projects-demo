import CarSearchResult from "./CarSearchResult";

export default CarSearchResult;
