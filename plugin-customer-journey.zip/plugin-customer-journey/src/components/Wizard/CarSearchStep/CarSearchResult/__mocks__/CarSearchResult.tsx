import React from "react";
import { ComponentProps } from "../CarSearchResult";

const CarSearchResult: React.FC<ComponentProps> = (props) => <div />;

export default CarSearchResult;
