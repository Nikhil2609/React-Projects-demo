import React from "react";
import { ComponentProps } from "../SavedCarsList";

const SavedCarsList: React.FC<ComponentProps> = (props) => <div />;

export default SavedCarsList;
