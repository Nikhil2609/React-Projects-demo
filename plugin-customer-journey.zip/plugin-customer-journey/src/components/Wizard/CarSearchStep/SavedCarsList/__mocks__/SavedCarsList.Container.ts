import SavedCarsList from "./SavedCarsList";

export default SavedCarsList;
