import CarSearchResultDetailWrapper from "./CarSearchResultDetailWrapper";

export default CarSearchResultDetailWrapper;
