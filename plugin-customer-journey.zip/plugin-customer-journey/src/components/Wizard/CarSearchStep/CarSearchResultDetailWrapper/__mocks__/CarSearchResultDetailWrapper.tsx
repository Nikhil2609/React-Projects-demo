import React from "react";
import { ComponentProps } from "../CarSearchResultDetailWrapper";

const CarSearchResultDetailWrapper: React.FC<ComponentProps> = (props) => (
  <div />
);

export default CarSearchResultDetailWrapper;
