import Component from "./CarSearchCriteria";

export default Component;
