import styled from "react-emotion";

export const WizardComponentStyles = styled("div")({});
