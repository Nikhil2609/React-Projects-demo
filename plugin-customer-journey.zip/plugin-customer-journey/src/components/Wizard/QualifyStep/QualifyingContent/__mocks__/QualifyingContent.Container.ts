import QualifyingContent from "./QualifyingContent";

export default QualifyingContent;
