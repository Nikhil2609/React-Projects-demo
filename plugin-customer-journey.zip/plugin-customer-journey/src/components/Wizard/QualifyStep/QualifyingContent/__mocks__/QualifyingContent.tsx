import React from "react";
import { QualifyingContentProps } from "../QualifyingContent";

const QualifyingContent: React.FC<QualifyingContentProps> = (_props) => <div />;

export default QualifyingContent;
