export interface CarRegisteredSnackbarProps {
  is247Cars: boolean;
}
