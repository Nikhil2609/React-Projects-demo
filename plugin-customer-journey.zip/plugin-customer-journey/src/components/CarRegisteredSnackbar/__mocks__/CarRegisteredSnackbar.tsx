import React from "react";
import { CarRegisteredSnackbarProps } from "../CarRegisteredSnackbar.Props";

export const CarRegisteredSnackbar: React.FC<CarRegisteredSnackbarProps> = (
  props
) => {
  return <div className="car-registered-snackbar">CarRegisteredSnackbar</div>;
};
