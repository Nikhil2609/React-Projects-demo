export interface OwnProps {
  updateApplication: () => void;
}

export type UpdateApplicationProps = OwnProps;
