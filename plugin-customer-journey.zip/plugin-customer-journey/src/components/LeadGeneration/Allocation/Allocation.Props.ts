export interface OwnProps {
  getRankedAgents: () => void;
}

export type AllocationProps = OwnProps;
