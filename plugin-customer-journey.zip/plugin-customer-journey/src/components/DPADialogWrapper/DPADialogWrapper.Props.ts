export interface StateToProps {
  pin: string;
  postCode: string;
  dateOfBirth: string;
}

export interface DispatchToProps {}
