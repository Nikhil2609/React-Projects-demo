module.exports = {
	extends: [
		"react-app",
		"react-app/jest",
		"plugin:prettier/recommended",
	],
	rules: {
		"prettier/prettier": ["error", { endOfLine: "auto" }],
		"no-console": "warn",
		"no-debugger": "warn",
	},
	plugins: ["prettier"],
	overrides: [
		{
			files: ["**/*.ts?(x)"],
			rules: {},
		},
	],
};
