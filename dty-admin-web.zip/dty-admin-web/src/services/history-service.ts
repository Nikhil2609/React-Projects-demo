import { AxiosResponse } from "axios";
import {
	IHistoryInfo,
	IHistorySearchFields,
	IHttpsResponse,
} from "utility/interfaces";
import { ProtectedEndPoints } from "./api-end-points";
import httpClient from "./base-service";

const getSearchFields = async (): Promise<
	AxiosResponse<IHttpsResponse<IHistorySearchFields>>
> =>
	httpClient.get<IHttpsResponse<IHistorySearchFields>>(
		ProtectedEndPoints.GetHistorySearchFields
	);

const getHistoryGrids = async (): Promise<
	AxiosResponse<IHttpsResponse<IHistoryInfo>>
> =>
	httpClient.get<IHttpsResponse<IHistoryInfo>>(
		ProtectedEndPoints.GetHistoryGrids
	);

export default { getSearchFields };
