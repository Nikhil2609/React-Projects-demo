import { AxiosResponse } from "axios";
import { IAssignCaseInfo } from "utility/interfaces";
import {
	ICancelCaseInfo,
	ICancelCaseRequest,
	IDashboardInfo,
	IViewCaseInfo,
	IViewNoteInfo,
	IHttpsResponse,
	IDashboardSearchCriteria,
} from "utility/interfaces";
import { ProtectedEndPoints } from "./api-end-points";
import httpClient from "./base-service";

const getDashboardInfo = async (
	request: IDashboardSearchCriteria
): Promise<AxiosResponse<IHttpsResponse<IDashboardInfo>>> =>
	httpClient.post<IHttpsResponse<IDashboardInfo>>(
		ProtectedEndPoints.GetDashboardDetails,
		request
	);

const getViewCaseInfo = async (
	request: any
): Promise<AxiosResponse<IHttpsResponse<IViewCaseInfo>>> =>
	httpClient.post<IHttpsResponse<IViewCaseInfo>>(
		ProtectedEndPoints.GetViewCaseInfo,
		request
	);

const getViewNoteInfo = async (
	request: any
): Promise<AxiosResponse<IHttpsResponse<IViewNoteInfo>>> =>
	httpClient.post<IHttpsResponse<IViewNoteInfo>>(
		ProtectedEndPoints.GetViewNoteInfo,
		request
	);

const getCancelCaseModalInfo = async (
	request: any
): Promise<AxiosResponse<IHttpsResponse<ICancelCaseInfo>>> =>
	httpClient.post<IHttpsResponse<ICancelCaseInfo>>(
		ProtectedEndPoints.GetCancelCaseInfo,
		request
	);

const getAssignCaseModalInfo = async (
	request: any
): Promise<AxiosResponse<IHttpsResponse<IAssignCaseInfo>>> =>
	httpClient.post<IHttpsResponse<IAssignCaseInfo>>(
		ProtectedEndPoints.GetAssignCaseInfo,
		request
	);

const cancelCase = async (
	request: ICancelCaseRequest
): Promise<AxiosResponse<IHttpsResponse<any>>> =>
	httpClient.post<IHttpsResponse<any>>(ProtectedEndPoints.CancelCase, request);

export default {
	getDashboardInfo,
	getViewCaseInfo,
	getViewNoteInfo,
	getCancelCaseModalInfo,
	cancelCase,
	getAssignCaseModalInfo,
};
