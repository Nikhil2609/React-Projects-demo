import { AxiosResponse } from "axios";
import {
	ICreatUpdateRoleRequest,
	IRoleDetails,
	IRoleInfo,
	ISearchCriteria,
	IHttpsResponse,
} from "utility/interfaces";
import { ProtectedEndPoints } from "./api-end-points";
import httpClient from "./base-service";

const getGridRoles = async (
	searchCriteria: ISearchCriteria
): Promise<AxiosResponse<IHttpsResponse<IRoleInfo>>> =>
	httpClient.post<IHttpsResponse<IRoleInfo>>(
		ProtectedEndPoints.GetGridRoles,
		searchCriteria
	);

const getNewRoleDetails = async (): Promise<
	AxiosResponse<IHttpsResponse<IRoleDetails>>
> =>
	httpClient.get<IHttpsResponse<IRoleDetails>>(
		ProtectedEndPoints.GetNewRoleDetails
	);

const getRoleDetails = async (
	roleId: string
): Promise<AxiosResponse<IHttpsResponse<IRoleDetails>>> =>
	httpClient.post<IHttpsResponse<IRoleDetails>>(
		ProtectedEndPoints.GetRoleDetails,
		{
			roleId,
		}
	);

const createRole = async (
	request: ICreatUpdateRoleRequest
): Promise<AxiosResponse<IHttpsResponse<any>>> =>
	httpClient.post<IHttpsResponse<any>>(ProtectedEndPoints.CreateRole, request);

const updateRole = async (
	request: ICreatUpdateRoleRequest
): Promise<AxiosResponse<IHttpsResponse<any>>> =>
	httpClient.post<IHttpsResponse<any>>(ProtectedEndPoints.UpdateRole, request);

const deleteRole = async (
	roleId: number
): Promise<AxiosResponse<IHttpsResponse<any>>> =>
	httpClient.post<IHttpsResponse<any>>(ProtectedEndPoints.DeleteRole, {
		roleId,
	});

export default {
	getGridRoles,
	getNewRoleDetails,
	getRoleDetails,
	updateRole,
	createRole,
	deleteRole,
};
