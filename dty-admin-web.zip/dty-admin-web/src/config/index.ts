// export const BASE_API_URL = `https://localhost:7080/`;
export const BASE_API_URL = `https://web2.anasource.com/dtyapi/`;
export const ANONYMOUS_KEY = `DTY-Anonymous`;
export const APPLICATION = `Web`;
export const APPLICATION_TYPE = `AdminProvider`;
export const ENVIRONMENT = `dev`;
