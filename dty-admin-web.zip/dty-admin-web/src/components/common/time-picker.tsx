import { TextField } from "@mui/material";
import { LocalizationProvider, TimePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { ClockIcon } from "assests/images";
import React from "react";

type ComponentProps = {
	value: string | undefined;
	label: string;
	onChange: any;
	name: string;
	disabled: boolean;
};

export function CustomTimePicker(props: ComponentProps) {
	const { value, onChange, label, name, disabled } = props;
	function datePickerIcon() {
		return (
			<>
				<img src={ClockIcon} alt="time" />
			</>
		);
	}
	return (
		<>
			<LocalizationProvider dateAdapter={AdapterDayjs}>
				<TimePicker
					closeOnSelect={false}
					disabled={disabled}
					label={label}
					value={value || null}
					onChange={(newValue) => {
						onChange(name, newValue);
					}}
					components={{
						OpenPickerIcon: datePickerIcon,
					}}
					renderInput={(params) => (
						<TextField
							{...params}
							fullWidth
							id="time"
							className="datepicker"
							autoComplete="on"
							inputProps={{
								...params.inputProps,
							}}
						/>
					)}
				/>
			</LocalizationProvider>
		</>
	);
}
