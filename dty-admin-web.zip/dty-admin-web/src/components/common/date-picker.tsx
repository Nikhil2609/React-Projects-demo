import { TextField } from "@mui/material";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { CalendarDarkIcon } from "assests/images";
import React from "react";

type ComponentProps = {
	value: string | undefined;
	label: string;
	onChange: any;
	name: string;
	disabled: boolean;
};

export function CustomDatePicker(props: ComponentProps) {
	const { value, onChange, label, name, disabled } = props;
	function datePickerIcon() {
		return (
			<>
				<img src={CalendarDarkIcon} alt="calendar" />
			</>
		);
	}
	return (
		<>
			<LocalizationProvider dateAdapter={AdapterDayjs}>
				<DesktopDatePicker
					disabled={disabled}
					label={label}
					value={value || null}
					inputFormat="DD/MM/YYYY"
					onChange={(newValue) => {
						onChange(name, newValue);
					}}
					components={{
						OpenPickerIcon: datePickerIcon,
					}}
					renderInput={(params) => (
						<TextField
							{...params}
							fullWidth
							id="date"
							className="datepicker"
							autoComplete="off"
							inputProps={{
								...params.inputProps,
							}}
						/>
					)}
				/>
			</LocalizationProvider>
		</>
	);
}
