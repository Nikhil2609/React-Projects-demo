import React, { useEffect } from "react";
import {
	IconButton,
	InputAdornment,
	TextField,
	Typography,
} from "@mui/material";
import {
	CloseWhiteIcon,
	LinkIcon,
	MaximizeIcon,
	MinimizeIcon,
	MoodIcon,
	Profile,
	SendIcon,
	VerticalMenuIcon,
} from "assests/images";
import { ChatMenu } from "./chat-menu";
import { IChatBoxInfo } from "utility/interfaces";

type ComponentProps = {
	handleOnCloseChat: any;
	handleOnMinimized: any;
	chatBoxInfo: IChatBoxInfo;
	index: number;
};

export function ChatBox(props: ComponentProps) {
	// useStates
	const [chatMenu, setChatMenu] = React.useState<null | HTMLElement>(null);
	const [isChatMenuRight, setIsChatMenuRight] = React.useState(false);
	const [minimizeClass, setMinimizeClass] = React.useState("maximize-chatbox");
	// Extract Props
	const { handleOnCloseChat, chatBoxInfo, handleOnMinimized, index } = props;

	// Handled events and functions
	const handleOnClickMinimized = () => {
		if (chatBoxInfo.isMinimized) setMinimizeClass("maximize-chatbox");
		else setMinimizeClass("minimize-chatbox");

		handleOnMinimized(chatBoxInfo.receiverId, chatBoxInfo.senderId);
	};
	const chatMenuOpen = Boolean(chatMenu);
	const handleChatMenuClick = (
		event: React.MouseEvent<HTMLElement>,
		isRightSide: boolean
	) => {
		setIsChatMenuRight(isRightSide);
		setChatMenu(event.currentTarget);
	};

	const handleChatMenuClose = () => {
		setChatMenu(null);
	};

	// useEffects
	useEffect(() => {
		if (chatBoxInfo.isMinimized) setMinimizeClass("minimize-chatbox");
		else setMinimizeClass("maximize-chatbox");
	}, [chatBoxInfo]);

	return (
		<div className={`chat-popover chat-${index} ${minimizeClass}`}>
			<div className="popover-header">
				<Typography variant="h5">
					<img src={Profile} alt="profile" />
					{chatBoxInfo.receiverName}
				</Typography>
				<div className="chat-action-group">
					{chatBoxInfo.isMinimized ? (
						<IconButton
							disableFocusRipple
							disableRipple
							onClick={handleOnClickMinimized}
						>
							<img src={MaximizeIcon} alt="clmaximizeose" />
						</IconButton>
					) : (
						<IconButton
							disableFocusRipple
							disableRipple
							className="chatbox-size-btn minimize-btn"
							onClick={handleOnClickMinimized}
						>
							<img src={MinimizeIcon} alt="minimize" />
						</IconButton>
					)}
					<IconButton
						onClick={(e) => {
							handleOnCloseChat(chatBoxInfo.receiverId, chatBoxInfo.senderId);
						}}
						disableFocusRipple
						disableRipple
					>
						<img src={CloseWhiteIcon} alt="close" />
					</IconButton>
				</div>
			</div>
			<div className="popover-body">
				<div className="popover-scroll">
					<div className="popover-scroll-inner">
						<span className="day">Today</span>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">Hello</div>
							<Typography variant="body1">11:30 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">Good Morning</div>
							<Typography variant="body1">11:32 AM</Typography>
						</div>
						<div className="messages left">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">Good Morning</div>
							<Typography variant="body1">11:45 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages left">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur. Lorem ipsum dolor sit
								amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
						<div className="messages right">
							<IconButton
								onClick={(e) => handleChatMenuClick(e, true)}
								aria-haspopup="true"
								disableFocusRipple
								disableRipple
							>
								<img src={VerticalMenuIcon} alt="menu" />
							</IconButton>
							<div className="message">
								Lorem ipsum dolor sit amet consectetur.
							</div>
							<Typography variant="body1">11:52 AM</Typography>
						</div>
					</div>
				</div>
			</div>
			<div className="popover-footer">
				<TextField
					placeholder="Type a message"
					id="chat"
					fullWidth
					className="with-icon-left"
					InputProps={{
						startAdornment: (
							<InputAdornment position="start">
								<IconButton edge="end" disableFocusRipple disableRipple>
									<img src={MoodIcon} alt="smiley" />
								</IconButton>
							</InputAdornment>
						),
					}}
				/>
				<IconButton className="contained">
					<img src={SendIcon} alt="send" />
				</IconButton>
				<IconButton className="outlined">
					<img src={LinkIcon} alt="link" />
				</IconButton>
			</div>
			<ChatMenu
				handleChatMenuClose={handleChatMenuClose}
				isRight={isChatMenuRight}
				chatMenu={chatMenu}
				chatMenuOpen={chatMenuOpen}
			/>
		</div>
	);
}
