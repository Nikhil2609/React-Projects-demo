import React from "react";
import { PDFViewer } from "@react-pdf/renderer";
import { Document, Page } from "@react-pdf/renderer";

type ComponentProps = {
	content: any;
};
export function CustomPDFViewer(props: ComponentProps) {
	// Extract Props
	const { content } = props;
	return (
		<PDFViewer
			width="100%"
			style={{ maxWidth: "100%" }}
			height="100%"
			showToolbar={true}
		>
			<Document>
				<Page
					size="A4"
					style={{ flexDirection: "row", backgroundColor: "#E4E4E4" }}
				>
					{content}
				</Page>
			</Document>
		</PDFViewer>
	);
}
