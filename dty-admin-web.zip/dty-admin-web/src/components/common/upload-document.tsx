import {
	Button,
	FormControl,
	InputAdornment,
	OutlinedInput,
	Tooltip,
} from "@mui/material";
import { UploadcloudIcon } from "assests/images";
import React, { useState } from "react";

export function UploadDocument() {
	// useStates
	const [selectedFiles, setSelectedFiles] = useState<string[]>([]);

	// Handled event(s)
	const onSelectNewFiles = (event: any) => {
		const fileNames: string[] = [];
		if (event.target.files && event.target.files.length > 0) {
			Array.prototype.forEach.call(event.target.files, (file: any) => {
				fileNames.push(file.name);
			});
			setSelectedFiles(fileNames);
		}
	};

	return (
		<>
			<FormControl fullWidth variant="outlined">
				<OutlinedInput
					id="upload-file"
					type="text"
					disabled
					value={selectedFiles}
					className="upload-input"
					placeholder="Select File"
					endAdornment={
						<InputAdornment position="end">
							<Tooltip title="Click Here To Upload">
								<Button
									variant="contained"
									component="label"
									disableElevation
									disableFocusRipple
									disableRipple
								>
									<img src={UploadcloudIcon} alt="upload" />
									<span>Upload</span>
									<input
										onChange={onSelectNewFiles}
										hidden
										accept="*"
										multiple
										type="file"
									/>
								</Button>
							</Tooltip>
						</InputAdornment>
					}
					label="Password"
				/>
			</FormControl>
		</>
	);
}
