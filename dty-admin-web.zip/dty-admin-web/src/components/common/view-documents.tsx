import React from "react";
import { Box, Button, Tooltip, Typography } from "@mui/material";
import {
	ArrowBack,
	DeleteAllIcon,
	DownloadAllIcon,
	MailIconBlue,
} from "assests/images";
import { UploadDocument, WarningModal, DocumentList } from "components";
import { IDocumentInfo } from "utility/interfaces";
import myCustomTheme from "app.theme";

interface EnhancedTableToolbarProps {
	selectedDocuments: readonly string[];
	handleOnClickSendEmail: any;
	handleOnClickDeleteAll: any;
	handleOnClickDownloadDocument: any;
}

type ComponentProps = {
	documentList: IDocumentInfo[];
	handleOnClickBackCancel: any;
};

function EnhancedTableToolbar(props: EnhancedTableToolbarProps) {
	const {
		selectedDocuments,
		handleOnClickSendEmail,
		handleOnClickDeleteAll,
		handleOnClickDownloadDocument,
	} = props;

	return (
		<Box>
			<Tooltip title="Download Selected">
				<Button
					variant="outlined"
					disableElevation
					disableRipple
					disableFocusRipple
					disabled={selectedDocuments.length > 0 ? false : true}
					sx={{
						minWidth: "111px",
						[myCustomTheme.breakpoints.down("sm")]: {
							minWidth: "0",
						},
					}}
					onClick={() => handleOnClickDownloadDocument(selectedDocuments, true)}
				>
					<span>Download all</span>
					<img src={DownloadAllIcon} alt="download" />
				</Button>
			</Tooltip>
			<Tooltip title="Delete Selected">
				<Button
					variant="outlined"
					disableElevation
					disableRipple
					disableFocusRipple
					disabled={selectedDocuments.length > 0 ? false : true}
					sx={{
						minWidth: "111px",
						[myCustomTheme.breakpoints.down("sm")]: {
							minWidth: "0",
						},
					}}
					onClick={() =>
						selectedDocuments.length > 0 && handleOnClickDeleteAll()
					}
				>
					<span>Delete all</span>
					<img src={DeleteAllIcon} alt="delete" />
				</Button>
			</Tooltip>
			<Tooltip title="Send Mail">
				<Button
					variant="outlined"
					disableElevation
					disableRipple
					disableFocusRipple
					disabled={selectedDocuments.length > 0 ? false : true}
					sx={{
						minWidth: "111px",
						[myCustomTheme.breakpoints.down("sm")]: {
							minWidth: "0",
						},
					}}
					onClick={() =>
						selectedDocuments.length > 0 && handleOnClickSendEmail()
					}
				>
					<span>Send Mail</span>
					<img src={MailIconBlue} alt="mail" />
				</Button>
			</Tooltip>
		</Box>
	);
}

export function ViewDocuments(props: ComponentProps) {
	// props
	const { documentList, handleOnClickBackCancel } = props;

	// useStates
	const [selectedDocuments, setSelectedDocuments] = React.useState<
		readonly string[]
	>([]);
	const [isDeleteModalOpen, setIsDeleteModalOpen] = React.useState(false);
	const [isSendDocumentModalOpen, setIsSendDocumentModalOpen] =
		React.useState(false);
	const [documentsNeedToDeleteOrSend, setDocumentsNeedToDeleteOrSend] =
		React.useState<readonly string[]>([]);

	const handleOnClickDeleteButton = () => {
		//TODO: Delete document logic will here
		console.log(documentsNeedToDeleteOrSend);
	};
	const handleOnClickSendEmailButton = () => {
		//TODO: Send emails logic will here
		console.log(documentsNeedToDeleteOrSend);
	};

	const handleOnClickDownloadDocument = (
		ids?: string[] | null,
		isDownloadMultiple?: boolean
	) => {
		//TODO: Download logic will here
		console.log(ids);
	};

	const handleOnClickDeleteDocument = (ids: string[]) => {
		setDocumentsNeedToDeleteOrSend(ids);
		setIsDeleteModalOpen(true);
	};
	const handleOnClickSendEmail = () => {
		setDocumentsNeedToDeleteOrSend(selectedDocuments);
		setIsSendDocumentModalOpen(true);
	};
	const handleOnClickDeleteAll = () => {
		setDocumentsNeedToDeleteOrSend(selectedDocuments);
		setIsDeleteModalOpen(true);
	};
	const handleOnSelectAllClick = (
		event: React.ChangeEvent<HTMLInputElement>
	) => {
		if (event.target.checked) {
			const newSelected = documentList.map((n) => n.id.toString());
			setSelectedDocuments(newSelected);
			return;
		}
		setSelectedDocuments([]);
	};

	const handleOnSelectDocument = (doc: number) => {
		const selectedIndex = selectedDocuments.indexOf(doc.toString());
		let newSelected: readonly string[] = [];

		if (selectedIndex === -1) {
			newSelected = newSelected.concat(selectedDocuments, doc.toString());
		} else if (selectedIndex === 0) {
			newSelected = newSelected.concat(selectedDocuments.slice(1));
		} else if (selectedIndex === selectedDocuments.length - 1) {
			newSelected = newSelected.concat(selectedDocuments.slice(0, -1));
		} else if (selectedIndex > 0) {
			newSelected = newSelected.concat(
				selectedDocuments.slice(0, selectedIndex),
				selectedDocuments.slice(selectedIndex + 1)
			);
		}
		setSelectedDocuments(newSelected);
	};

	return (
		<>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Documents</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div className="confirm-number uploaded-data">
							<label>Patient Name</label>
							<Typography variant="h4">
								Rajesh Satvara <span>&nbsp;&#40;DC010423SARA0002&#41;</span>
							</Typography>
						</div>
						<Typography variant="body1" className="instruction">
							Check here to review and add files that you or the Client/Member
							has attached to the Request.
						</Typography>
						<UploadDocument />
						<div className="attachment">
							<Typography variant="h4">Documents</Typography>
							<Box className="selected-action-btn">
								<EnhancedTableToolbar
									handleOnClickSendEmail={handleOnClickSendEmail}
									selectedDocuments={selectedDocuments}
									handleOnClickDeleteAll={handleOnClickDeleteAll}
									handleOnClickDownloadDocument={handleOnClickDownloadDocument}
								/>
							</Box>
						</div>
						<DocumentList
							selectedDocuments={selectedDocuments}
							documentList={documentList}
							handleOnSelectAllClick={handleOnSelectAllClick}
							handleOnSelectDocument={handleOnSelectDocument}
							handleOnClickDeleteDocument={handleOnClickDeleteDocument}
							handleOnClickDownloadDocument={handleOnClickDownloadDocument}
						/>
					</Box>
				</Box>
			</main>
			{/* Page Modals */}
			{/* Delete warning*/}
			<WarningModal
				isModalOpen={isDeleteModalOpen}
				handleOnClickCloseModal={() => {
					setDocumentsNeedToDeleteOrSend([]);
					setIsDeleteModalOpen(false);
				}}
				title="Delete"
				warningMessage="Are you sure, want to delete selected document(s)?"
				okButtonText="Delete"
				closeButtonText="Cancel"
				handleOnClickOk={handleOnClickDeleteButton}
			/>
			{/* Send email warning*/}
			<WarningModal
				isModalOpen={isSendDocumentModalOpen}
				handleOnClickCloseModal={() => {
					setDocumentsNeedToDeleteOrSend([]);
					setIsSendDocumentModalOpen(false);
				}}
				title="Send"
				warningMessage="Are you sure, want to send selected document(s)?"
				okButtonText="Send"
				closeButtonText="Cancel"
				handleOnClickOk={handleOnClickSendEmailButton}
			/>
		</>
	);
}
