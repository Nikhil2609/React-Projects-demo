import React from "react";
import { Divider, Tooltip } from "@mui/material";
import { FooterLogo, FooterLogoMobile } from "assests/images";

export function Footer() {
	return (
		<footer>
			<Tooltip title="Doctors To You">
				<a href="/designer-dashboard" className="footer-logo">
					<img src={FooterLogo} alt="Doctors To You" className="desktop" />
					<img src={FooterLogoMobile} alt="Doctors To You" className="mobile" />
				</a>
			</Tooltip>
			<div className="footer-links">
				<Tooltip title="Terms of Conditions">
					<a href="#">Terms of Conditions</a>
				</Tooltip>
				<Divider orientation="vertical" variant="middle" flexItem />
				<Tooltip title="Privacy Policy">
					<a href="#">Privacy Policy</a>
				</Tooltip>
			</div>
		</footer>
	);
}
