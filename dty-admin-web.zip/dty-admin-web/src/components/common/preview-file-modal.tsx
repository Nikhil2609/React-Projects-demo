import { Box, Button, IconButton, Modal, Typography } from "@mui/material";
import { CloseWhiteIcon } from "assests/images";
import React from "react";
import { commonModalStyle } from "utility/helpers";

type ComponentProps = {
	isModelOpen: boolean;
	handleModalClose: any;
	url: string;
};

export function PreviewFileModal(props: ComponentProps) {
	// Extract Props
	const { isModelOpen, handleModalClose, url } = props;

	return (
		<>
			<Modal
				open={isModelOpen}
				onClose={handleModalClose}
				className="send-modal"
			>
				<Box sx={commonModalStyle}>
					<Box className="modal-header">
						<Typography variant="h5">Preview</Typography>
						<IconButton onClick={handleModalClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<iframe
								style={{ width: "100%", height: "500px" }}
								title="Preview"
								src={url}
							/>
						</div>
						<div className="modal-footer">
							<a href={url} target="_blank" rel="noreferrer">
								If you can not preview, click here
							</a>
							<Button variant="outlined" onClick={handleModalClose}>
								Close
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
		</>
	);
}
