import React from "react";
import { Divider } from "@mui/material";
import Tooltip from "@mui/material/Tooltip";

export function AccountFooter() {
	return (
		<div className="login-links">
			<Tooltip title="Terms of Conditions">
				<a>Terms of Conditions</a>
			</Tooltip>
			<Divider orientation="vertical" variant="middle" flexItem />
			<Tooltip title="Privacy Policy">
				<a>Privacy Policy</a>
			</Tooltip>
		</div>
	);
}
