import React, { useState } from "react";
import { Box, Button, Checkbox, TableCell, Tooltip } from "@mui/material";
import { IProvider } from "utility/interfaces";
import { UncheckIcon, CheckIcon } from "assests/images";
import { ContactProviderModal } from "./contact-provider-modal";

type ComponentProps = {
	row: IProvider;
	handleOnSelectRow: any;
	index: any;
};

export function ProviderInfoTableRow(props: ComponentProps) {
	// Extract Props
	const { row, handleOnSelectRow, index } = props;

	// useStates
	const [openContactProvider, setOpenContactProvider] = useState(false);

	// events and functions
	const handleOnClickDelete = () => {
		console.log("Delete logic here");
	};
	const CheckedboxIcon = () => {
		return <img src={CheckIcon} alt="checkbox" />;
	};
	const CheckboxIcon = () => {
		return <img src={UncheckIcon} alt="checkbox" />;
	};

	return (
		<>
			<TableCell padding="checkbox" align="center">
				<Checkbox
					onClick={() => handleOnSelectRow(row.providerId)}
					icon={<CheckboxIcon />}
					checkedIcon={<CheckedboxIcon />}
					checked={row.isNotificationStoped}
					disableRipple
					disableFocusRipple
					inputProps={{
						"aria-labelledby": `enhanced-table-checkbox-${index}`,
					}}
				/>
			</TableCell>
			<TableCell component="th" scope="row" className="upload-file-col">
				<div className="upload-file">
					<Box className="display-small-table-label">Provider Name: &nbsp;</Box>
					<span>{row.providerName}</span>
				</div>
			</TableCell>
			<TableCell scope="row">
				<div>
					<Box className="display-small-table-label">Role: &nbsp;</Box>
					<span>{row.role}</span>
				</div>
			</TableCell>
			<TableCell scope="row">
				<div>
					<Box className="display-small-table-label">
						On Call Status: &nbsp;
					</Box>
					<span>{row.onCallStatus}</span>
				</div>
			</TableCell>
			<TableCell align="center">
				<div className="upload-actions">
					<Tooltip title="Contact">
						<Button
							id="table-button-edit"
							onClick={() => setOpenContactProvider(true)}
							className="action-btn action-btn-primary"
							style={{ marginRight: 4 }}
						>
							Contact
						</Button>
					</Tooltip>
					<Tooltip title="Edit">
						<Button
							id="table-button-delete"
							className="action-btn action-btn-primary"
						>
							Edit
						</Button>
					</Tooltip>
				</div>
			</TableCell>
			<ContactProviderModal
				modalOpen={openContactProvider}
				onModalClose={() => setOpenContactProvider(false)}
				providerId={row.providerId}
			/>
		</>
	);
}
