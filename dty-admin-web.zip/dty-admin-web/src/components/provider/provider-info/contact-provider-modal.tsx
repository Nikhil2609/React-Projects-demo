import { yupResolver } from "@hookform/resolvers/yup";
import {
	Box,
	Button,
	IconButton,
	Modal,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import { CloseWhiteIcon } from "assests/images";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { commonModalStyle } from "utility/helpers";
import { IContactProvider } from "utility/interfaces";
import { contactProviderSchema } from "utility/validations";

type ComponentProps = {
	modalOpen: boolean;
	onModalClose: any;
	providerId: string;
};

export function ContactProviderModal(props: ComponentProps) {
	// Extract Props
	const { modalOpen, onModalClose, providerId } = props;

	// useStates
	const [formValues, setFormValues] = useState<IContactProvider>({
		communicationBy: "sms",
		message: "",
	});

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
		clearErrors,
		reset,
	} = useForm({
		resolver: yupResolver(contactProviderSchema),
	});

	// Events and functions
	const handleOnChangeMessage = (e: any) => {
		setFormValues({ ...formValues, message: e.target.value });
	};
	const handleOnClickConfirm = () => {
		console.log(formValues);
	};

	// useEffects
	useEffect(() => {
		reset();
		clearErrors();
		setFormValues({
			communicationBy: "sms",
			message: "",
		});
	}, [modalOpen]);

	return (
		<>
			<Modal
				open={modalOpen}
				onClose={onModalClose}
				className="send-modal select-input-modal"
			>
				<Box sx={commonModalStyle}>
					<Box className="modal-header">
						<Typography variant="h5">Contact Your Provider</Typography>
						<IconButton onClick={onModalClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="h6" className="patient-name">
								Choose communication to send message
							</Typography>
							<TextField
								{...register("message")}
								id="block"
								label="Message"
								value={formValues.message}
								name="message"
								onChange={handleOnChangeMessage}
								multiline
								maxRows={1}
								inputProps={{
									style: { minHeight: "88px" },
								}}
								fullWidth
								error={errors?.message?.message ? true : false}
								helperText={errors?.message?.message?.toString()}
							/>
						</div>
						<div className="modal-footer">
							<Tooltip title="Send">
								<Button
									variant="contained"
									onClick={handleSubmit(handleOnClickConfirm)}
								>
									Send
								</Button>
							</Tooltip>
							<Tooltip title="Cancel">
								<Button variant="outlined" onClick={onModalClose}>
									Cancel
								</Button>
							</Tooltip>
						</div>
					</Box>
				</Box>
			</Modal>
		</>
	);
}
