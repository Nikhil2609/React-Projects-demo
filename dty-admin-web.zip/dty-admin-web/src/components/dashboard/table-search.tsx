import React, { useState, useEffect } from "react";
import { Button, TextField } from "@mui/material";
import { IDashboardSearchCriteria } from "utility/interfaces";
import { getTypeWiseClassName } from "utility/helpers";
import { RequestTypes } from "utility/enums/request-status";

type ComponentProps = {
	searchCriteria: IDashboardSearchCriteria;
	handleOnSearchCriteriaChange: any;
};
interface ITypes {
	title: string;
	type: number;
}

const types: ITypes[] = [
	{ title: "All", type: RequestTypes.All },
	{ title: "Patient", type: RequestTypes.Patient },
	{ title: "Family/Friend", type: RequestTypes.Family },
	{ title: "Business", type: RequestTypes.Business },
	{ title: "Concierge", type: RequestTypes.Concierge },
	{ title: "VIP", type: RequestTypes.VIP },
	{ title: "Declined By", type: RequestTypes.Declined },
];

export function DashboardTableSearch(props: ComponentProps) {
	// Extract Props
	const { handleOnSearchCriteriaChange, searchCriteria } = props;

	// useStates
	const [searchText, setSearchText] = useState("");

	// Handled events and functions
	const handleOnSearchTextChange = (e: any) => {
		setSearchText(e.target.value);
	};
	const handleOnTypeChange = (type: number) => {
		const newSearchCriteria = {
			...searchCriteria,
			PageIndexId: 0,
			RequestTypeId: type,
		};
		handleOnSearchCriteriaChange(newSearchCriteria);
	};
	const handleSearchKeywordKeyUp = (event: any) => {
		// Enter keycode = 13
		if (event.keyCode === 13 || event.keyCode === 9) {
			const newSearchCriteria = {
				...searchCriteria,
				PageIndexId: 0,
				SearchBy: event.target.value.trim(),
			};
			handleOnSearchCriteriaChange(newSearchCriteria);
		}
	};

	// useEffects
	useEffect(() => {
		setSearchText(searchCriteria.SearchBy);
	}, [searchCriteria]);

	return (
		<>
			<div className="table-header">
				<TextField
					id="search"
					placeholder="Search Patients"
					variant="outlined"
					autoFocus
					onKeyDown={handleSearchKeywordKeyUp}
					value={searchText}
					onChange={handleOnSearchTextChange}
				/>
				<div className="table-btn-group">
					{types.map((item) => {
						return (
							<Button
								disableElevation
								disableRipple
								key={item.type}
								onClick={() => handleOnTypeChange(item.type)}
								className={
									item.type === searchCriteria.RequestTypeId ? "active" : ""
								}
							>
								{item.type !== RequestTypes.All ? (
									<span className={getTypeWiseClassName(item.type)}></span>
								) : null}
								{item.title}
							</Button>
						);
					})}
				</div>
			</div>
		</>
	);
}
