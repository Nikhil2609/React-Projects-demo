import React, { useEffect, useState } from "react";
import {
	Box,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	Typography,
} from "@mui/material";
import { ChatBox } from "../common/chat-box";
import { IDashboardInfo, IDashboardSearchCriteria } from "utility/interfaces";
import { SortOrder } from "utility/enums/sort-order";
import { IChatBoxInfo } from "utility/interfaces";
import {
	DashboardTableRowData,
	DashboardTableSearch,
	TablePagination,
} from "components";

type ComponentProps = {
	searchCriteria: IDashboardSearchCriteria;
	handleOnSearchCriteriaChange: any;
	dashboardPageInfo: IDashboardInfo | null;
	getDashboardDetails: any;
};

export function DashboardTable(props: ComponentProps) {
	// Extract Props
	const {
		searchCriteria,
		handleOnSearchCriteriaChange,
		dashboardPageInfo,
		getDashboardDetails,
	} = props;

	// useStates
	const [openChatBoxList, setOpenChatBoxList] = useState<IChatBoxInfo[]>([]);

	// Handled events and functions
	const handleOnCloseChat = (receiverId: number, senderId: number) => {
		const openChatBoxes = openChatBoxList.filter(
			(box) => box.receiverId !== receiverId || box.senderId !== senderId
		);
		setOpenChatBoxList([...openChatBoxes]);
	};
	const handleOnMinimized = (receiverId: number, senderId: number) => {
		const chatBoxes = openChatBoxList.map((box) => {
			if (box.receiverId === receiverId && box.senderId === senderId) {
				box.isMinimized = !box.isMinimized;
			}
			return box;
		});
		setOpenChatBoxList(chatBoxes);
	};
	const handleOpenChatBox = (
		receiverName: string,
		senderName: string,
		receiverId: number,
		senderId: number
	) => {
		const openChatBoxes = openChatBoxList.filter(
			(box) => box.receiverId === receiverId && box.senderId === senderId
		);
		if (!openChatBoxes || openChatBoxes?.length === 0) {
			setOpenChatBoxList([
				...openChatBoxList,
				{
					receiverId,
					receiverName,
					senderId,
					senderName,
					isMinimized: false,
				},
			]);
			return;
		}
		const chatBoxes = openChatBoxList.filter(
			(box) => box.receiverId !== receiverId || box.senderId !== senderId
		);
		setOpenChatBoxList([
			...chatBoxes,
			{
				receiverId,
				receiverName,
				senderId,
				senderName,
				isMinimized: false,
			},
		]);
	};
	const updateChatBoxClasses = (openChatBoxList: IChatBoxInfo[]) => {
		const openChatBoxes = openChatBoxList.filter((box) => !box.isMinimized);
		openChatBoxes.length > 0
			? document.body.classList.toggle("chatbox-open", true)
			: document.body.classList.toggle("chatbox-open", false);
	};
	const handleOnPageNumberChange = (value: number) => {
		handleOnSearchCriteriaChange({ ...searchCriteria, PageIndexId: value });
	};
	const handleOnChangeSortDirection = (sortBy: string) => {
		handleOnSearchCriteriaChange({
			...searchCriteria,
			PageIndexId: 0,
			SortBy: sortBy,
			SortOrder:
				searchCriteria.SortOrder === SortOrder.ascending
					? SortOrder.descending
					: SortOrder.ascending,
		});
	};
	// useEffects
	useEffect(() => {
		updateChatBoxClasses(openChatBoxList);
	}, [openChatBoxList]);

	return (
		<Box className="table-box">
			<DashboardTableSearch
				handleOnSearchCriteriaChange={handleOnSearchCriteriaChange}
				searchCriteria={searchCriteria}
			/>
			{dashboardPageInfo && dashboardPageInfo?.totalRecords > 0 ? (
				<>
					<TableContainer sx={{ display: { xs: "none", sm: "block" } }}>
						<Table>
							<TableHead>
								<TableRow>
									{dashboardPageInfo?.gridColumns?.isDisplayName && (
										<TableCell sx={{ minWidth: 190, maxWidth: 190 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "name"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("name")}
											>
												Name
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayEmail && (
										<TableCell sx={{ maxWidth: 55 }}></TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayDateOfBirth && (
										<TableCell sx={{ maxWidth: 145, minWidth: 145 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "dateOfBirth"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("dateOfBirth")
												}
											>
												Date Of Birth
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayRegion && (
										<TableCell sx={{ maxWidth: 165, minWidth: 165 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "regionName"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("regionName")
												}
											>
												Region
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayWaitTime && (
										<TableCell sx={{ maxWidth: 150, minWidth: 150 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "waitTime"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("waitTime")}
											>
												Wait Time
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayRequestorName && (
										<TableCell sx={{ minWidth: 190, maxWidth: 190 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "requestor"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("requestor")}
											>
												Requestor
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayRequestedDate && (
										<TableCell sx={{ minWidth: 180, maxWidth: 180 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "requestedDate"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("requestedDate")
												}
											>
												Requested Date
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayPhysicianName && (
										<TableCell sx={{ minWidth: 180, maxWidth: 180 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "physicianName"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("physicianName")
												}
											>
												Physician Name
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayAcceptedDate && (
										<TableCell sx={{ minWidth: 180, maxWidth: 180 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "name"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("acceptedDate")
												}
											>
												Date Of Service
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayPhone && (
										<TableCell sx={{ minWidth: 200, maxWidth: 200 }}>
											Phone
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayAddress && (
										<TableCell sx={{ minWidth: 210 }}>Address</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayRequestStatus && (
										<TableCell sx={{ minWidth: 110, maxWidth: 110 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "name"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("status")}
											>
												Status
											</TableSortLabel>
										</TableCell>
									)}
									{dashboardPageInfo?.gridColumns?.isDisplayChatWithAdmin ||
									dashboardPageInfo?.gridColumns?.isDisplayChatWithPatient ||
									dashboardPageInfo?.gridColumns?.isDisplayChatWithPhysician ? (
										<TableCell sx={{ minWidth: 210 }}>Chat With</TableCell>
									) : null}

									<TableCell align="center" sx={{ minWidth: 110 }}>
										Actions
									</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{dashboardPageInfo?.requests?.map((row, index) => (
									<DashboardTableRowData
										getDashboardDetails={getDashboardDetails}
										searchCriteria={searchCriteria}
										handleOpenChatBox={handleOpenChatBox}
										key={index}
										row={row}
										isSmallDevice={false}
										gridButtonsPermissions={dashboardPageInfo?.gridButtons}
										gridColumnPermissions={dashboardPageInfo?.gridColumns}
									/>
								))}
							</TableBody>
						</Table>
					</TableContainer>
					<Box
						sx={{ display: { xs: "block", sm: "none" } }}
						className="tabledata-cards-group"
					>
						{dashboardPageInfo?.requests?.map((row, index) => (
							<DashboardTableRowData
								getDashboardDetails={getDashboardDetails}
								searchCriteria={searchCriteria}
								handleOpenChatBox={handleOpenChatBox}
								key={index}
								row={row}
								isSmallDevice={true}
								gridButtonsPermissions={dashboardPageInfo?.gridButtons}
								gridColumnPermissions={dashboardPageInfo?.gridColumns}
							/>
						))}
					</Box>
					<TablePagination
						currentPageNumber={searchCriteria.PageIndexId}
						handleOnPageNumberChange={handleOnPageNumberChange}
						totalRecords={dashboardPageInfo?.totalRecords || 0}
						rowCount={dashboardPageInfo?.requests?.length || 0}
					/>
				</>
			) : (
				<Typography variant="h5" className="no-record" sx={{ padding: 3 }}>
					No Record(s) Found
				</Typography>
			)}
			{openChatBoxList.map((chatBox, index) => {
				return (
					// TODO: set sender and receiver details in table after chat box will work proper
					<ChatBox
						index={index}
						handleOnMinimized={handleOnMinimized}
						key={index}
						handleOnCloseChat={handleOnCloseChat}
						chatBoxInfo={chatBox}
					/>
				);
			})}
		</Box>
	);
}
