import React from "react";
import {
	Button,
	IconButton,
	TableCell,
	TableRow,
	ButtonProps,
	Card,
	CardHeader,
	CardContent,
	Typography,
	Collapse,
	Tooltip,
	Box,
} from "@mui/material";
import {
	CallIcon,
	DoctorLightIcon,
	MailIcon,
	PatientLightIcon,
	CalendarPrimaryIcon,
	ClockIcon,
	StatusCheckIcon,
	RequestorIcon,
	RegionIcon,
	PhysicianIcon,
	CopyIcon,
} from "assests/images";
import { styled } from "@mui/material/styles";
import { getTypeWiseClassName, copyTextOnClipBoard } from "utility/helpers";
import { SendEmailModal } from "./send-email-modal";
import { BlockCaseModal } from "./block-case-modal";
import { AssignTransferCaseModal } from "./assign-transfer-case-modal";
import { CancelCaseModal } from "./cancel-case-modal";
import {
	IRequest,
	IGridButtons,
	IGridColumns,
	IDashboardSearchCriteria,
} from "utility/interfaces";
import {
	WarningModal,
	CustomCopyTooltip,
	DashboardTableRowMenu,
} from "components";
import { SendAgreementModal } from "./send-agreement-modal";

type ComponentProps = {
	row: IRequest;
	isSmallDevice: boolean;
	handleOpenChatBox: any;
	gridButtonsPermissions: IGridButtons;
	gridColumnPermissions: IGridColumns;
	searchCriteria: IDashboardSearchCriteria;
	getDashboardDetails: any;
};

interface ExpandMoreProps extends ButtonProps {
	expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
	const { expand, ...other } = props;
	return (
		<Button {...other} disableFocusRipple disableElevation disableRipple />
	);
})(({ theme, expand }) => ({
	marginLeft: "auto",
	transition: theme.transitions.create("transform", {
		duration: theme.transitions.duration.shortest,
	}),
}));

export function DashboardTableRowData(props: ComponentProps) {
	// useStates
	const [tableUser, setTableUser] = React.useState<null | HTMLElement>(null);
	const [expanded, setExpanded] = React.useState(false);
	const [sendMailOpen, setSendMailOpen] = React.useState(false);
	const [blockCaseModelOpen, setBlockCaseModelOpen] = React.useState(false);
	const [assignCaseModalOpen, setAssignCaseModalOpen] = React.useState(false);
	const [transferCaseModalOpen, setTransferCaseModalOpen] =
		React.useState(false);
	const [cancelCaseModalOpen, setCancelCaseModalOpen] = React.useState(false);
	const [clearCaseModalOpen, setClearCaseModalOpen] = React.useState(false);
	const [sendAgreementModalOpen, setSendAgreementModalOpen] =
		React.useState(false);

	// Extract Props
	const {
		row,
		isSmallDevice,
		handleOpenChatBox,
		gridButtonsPermissions,
		gridColumnPermissions,
		searchCriteria,
		getDashboardDetails,
	} = props;

	// Handled events and functions
	const handleTableMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
		event.stopPropagation();
		setTableUser(event.currentTarget);
	};
	const handleTableMenuClose = () => {
		setTableUser(null);
	};
	const handleExpandClick = () => {
		setExpanded(!expanded);
	};
	const handleSendMailOpen = () => setSendMailOpen(true);
	const handleSendEmailModalClose = () => setSendMailOpen(false);
	const handleCancelCaseModalOpen = () => {
		setCancelCaseModalOpen(true);
		handleTableMenuClose();
	};
	const handleBlockCaseModalOpen = () => {
		setBlockCaseModelOpen(true);
		handleTableMenuClose();
	};
	const handleAssignCaseModalOpen = () => {
		setAssignCaseModalOpen(true);
		handleTableMenuClose();
	};
	const handleBlockCaseModalClose = () => {
		setBlockCaseModelOpen(false);
		handleTableMenuClose();
	};
	const assignCaseModalClose = (isSuccess?: boolean) => {
		if (isSuccess) getDashboardDetails();
		setAssignCaseModalOpen(false);
		handleTableMenuClose();
	};
	const transferCaseModalClose = (isSuccess?: boolean) => {
		setTransferCaseModalOpen(false);
		handleTableMenuClose();
	};
	const cancelCaseModalClose = (isSuccess?: boolean) => {
		if (isSuccess) getDashboardDetails();
		setCancelCaseModalOpen(false);
		handleTableMenuClose();
	};
	const handleOnClickCloseClearCase = () => {
		setClearCaseModalOpen(false);
		handleTableMenuClose();
	};
	const sendAgreementModalClose = () => {
		setSendAgreementModalOpen(false);
		handleTableMenuClose();
	};
	const handleClearCaseModalOpen = () => {
		setClearCaseModalOpen(true);
		handleTableMenuClose();
	};
	const handleSendAgreemenrModalOpen = () => {
		setSendAgreementModalOpen(true);
		handleTableMenuClose();
	};
	const handleOnClickClearCase = () => {
		// TODO: clear case logic here
		setClearCaseModalOpen(false);
		handleTableMenuClose();
	};
	const handleOnClickSendAgreement = () => {
		// TODO: send agreement logic here
		setSendAgreementModalOpen(false);
		handleTableMenuClose();
	};
	const handleOnClickCopy = (e: any, text: string) => {
		console.log(text);
		e.stopPropagation();
		copyTextOnClipBoard(text);
	};

	// Page level variables
	const tableMenuOpen = Boolean(tableUser);

	return (
		<>
			{!isSmallDevice ? (
				<>
					<TableRow
						key={row.requestId}
						className={getTypeWiseClassName(row.requestTypeId)}
					>
						{gridColumnPermissions?.isDisplayName && (
							<TableCell
								component="th"
								style={{ minWidth: 190, maxWidth: 190 }}
								scope="row"
								className="wrap"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.name}
								>
									{row.name}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayEmail && (
							<TableCell
								style={{ maxWidth: 55 }}
								component="th"
								scope="row"
								className="wrap"
							>
								<CustomCopyTooltip text="Send Email">
									<div className="cell-with-icons">
										<IconButton
											className="mail-btn"
											onClick={handleSendMailOpen}
										>
											<img src={MailIcon} alt="email" />
										</IconButton>
									</div>
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayDateOfBirth && (
							<TableCell
								style={{ minWidth: 145, maxWidth: 145 }}
								component="th"
								scope="row"
								className="wrap"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.dateOfBirth}
								>
									{row.dateOfBirth}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayRegion && (
							<TableCell
								style={{ minWidth: 165, maxWidth: 165 }}
								component="th"
								scope="row"
								className="wrap"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.regionName}
								>
									{row.regionName}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayWaitTime && (
							<TableCell
								style={{ minWidth: 100, maxWidth: 100 }}
								component="th"
								scope="row"
								className="wrap"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.waitTime}
								>
									{row.waitTime}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayRequestorName && (
							<TableCell
								style={{ minWidth: 190, maxWidth: 190 }}
								component="th"
								scope="row"
								className="wrap"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.requestor}
								>
									{row.requestor}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayRequestedDate && (
							<TableCell
								style={{ minWidth: 140, maxWidth: 140 }}
								className="wrap"
								component="th"
								scope="row"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.requestedDate}
								>
									{row.requestedDate}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayPhysicianName && (
							<TableCell
								style={{ minWidth: 140, maxWidth: 140 }}
								className="wrap"
								component="th"
								scope="row"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.physicianName}
								>
									{row.physicianName}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{/* Date of service */}
						{gridColumnPermissions?.isDisplayAcceptedDate && (
							<TableCell
								style={{ minWidth: 180, maxWidth: 180 }}
								component="th"
								className="wrap"
								scope="row"
							>
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.acceptedDate}
								>
									{row.acceptedDate}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayPhone && (
							<TableCell
								style={{ minWidth: 200, maxWidth: 200 }}
								component="th"
								scope="row"
							>
								<div className="phone-numbers">
									{row.phone && row.phone?.trim() !== "" ? (
										<Tooltip title="Call">
											<Button variant="outlined" href={`tel:${row.phone}`}>
												<img src={CallIcon} alt="call" />
												{row.phone}
											</Button>
										</Tooltip>
									) : null}
									{row.requestorPhone &&
									row.requestorPhone?.trim() !== "" &&
									row.requestorPhone?.trim() !== row.phone?.trim() ? (
										<Tooltip title="Call">
											<Button
												variant="outlined"
												href={`tel:${row.requestorPhone}`}
											>
												<img src={CallIcon} alt="call" />
												{row.requestorPhone}
											</Button>
										</Tooltip>
									) : null}
								</div>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayAddress && (
							<TableCell className="wrap" component="th" scope="row">
								<CustomCopyTooltip
									canDoCopy={true}
									text="Copy"
									copyText={row.address}
								>
									{row.address}
								</CustomCopyTooltip>
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayRequestStatus && (
							<TableCell
								style={{ minWidth: 110, maxWidth: 110 }}
								component="th"
								className="wrap"
								scope="row"
							>
								{row.requestStatus}
							</TableCell>
						)}
						{gridColumnPermissions?.isDisplayChatWithAdmin ||
						gridColumnPermissions?.isDisplayChatWithPatient ||
						gridColumnPermissions?.isDisplayChatWithPhysician ? (
							<TableCell component="th" scope="row">
								<span className="table-cell-title">Chat With</span>
								<div className="table-cell-btn-group">
									{gridColumnPermissions?.isDisplayChatWithPatient && (
										<Button
											variant="outlined"
											onClick={() =>
												handleOpenChatBox(
													"Receiver Name",
													"senderName",
													1, // Receiver id
													1 // sender id
												)
											}
										>
											<img src={PatientLightIcon} alt="" />
											Patient
										</Button>
									)}
									{gridColumnPermissions?.isDisplayChatWithPhysician && (
										<Button
											disabled={!row.physicianId}
											variant="outlined"
											onClick={() =>
												handleOpenChatBox(
													"Receiver Name",
													"senderName",
													1, // Receiver id
													1 // sender id
												)
											}
										>
											<img src={DoctorLightIcon} alt="" />
											Provider
										</Button>
									)}
								</div>
							</TableCell>
						) : null}
						<TableCell align="center" component="th" scope="row">
							<span className="table-cell-title">Actions</span>
							<Button
								id="table-button"
								aria-controls={tableMenuOpen ? "table-menu" : undefined}
								aria-haspopup="true"
								aria-expanded={tableMenuOpen ? "true" : undefined}
								onClick={handleTableMenu}
								className="action-btn"
							>
								Actions
							</Button>
						</TableCell>
					</TableRow>
				</>
			) : (
				// Mobile view
				<Card className={getTypeWiseClassName(row.requestTypeId)}>
					<div className="card-container">
						<ExpandMore
							expand={expanded}
							onClick={handleExpandClick}
							aria-expanded={expanded}
							aria-label="show more"
						>
							<Button
								id="table-button"
								aria-controls={tableMenuOpen ? "table-menu" : undefined}
								aria-haspopup="true"
								aria-expanded={tableMenuOpen ? "true" : undefined}
								onClick={handleTableMenu}
								className="action-btn"
							>
								Actions
							</Button>
							{gridColumnPermissions?.isDisplayName && (
								<CardHeader
									title={
										<React.Fragment>
											<span>{row.name}</span>
											{row.name && (
												<IconButton
													className="copy-btn"
													onClick={(e) => handleOnClickCopy(e, row.name)}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</React.Fragment>
									}
								/>
							)}
							<CardContent className="card-header-content">
								<div className="card-subheader"></div>
								<div className="card-subheader">
									{gridColumnPermissions?.isDisplayAddress ? (
										<Typography variant="body2" color="text.secondary">
											{row.address}
											{row.address && (
												<IconButton
													className="copy-btn"
													onClick={(e) => handleOnClickCopy(e, row.address)}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									) : (
										<>
											{gridColumnPermissions.isDisplayEmail && (
												<div onClick={handleSendMailOpen}>
													<Typography variant="body2">
														<span
															style={{
																lineBreak: "anywhere",
																textTransform: "lowercase",
															}}
														>
															{row.email}
														</span>
														{row.email && (
															<IconButton
																className="copy-btn"
																onClick={(e) => handleOnClickCopy(e, row.email)}
															>
																<img src={CopyIcon} alt="copy" />
															</IconButton>
														)}
													</Typography>
												</div>
											)}
										</>
									)}
									<ExpandMore
										expand={expanded}
										aria-expanded={expanded}
										aria-label="show more"
									>
										Map Location
									</ExpandMore>
								</div>
								{gridColumnPermissions.isDisplayWaitTime && (
									<Typography>
										<img src={ClockIcon} alt="time" />
										Wait Time:&nbsp;
										{gridColumnPermissions.isDisplayRequestedDate && (
											<span>{row?.requestedDate}</span>
										)}
										<span>&nbsp;({row?.waitTime})&nbsp;</span>
										{row.waitTime && (
											<IconButton
												className="copy-btn"
												onClick={(e) => handleOnClickCopy(e, row.waitTime)}
											>
												<img src={CopyIcon} alt="copy" />
											</IconButton>
										)}
									</Typography>
								)}
							</CardContent>
						</ExpandMore>
						<Collapse in={expanded} timeout="auto" unmountOnExit>
							<CardContent>
								{gridColumnPermissions.isDisplayDateOfBirth && (
									<div>
										<span>
											<img src={CalendarPrimaryIcon} alt="calender" />
										</span>
										<Typography variant="h6">
											Date of birth: &nbsp;
											<span>{row.dateOfBirth}</span>
											{row.dateOfBirth && (
												<IconButton
													className="copy-btn"
													onClick={(e) => handleOnClickCopy(e, row.dateOfBirth)}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								)}
								{gridColumnPermissions.isDisplayEmail &&
								gridColumnPermissions.isDisplayAddress ? (
									<div onClick={handleSendMailOpen}>
										<span>
											<img src={MailIcon} alt="email" />
										</span>
										<Typography variant="h6">
											<span>Email: &nbsp;</span>
											<span>{row.email}</span>
											{row.email && (
												<IconButton
													className="copy-btn"
													onClick={(e) => handleOnClickCopy(e, row.email)}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								) : null}
								{gridColumnPermissions.isDisplayPhone && (
									<div>
										<span>
											<img src={CallIcon} alt="call" />
										</span>
										<Typography variant="h6">
											Patient: &nbsp;
											<span>
												{row.phone?.trim() !== "" && (
													<Box sx={{ display: "flex" }}>
														<span>
															<a href={`tel:${row.phone}`}>{row.phone}</a>
														</span>
														{row.phone && (
															<IconButton
																className="copy-btn"
																onClick={(e) => handleOnClickCopy(e, row.phone)}
															>
																<img src={CopyIcon} alt="copy" />
															</IconButton>
														)}
													</Box>
												)}
												{row.requestorPhone &&
												row.requestorPhone?.trim() !== "" &&
												row.requestorPhone?.trim() !== row.phone?.trim() ? (
													<Box sx={{ display: "flex" }}>
														<span className="requestor-phone">
															<a href={`tel:${row.requestorPhone}`}>
																{row.requestorPhone}
															</a>
														</span>

														<IconButton
															className="copy-btn"
															onClick={(e) =>
																handleOnClickCopy(e, row.requestorPhone)
															}
														>
															<img src={CopyIcon} alt="copy" />
														</IconButton>
													</Box>
												) : null}
											</span>
										</Typography>
									</div>
								)}

								{gridColumnPermissions.isDisplayRequestStatus && (
									<div>
										<span>
											<img src={StatusCheckIcon} alt="check" />
										</span>
										<Typography variant="h6">
											Status: &nbsp; <span>{row.requestStatus}</span>
											{row.requestStatus && (
												<IconButton
													className="copy-btn"
													onClick={(e) =>
														handleOnClickCopy(e, row.requestStatus)
													}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								)}
								{gridColumnPermissions.isDisplayAcceptedDate && (
									<div>
										<span>
											<img src={CalendarPrimaryIcon} alt="calender" />
										</span>
										<Typography variant="h6">
											Date of service: &nbsp;
											<span>{row.acceptedDate}</span>
											{row.acceptedDate && (
												<IconButton
													className="copy-btn"
													onClick={(e) =>
														handleOnClickCopy(e, row.acceptedDate)
													}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								)}

								{gridColumnPermissions.isDisplayPhysicianName && (
									<div>
										<span>
											<img src={PhysicianIcon} alt="check" />
										</span>
										<Typography variant="h6">
											<span>Physician: &nbsp;</span>
											<span>{row.physicianName}</span>
											{row.physicianName && (
												<IconButton
													className="copy-btn"
													onClick={(e) =>
														handleOnClickCopy(e, row.physicianName)
													}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								)}
								{gridColumnPermissions.isDisplayRequestorName && (
									<div>
										<span>
											<img src={RequestorIcon} alt="check" />
										</span>
										<Typography variant="h6">
											<span>Requestor: &nbsp;</span>
											<span>{row.requestor}</span>
											{row.requestor && (
												<IconButton
													className="copy-btn"
													onClick={(e) => handleOnClickCopy(e, row.requestor)}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								)}
								{gridColumnPermissions.isDisplayRegion && (
									<div>
										<span>
											<img src={RegionIcon} alt="check" />
										</span>
										<Typography variant="h6">
											Region: &nbsp; <span>{row.regionName}</span>
											{row.regionName && (
												<IconButton
													className="copy-btn"
													onClick={(e) => handleOnClickCopy(e, row.regionName)}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											)}
										</Typography>
									</div>
								)}
								<div className="table-cell-btn-group">
									{gridColumnPermissions.isDisplayChatWithPatient && (
										<Button
											variant="outlined"
											onClick={() =>
												handleOpenChatBox(
													"Receiver Name",
													"senderName",
													1, // Receiver id
													1 // sender id
												)
											}
										>
											<img src={PatientLightIcon} alt="patient" />
											Patient
										</Button>
									)}
									{gridColumnPermissions.isDisplayChatWithPhysician && (
										<Button
											disabled={!row.physicianId}
											variant="outlined"
											onClick={() =>
												handleOpenChatBox(
													"Receiver Name",
													"senderName",
													1, // Receiver id
													1 // sender id
												)
											}
										>
											<img src={DoctorLightIcon} alt="physician" />
											Provider
										</Button>
									)}
								</div>
							</CardContent>
						</Collapse>
					</div>
				</Card>
			)}
			<DashboardTableRowMenu
				row={row}
				tableMenuOpen={tableMenuOpen}
				tableUser={tableUser}
				handleTableMenuClose={handleTableMenuClose}
				handleBlockCaseModalOpen={handleBlockCaseModalOpen}
				handleAssignCaseModalOpen={handleAssignCaseModalOpen}
				handleCancelCaseModalOpen={handleCancelCaseModalOpen}
				handleClearCaseModalOpen={handleClearCaseModalOpen}
				handleSendAgreemenrModalOpen={handleSendAgreemenrModalOpen}
				gridButtonsPermissions={gridButtonsPermissions}
				searchCriteria={searchCriteria}
			/>

			{/* Page modals */}
			<SendEmailModal
				handleSendEmailModalClose={handleSendEmailModalClose}
				sendMailOpen={sendMailOpen}
				row={row}
			/>
			<BlockCaseModal
				handleBlockCaseModalClose={handleBlockCaseModalClose}
				blockCaseModelOpen={blockCaseModelOpen}
				row={row}
			/>
			{/* Assign Case Modal */}
			<AssignTransferCaseModal
				assignTransferCaseModalClose={assignCaseModalClose}
				assignTransferCaseModalOpen={assignCaseModalOpen}
				isTransfer={false}
				queryString={row?.queryString || ""}
				requestId={row?.requestId || 0}
			/>
			{/* Transfer Case Modal */}
			<AssignTransferCaseModal
				assignTransferCaseModalClose={transferCaseModalClose}
				assignTransferCaseModalOpen={transferCaseModalOpen}
				isTransfer={true}
				queryString={row?.queryString || ""}
				requestId={row?.requestId || 0}
			/>
			<CancelCaseModal
				cancelCaseModalClose={cancelCaseModalClose}
				cancelCaseModalOpen={cancelCaseModalOpen}
				queryString={row.queryString}
				requestId={row.requestId}
			/>
			<WarningModal
				isModalOpen={clearCaseModalOpen}
				handleOnClickCloseModal={handleOnClickCloseClearCase}
				handleOnClickOk={handleOnClickClearCase}
				warningMessage={
					"Are sure you want to clear this request? Once clear this request then you are not able to see this request."
				}
				title={"Confirmation for clear case"}
				okButtonText={"Clear"}
				closeButtonText={"Cancel"}
			/>
			<SendAgreementModal
				row={row}
				isSendAgreementModalOpen={sendAgreementModalOpen}
				sendAgreementModalClose={sendAgreementModalClose}
				handleOnClickSend={handleOnClickSendAgreement}
			/>
		</>
	);
}
