import React, { useContext, useEffect, useState } from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import {
	Box,
	Button,
	FormControl,
	FormHelperText,
	IconButton,
	InputLabel,
	MenuItem,
	Modal,
	Select,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import { CloseWhiteIcon } from "assests/images";
import { useForm } from "react-hook-form";
import { commonModalStyle, createCommonAPICall } from "utility/helpers";
import { assignCaseSchema } from "utility/validations";
import dashboardService from "services/dashboard-service";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { IAssignCaseInfo, IAssignCaseRequest } from "utility/interfaces";

type ComponentProps = {
	assignTransferCaseModalOpen: boolean;
	isTransfer: boolean;
	assignTransferCaseModalClose: any;
	queryString: string;
	requestId: number;
};

export function AssignTransferCaseModal(props: ComponentProps) {
	// Page level interface
	interface IAssignCase {
		region: string;
		physician: string;
		description: string;
	}

	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// useStates
	const [formValues, setFormValues] = useState<IAssignCase>({
		region: "",
		physician: "",
		description: "",
	});

	const [assignCaseModalInfo, setAssignCaseModalInfo] =
		useState<IAssignCaseInfo>({
			physicianList: [],
			regionList: [],
			description: "",
		});

	// Extract Props
	const {
		assignTransferCaseModalOpen,
		assignTransferCaseModalClose,
		isTransfer,
		queryString,
		requestId,
	} = props;

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
		reset,
		clearErrors,
		setValue,
	} = useForm({
		resolver: yupResolver(assignCaseSchema),
	});

	// Events and functions
	const handleFormValueChange = (e: any) => {
		setFormValues({ ...formValues, [e.target.name]: e.target.value });
	};
	const handleOnChangeRegion = (e: any) => {
		setFormValues({ ...formValues, region: e.target.value, physician: "" });
	};
	const handleOnClickSubmit = async () => {
		const request: IAssignCaseRequest = {
			description: formValues.description,
			physicianId: +formValues.physician,
			requestId: queryString,
		};
		const data = await createCommonAPICall({
			requestBody: request,
			apiService: dashboardService.cancelCase,
			showSuccessMessage: true,
			showErrorMessage: true,
			setSuccessErrorContext,
		});
		if (data && data.data) assignTransferCaseModalClose(true);
	};
	const getModalInfo = async () => {
		const data = await createCommonAPICall({
			requestBody: { requestId: queryString },
			apiService: dashboardService.getAssignCaseModalInfo,
			showSuccessMessage: false,
			showErrorMessage: true,
			setSuccessErrorContext,
		});
		if (data && data.isSuccessfull && data.data) {
			console.log("Here");
			const info: IAssignCaseInfo = data.data;
			setAssignCaseModalInfo(info);
			setFormValues({
				region:
					info.regionList
						?.find((region) => region.isSelected)
						?.value?.toString() || "",
				physician:
					info.physicianList
						?.find((phy) => phy.isSelected)
						?.value?.toString() || "",
				description: info.description || "",
			});
			return;
		}
		assignTransferCaseModalClose(false);
	};

	// useEffects
	useEffect(() => {
		reset();
		clearErrors();
		if (assignTransferCaseModalOpen) getModalInfo();
	}, [assignTransferCaseModalOpen]);
	useEffect(() => {
		Object.entries(formValues).forEach((child) => {
			setValue(child[0] as any, child[1] || "");
		});
	}, [formValues]);
	return (
		<>
			<Modal
				open={assignTransferCaseModalOpen}
				onClose={() => assignTransferCaseModalClose(false)}
				className="send-modal select-input-modal"
			>
				<Box sx={commonModalStyle}>
					<Box className="modal-header">
						<Typography variant="h5">
							{isTransfer ? "Transfer Request" : "Assign Request"}
						</Typography>
						<IconButton onClick={() => assignTransferCaseModalClose(false)}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="body1" className="instruction">
								{`To ${
									isTransfer ? "transfer" : "assign"
								} this request, search and select another Physician.`}
							</Typography>
							<FormControl fullWidth>
								<InputLabel id="region-label">
									Narrow Search by Region
								</InputLabel>
								<Select
									autoFocus
									labelId="region-label"
									id="region"
									value={formValues.region}
									name="region"
									label="Narrow Search by Region"
									onChange={handleOnChangeRegion}
								>
									{assignCaseModalInfo?.regionList?.map((region) => {
										return (
											<MenuItem key={region.value} value={region.value}>
												{region.text}
											</MenuItem>
										);
									})}
								</Select>
							</FormControl>
							<FormControl fullWidth>
								<InputLabel id="physician-label">Select Physician</InputLabel>
								<Select
									{...register("physician")}
									labelId="physician-label"
									id="physician"
									value={formValues.physician}
									label="Select Physician"
									name="physician"
									onChange={handleFormValueChange}
									error={errors?.physician?.message ? true : false}
								>
									{assignCaseModalInfo?.physicianList
										?.filter(
											(physician) =>
												physician.parentId.toString() ===
												formValues.region.toString()
										)
										.map((physician) => {
											return (
												<MenuItem key={physician.value} value={physician.value}>
													{physician.text}
												</MenuItem>
											);
										})}
								</Select>
								<FormHelperText error id="component-error-text">
									<>{errors?.physician?.message}</>
								</FormHelperText>
							</FormControl>
							<TextField
								{...register("description")}
								name="description"
								id="block"
								label="Description"
								value={formValues.description}
								multiline
								maxRows={1}
								inputProps={{
									style: { minHeight: "88px" },
								}}
								onChange={handleFormValueChange}
								fullWidth
								error={errors?.description?.message ? true : false}
								helperText={errors?.description?.message?.toString()}
							/>
						</div>
						<div className="modal-footer">
							<Tooltip title="Submit">
								<Button
									variant="contained"
									onClick={handleSubmit(handleOnClickSubmit)}
								>
									Submit
								</Button>
							</Tooltip>
							<Tooltip title="Cancel">
								<Button
									variant="outlined"
									onClick={() => assignTransferCaseModalClose(false)}
								>
									Cancel
								</Button>
							</Tooltip>
						</div>
					</Box>
				</Box>
			</Modal>
		</>
	);
}
