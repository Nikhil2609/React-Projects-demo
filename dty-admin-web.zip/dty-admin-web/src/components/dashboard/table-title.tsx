import React from "react";
import { Box, Button, Tooltip, Typography } from "@mui/material";
import {
	DocRequestIcon,
	ExportallIcon,
	ExportIcon,
	SendIcon,
} from "assests/images";
import { useNavigate } from "react-router-dom";
import { AppRoutings } from "utility/enums/app-routings";
import { getTabStatusWiseName } from "utility/helpers";
import { IDashboardSearchCriteria } from "utility/interfaces";

type ComponentProps = {
	handleClickSendLink: any;
	handleClickExport: any;
	handleClickExportAll: any;
	searchCriteria: IDashboardSearchCriteria;
};

export function DashboardTableTitle(props: ComponentProps) {
	// Extract Props
	const {
		handleClickSendLink,
		handleClickExport,
		handleClickExportAll,
		searchCriteria,
	} = props;

	// Page level local variables
	const navigate = useNavigate();

	return (
		<Box className="tab-item-header">
			<Typography variant="h2">
				Patients{" "}
				<span className="new">
					&nbsp;&#40;{getTabStatusWiseName(searchCriteria.RequestStatusId)}&#41;
				</span>
			</Typography>
			<Box className="tab-button-groups">
				<Tooltip title="Send Link">
					<Button variant="contained" onClick={handleClickSendLink}>
						<img src={SendIcon} alt="send link" />
						<span className="button-link">Send Link </span>
					</Button>
				</Tooltip>
				<Tooltip title="Create Requests">
					<Button
						variant="contained"
						onClick={() => {
							navigate(AppRoutings.CreateRequest, {
								state: {
									searchCriteria,
								},
							});
						}}
					>
						<img src={DocRequestIcon} alt="Create Request" />
						<span className="button-link">Create Requests</span>
					</Button>
				</Tooltip>
				<Tooltip title="Export">
					<Button variant="contained" onClick={handleClickExport}>
						<img src={ExportIcon} alt="export" />
						<span className="button-link">Export</span>
					</Button>
				</Tooltip>
				<Tooltip title="Export All">
					<Button variant="contained">
						<img
							src={ExportallIcon}
							alt="export"
							onClick={handleClickExportAll}
						/>
						<span className="button-link">Export All</span>
					</Button>
				</Tooltip>
			</Box>
		</Box>
	);
}
