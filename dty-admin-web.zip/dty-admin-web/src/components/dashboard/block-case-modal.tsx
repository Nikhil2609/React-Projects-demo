import { yupResolver } from "@hookform/resolvers/yup";
import {
	Box,
	Button,
	IconButton,
	Modal,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import { CloseWhiteIcon } from "assests/images";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { commonModalStyle } from "utility/helpers";
import { blockRequestSchema } from "utility/validations";

type ComponentProps = {
	blockCaseModelOpen: boolean;
	handleBlockCaseModalClose: any;
	row: any;
};

export function BlockCaseModal(props: ComponentProps) {
	// Usestates
	const [reason, setReason] = useState("");

	// Extract Props
	const { blockCaseModelOpen, handleBlockCaseModalClose, row } = props;

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
		clearErrors,
		reset,
	} = useForm({
		resolver: yupResolver(blockRequestSchema),
	});

	// Events and functions
	const handleOnClickConfirm = () => {
		console.log(row.email, reason);
		setReason("");
		handleBlockCaseModalClose();
	};

	// useEffects
	useEffect(() => {
		reset();
		clearErrors();
		setReason("");
	}, [blockCaseModelOpen]);

	return (
		<>
			<Modal
				open={blockCaseModelOpen}
				onClose={handleBlockCaseModalClose}
				className="send-modal"
			>
				<Box sx={commonModalStyle}>
					<Box className="modal-header">
						<Typography variant="h5">Confirm Block</Typography>
						<IconButton onClick={handleBlockCaseModalClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="h6" className="patient-name">
								Patient Name :&nbsp;
								<span>{row.name}</span>
							</Typography>
							<TextField
								{...register("reason")}
								id="block"
								label="Reason for Block Request"
								value={reason}
								onChange={(e) => setReason(e.target.value)}
								multiline
								maxRows={1}
								inputProps={{
									style: { minHeight: "88px" },
								}}
								fullWidth
								error={errors?.reason?.message ? true : false}
								helperText={errors?.reason?.message?.toString()}
							/>
						</div>
						<div className="modal-footer">
							<Tooltip title="Confirm">
								<Button
									variant="contained"
									onClick={handleSubmit(handleOnClickConfirm)}
								>
									Confirm
								</Button>
							</Tooltip>
							<Tooltip title="Cancel">
								<Button variant="outlined" onClick={handleBlockCaseModalClose}>
									Cancel
								</Button>
							</Tooltip>
						</div>
					</Box>
				</Box>
			</Modal>
		</>
	);
}
