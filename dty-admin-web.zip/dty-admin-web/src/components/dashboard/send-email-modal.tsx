import { yupResolver } from "@hookform/resolvers/yup";
import {
	Box,
	Button,
	IconButton,
	Modal,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import { CloseWhiteIcon } from "assests/images";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { commonModalStyle } from "utility/helpers";
import { sendEmailSchema } from "utility/validations";
import myCustomTheme from "app.theme";
import { CustomCopyTooltip } from "components";

type ComponentProps = {
	sendMailOpen: boolean;
	handleSendEmailModalClose: any;
	row: any;
};

export function SendEmailModal(props: ComponentProps) {
	// Usestates
	const [message, setMessage] = useState("");

	// Extract Props
	const { sendMailOpen, handleSendEmailModalClose, row } = props;

	// Yup resolver
	const {
		register,
		handleSubmit,
		reset,
		clearErrors,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(sendEmailSchema),
	});

	// Handled events and functions
	const handleOnClickConfirm = () => {
		setMessage("");
		handleSendEmailModalClose();
	};

	// useEffects
	useEffect(() => {
		reset();
		clearErrors();
		setMessage("");
	}, [sendMailOpen]);

	return (
		<>
			<Modal
				open={sendMailOpen}
				onClose={handleSendEmailModalClose}
				className="send-modal"
			>
				<Box sx={commonModalStyle}>
					<Box className="modal-header">
						<Typography variant="h5">Send Mail</Typography>
						<IconButton onClick={handleSendEmailModalClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="h6" className="patient-name">
								<Box
									sx={{
										minWidth: 125,
										[myCustomTheme.breakpoints.down("sm")]: {
											minWidth: "110px",
										},
									}}
								>
									Patient Name :&nbsp;
								</Box>
								<Box className="name">
									<span>{row.name}</span>
									<CustomCopyTooltip
										canDoCopy={true}
										text="Copy"
										copyText={row.email}
									>
										<span className="email-wrapper">
											&#40;<span>{row.email}</span>&#41;
										</span>
									</CustomCopyTooltip>
								</Box>
							</Typography>
							<TextField
								{...register("message")}
								id="block"
								label="Message"
								value={message}
								onChange={(e) => setMessage(e.target.value)}
								multiline
								maxRows={1}
								inputProps={{
									style: { minHeight: "88px" },
								}}
								fullWidth
								error={errors?.message?.message ? true : false}
								helperText={errors?.message?.message?.toString()}
							/>
						</div>
						<div className="modal-footer">
							<Tooltip title="Confirm">
								<Button
									variant="contained"
									onClick={handleSubmit(handleOnClickConfirm)}
								>
									Confirm
								</Button>
							</Tooltip>
							<Tooltip title="Cancel">
								<Button variant="outlined" onClick={handleSendEmailModalClose}>
									Cancel
								</Button>
							</Tooltip>
						</div>
					</Box>
				</Box>
			</Modal>
		</>
	);
}
