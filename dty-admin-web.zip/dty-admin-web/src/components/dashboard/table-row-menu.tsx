import React from "react";
import { Link, Menu, MenuItem } from "@mui/material";
import {
	AnalysisDarkIcon,
	AnalysisIcon,
	BlockDarkIcon,
	BlockIcon,
	DocnotesIcon,
	DocnotesIconDark,
	ErrorDarkIcon,
	ErrorDarkModeIcon,
	NotesDarkIcon,
	NotesIcon,
	OrdersIcon,
	OrdersIconDark,
	TasksDarkIcon,
	TasksIcon,
	UploadfileIcon,
	UploadfileIconDark,
	HeartbeatIcon,
	HeartbeatIconDark,
	ClearCaseDarkIcon,
	ClearCaseIcon,
} from "assests/images";
import { useNavigate } from "react-router-dom";
import { AppRoutings } from "utility/enums/app-routings";
import {
	IRequest,
	IGridButtons,
	IDashboardSearchCriteria,
} from "utility/interfaces";
import { getTabStatusWiseName } from "utility/helpers";

type ComponentProps = {
	row: IRequest;
	tableMenuOpen: boolean;
	tableUser: any;
	handleTableMenuClose: any;
	handleBlockCaseModalOpen: any;
	handleAssignCaseModalOpen: any;
	handleCancelCaseModalOpen: any;
	handleClearCaseModalOpen: any;
	handleSendAgreemenrModalOpen: any;
	gridButtonsPermissions: IGridButtons;
	searchCriteria: IDashboardSearchCriteria;
};

export function DashboardTableRowMenu(props: ComponentProps) {
	// Page level variables
	const navigate = useNavigate();

	// Extract Props
	const {
		row,
		tableMenuOpen,
		tableUser,
		handleTableMenuClose,
		handleBlockCaseModalOpen,
		handleAssignCaseModalOpen,
		handleCancelCaseModalOpen,
		gridButtonsPermissions,
		handleClearCaseModalOpen,
		handleSendAgreemenrModalOpen,
		searchCriteria,
	} = props;

	return (
		<Menu
			id="table-menu"
			anchorEl={tableUser}
			open={tableMenuOpen}
			className="new-table-menu"
			onClose={handleTableMenuClose}
			anchorOrigin={{
				vertical: "bottom",
				horizontal: "right",
			}}
			transformOrigin={{
				vertical: "top",
				horizontal: "right",
			}}
		>
			{gridButtonsPermissions.isViewCase ? (
				<MenuItem
					onClick={() => {
						navigate(AppRoutings.ViewCase.replace(":caseId", row.queryString), {
							state: {
								backURL: AppRoutings.Dashboard.replace(
									":tabStatus",
									getTabStatusWiseName(
										searchCriteria?.RequestStatusId
									).toLocaleLowerCase()
								),
								searchCriteria,
							},
						});
					}}
				>
					<Link>
						<img src={AnalysisIcon} alt="analysis" className="light-icon" />
						<img src={AnalysisDarkIcon} alt="analysis" className="dark-icon" />
						View Case
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isViewUploads ? (
				<MenuItem
					onClick={() => {
						navigate(
							AppRoutings.ViewUploads.replace(":caseId", row.queryString),
							{
								state: {
									backURL: AppRoutings.Dashboard.replace(
										":tabStatus",
										getTabStatusWiseName(
											searchCriteria?.RequestStatusId
										).toLocaleLowerCase()
									),
									searchCriteria,
								},
							}
						);
					}}
				>
					<Link>
						<img src={UploadfileIcon} alt="files" className="light-icon" />
						<img src={UploadfileIconDark} alt="files" className="dark-icon" />
						View Uploads
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isViewNotes ? (
				<MenuItem
					onClick={() => {
						navigate(
							AppRoutings.ViewNotes.replace(":caseId", row.queryString),
							{
								state: {
									searchCriteria,
									backURL: AppRoutings.Dashboard.replace(
										":tabStatus",
										getTabStatusWiseName(
											searchCriteria?.RequestStatusId
										).toLocaleLowerCase()
									),
								},
							}
						);
					}}
				>
					<Link>
						<img src={NotesIcon} alt="notes" className="light-icon" />
						<img src={NotesDarkIcon} alt="notes" className="dark-icon" />
						View Notes
					</Link>
				</MenuItem>
			) : null}

			{gridButtonsPermissions.isOrders ? (
				<MenuItem
					onClick={() => {
						navigate(AppRoutings.Orders.replace(":caseId", row.queryString), {
							state: {
								searchCriteria,
								backURL: AppRoutings.Dashboard.replace(
									":tabStatus",
									getTabStatusWiseName(
										searchCriteria?.RequestStatusId
									).toLocaleLowerCase()
								),
							},
						});
					}}
				>
					<Link>
						<img src={OrdersIcon} alt="orders" className="light-icon" />
						<img src={OrdersIconDark} alt="notes" className="dark-icon" />
						Orders
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isCancelCase ? (
				<MenuItem onClick={handleCancelCaseModalOpen}>
					<Link>
						<img src={ErrorDarkIcon} alt="error" className="light-icon" />
						<img src={ErrorDarkModeIcon} alt="error" className="dark-icon" />
						Cancel Case
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isAssignCase ? (
				<MenuItem onClick={handleAssignCaseModalOpen}>
					<Link>
						<img src={TasksIcon} alt="tasks" className="light-icon" />
						<img src={TasksDarkIcon} alt="tasks" className="dark-icon" />
						Assign Case
					</Link>
				</MenuItem>
			) : null}

			{gridButtonsPermissions.isBlockCase ? (
				<MenuItem onClick={handleBlockCaseModalOpen}>
					<Link>
						<img src={BlockIcon} alt="error" className="light-icon" />
						<img src={BlockDarkIcon} alt="error" className="dark-icon" />
						Block Case
					</Link>
				</MenuItem>
			) : null}

			{gridButtonsPermissions.isConcludeCare ? (
				<MenuItem
					onClick={() => {
						navigate(
							AppRoutings.ConcludeCare.replace(":caseId", row.queryString),
							{
								state: {
									searchCriteria,
									backURL: AppRoutings.Dashboard.replace(
										":tabStatus",
										getTabStatusWiseName(
											searchCriteria?.RequestStatusId
										).toLocaleLowerCase()
									),
								},
							}
						);
					}}
				>
					<Link>
						<img src={HeartbeatIcon} alt="heart-beat" className="light-icon" />
						<img
							src={HeartbeatIconDark}
							alt="heart-beat"
							className="dark-icon"
						/>
						Conclude Care
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isCloseCase ? (
				<MenuItem
					onClick={() => {
						navigate(
							AppRoutings.CloseCase.replace(":caseId", row.queryString),
							{
								state: {
									searchCriteria,
									backURL: AppRoutings.Dashboard.replace(
										":tabStatus",
										getTabStatusWiseName(
											searchCriteria?.RequestStatusId
										).toLocaleLowerCase()
									),
								},
							}
						);
					}}
				>
					<Link>
						<img src={ErrorDarkIcon} alt="error" className="light-icon" />
						<img src={ErrorDarkModeIcon} alt="error" className="dark-icon" />
						Close Case
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isDoctorNotes ? (
				<MenuItem
					onClick={() =>
						navigate(
							AppRoutings.DoctorsNote.replace(":caseId", row.queryString),
							{
								state: {
									searchCriteria,
									backURL: AppRoutings.Dashboard.replace(
										":tabStatus",
										getTabStatusWiseName(
											searchCriteria?.RequestStatusId
										).toLocaleLowerCase()
									),
								},
							}
						)
					}
				>
					<Link>
						<img src={DocnotesIcon} alt="notes" className="light-icon" />
						<img src={DocnotesIconDark} alt="notes" className="dark-icon" />
						Doctors Note
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isClear ? (
				<MenuItem onClick={handleClearCaseModalOpen}>
					<Link>
						<img src={ClearCaseIcon} alt="notes" className="light-icon" />
						<img src={ClearCaseDarkIcon} alt="notes" className="dark-icon" />
						Clear Case
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isSendAgreement ? (
				<MenuItem onClick={handleSendAgreemenrModalOpen}>
					<Link>
						<img src={DocnotesIcon} alt="notes" className="light-icon" />
						<img src={DocnotesIconDark} alt="notes" className="dark-icon" />
						Send Agreement
					</Link>
				</MenuItem>
			) : null}
			{gridButtonsPermissions.isEncounter ? (
				<MenuItem
					onClick={() =>
						navigate(
							AppRoutings.Encounter.replace(":caseId", row.queryString),
							{
								state: {
									searchCriteria,
									backURL: AppRoutings.Dashboard.replace(
										":tabStatus",
										getTabStatusWiseName(
											searchCriteria?.RequestStatusId
										).toLocaleLowerCase()
									),
								},
							}
						)
					}
				>
					<Link>
						<img src={DocnotesIcon} alt="notes" className="light-icon" />
						<img src={DocnotesIconDark} alt="notes" className="dark-icon" />
						Encounter
					</Link>
				</MenuItem>
			) : null}
		</Menu>
	);
}
