import { yupResolver } from "@hookform/resolvers/yup";
import {
	Box,
	Button,
	IconButton,
	Modal,
	TextField,
	Typography,
} from "@mui/material";
import { CloseWhiteIcon } from "assests/images";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { commonModalStyle, getTypeWiseClassName } from "utility/helpers";
import { IRequest } from "utility/interfaces";
import { sendAgreementSchema } from "utility/validations";

type ComponentProps = {
	isSendAgreementModalOpen: boolean;
	sendAgreementModalClose: any;
	handleOnClickSend: any;
	row: IRequest;
};

export function SendAgreementModal(props: ComponentProps) {
	// Page level interface
	interface ISendAgreement {
		phoneNumber: string;
		email: string;
	}

	// useStates
	const [formValues, setFormValues] = useState<ISendAgreement>({
		phoneNumber: "",
		email: "",
	});

	const resetFormValue = () => {
		setFormValues({
			phoneNumber: "",
			email: "",
		});
	};

	// Extract Props
	const {
		isSendAgreementModalOpen,
		sendAgreementModalClose,
		handleOnClickSend,
		row,
	} = props;

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
		reset,
		clearErrors,
	} = useForm({
		resolver: yupResolver(sendAgreementSchema),
	});

	// useEffects
	useEffect(() => {
		reset();
		clearErrors();
		resetFormValue();
	}, [isSendAgreementModalOpen]);

	// Events and functions
	const handleFormValueChange = (e: any) => {
		setFormValues({ ...formValues, [e.target.name]: e.target.value });
	};

	return (
		<>
			<Modal
				open={isSendAgreementModalOpen}
				onClose={sendAgreementModalClose}
				className="send-modal select-input-modal"
			>
				<Box sx={commonModalStyle}>
					<Box className="modal-header">
						<Typography variant="h5">Send Agreement</Typography>
						<IconButton onClick={sendAgreementModalClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<div>
								<Typography className="agreement-modal-type">
									{/* TODO: Dynamic setup */}
									<span className={getTypeWiseClassName(2)}></span>
									Test
								</Typography>
							</div>
							<Typography variant="body1" className="instruction">
								To Send Agreement please make sure you are updating the correct
								contact information below for the responsible party.
							</Typography>
							<TextField
								{...register("phoneNumber")}
								name="phoneNumber"
								id="block"
								label="Phone Number"
								type="number"
								value={formValues.phoneNumber}
								onChange={handleFormValueChange}
								fullWidth
								error={errors?.phoneNumber?.message ? true : false}
								helperText={errors?.phoneNumber?.message?.toString()}
							/>
							<TextField
								{...register("email")}
								name="email"
								id="block"
								label="Email"
								value={formValues.email}
								onChange={handleFormValueChange}
								fullWidth
								error={errors?.email?.message ? true : false}
								helperText={errors?.email?.message?.toString()}
							/>
						</div>
						<div className="modal-footer">
							<Button
								variant="contained"
								onClick={handleSubmit(handleOnClickSend)}
							>
								Send
							</Button>
							<Button variant="outlined" onClick={sendAgreementModalClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
		</>
	);
}
