import React from "react";
import {
	Box,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	Typography,
} from "@mui/material";
import { IRegionInfo, IRegionSearchCriteria } from "utility/interfaces";
import { SortOrder } from "utility/enums/sort-order";
import {
	RegionTableRowData,
	TablePagination,
	RegionTableSearch,
} from "components";

type ComponentProps = {
	searchCriteria: IRegionSearchCriteria;
	handleOnSearchCriteriaChange: any;
	regionPageInfo: IRegionInfo | null;
};

export function RegionTable(props: ComponentProps) {
	// Extract Props
	const { searchCriteria, handleOnSearchCriteriaChange, regionPageInfo } =
		props;

	// Handled events and functions
	const handleOnPageNumberChange = (value: number) => {
		handleOnSearchCriteriaChange({ ...searchCriteria, PageIndexId: value });
	};
	const handleOnChangeSortDirection = (sortBy: string) => {
		handleOnSearchCriteriaChange({
			...searchCriteria,
			SortBy: sortBy,
			SortOrder:
				searchCriteria.SortOrder === SortOrder.ascending
					? SortOrder.descending
					: SortOrder.ascending,
		});
	};

	return (
		<Box className="table-box">
			<RegionTableSearch
				handleOnSearchCriteriaChange={handleOnSearchCriteriaChange}
				searchCriteria={searchCriteria}
			/>
			{regionPageInfo && regionPageInfo?.totalRecords > 0 ? (
				<>
					<TableContainer sx={{ display: { xs: "none", sm: "block" } }}>
						<Table>
							<TableHead>
								<TableRow>
									{regionPageInfo?.gridColumns?.isDisplayWaitTime && (
										<TableCell sx={{ minWidth: 130, maxWidth: 130 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "waitTime"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("waitTime")}
											>
												Wait Time
											</TableSortLabel>
										</TableCell>
									)}
									{regionPageInfo?.gridColumns?.isDisplayClientMember && (
										<TableCell sx={{ minWidth: 170, maxWidth: 170 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "clientMember"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("clientMember")
												}
											>
												Client/Member
											</TableSortLabel>
										</TableCell>
									)}
									{regionPageInfo?.gridColumns?.isDisplayBusiness && (
										<TableCell sx={{ minWidth: 150, maxWidth: 150 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "business"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("business")}
											>
												Business
											</TableSortLabel>
										</TableCell>
									)}
									{regionPageInfo?.gridColumns?.isDisplayAddress && (
										<TableCell sx={{ minWidth: 200 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "address"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() => handleOnChangeSortDirection("address")}
											>
												Address
											</TableSortLabel>
										</TableCell>
									)}
									{regionPageInfo?.gridColumns?.isDisplayRequestStatus && (
										<TableCell sx={{ minWidth: 130, maxWidth: 130 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "requestStatus"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("requestStatus")
												}
											>
												Status
											</TableSortLabel>
										</TableCell>
									)}
									{regionPageInfo?.gridColumns?.isDisplayPhysician && (
										<TableCell sx={{ minWidth: 200, maxWidth: 200 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "physicianName"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("physicianName")
												}
											>
												Physician
											</TableSortLabel>
										</TableCell>
									)}
									{regionPageInfo?.gridColumns?.isDisplayRegion && (
										<TableCell sx={{ minWidth: 100, maxWidth: 100 }}>
											<TableSortLabel
												active={searchCriteria.SortBy === "regionName"}
												direction={
													searchCriteria.SortOrder === SortOrder.ascending
														? "asc"
														: "desc"
												}
												onClick={() =>
													handleOnChangeSortDirection("regionName")
												}
											>
												Region
											</TableSortLabel>
										</TableCell>
									)}
									<TableCell align="center" sx={{ minWidth: 110 }}>
										Actions
									</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{regionPageInfo?.requests?.map((row, index) => (
									<RegionTableRowData
										key={index}
										row={row}
										isSmallDevice={false}
										gridButtonsPermissions={regionPageInfo.gridButtons}
										gridColumnPermissions={regionPageInfo.gridColumns}
										searchCriteria={searchCriteria}
									/>
								))}
							</TableBody>
						</Table>
					</TableContainer>
					<Box
						sx={{ display: { xs: "block", sm: "none" } }}
						className="tabledata-cards-group"
					>
						{regionPageInfo?.requests?.map((row, index) => (
							<RegionTableRowData
								key={index}
								row={row}
								isSmallDevice={true}
								gridButtonsPermissions={regionPageInfo.gridButtons}
								gridColumnPermissions={regionPageInfo.gridColumns}
								searchCriteria={searchCriteria}
							/>
						))}
					</Box>
					<TablePagination
						currentPageNumber={searchCriteria.PageIndexId}
						handleOnPageNumberChange={handleOnPageNumberChange}
						totalRecords={regionPageInfo?.totalRecords || 0}
						rowCount={regionPageInfo?.requests?.length || 0}
					/>
				</>
			) : (
				<Typography variant="h5" sx={{ padding: 3 }}>
					No Record(s) Found{" "}
				</Typography>
			)}
		</Box>
	);
}
