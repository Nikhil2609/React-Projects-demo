import {
	Button,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import React, { useState } from "react";
import { IDropDownList, IMyProfileInfo } from "utility/interfaces";

type ComponentProps = {
	formValues: IMyProfileInfo;
	handleOnChangeFormValue: any;
};

export function AccountInformation(props: ComponentProps) {
	// Extract Props
	const { formValues, handleOnChangeFormValue } = props;

	// useStates
	const [isEditAccountInformation, setIsEditAccountInformation] =
		useState(false);
	const [roleList, setRoleList] = useState<IDropDownList[]>([
		{
			text: "Role 1",
			value: 1,
		},
		{
			text: "Role 2",
			value: 2,
		},
		{
			text: "Role 3",
			value: 3,
		},
	]);
	const [statusList, setStatusList] = useState<IDropDownList[]>([
		{
			text: "Status 1",
			value: 1,
		},
		{
			text: "Status 2",
			value: 2,
		},
		{
			text: "Status 3",
			value: 3,
		},
	]);

	// TODO: Dynamic value

	// Handled events and functions

	// useEffects

	return (
		<>
			<Typography variant="h4">Account Information</Typography>
			<div>
				<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAccountInformation}
							fullWidth
							id="user-name"
							label="User Name"
							variant="outlined"
							name="userName"
							value={formValues.userName}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAccountInformation}
							fullWidth
							id="password"
							label="Password"
							variant="outlined"
							name="password"
							value={formValues.password}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<FormControl fullWidth className="select-input">
							<InputLabel id="status-label">Status</InputLabel>
							<Select
								disabled={!isEditAccountInformation}
								labelId="status"
								id="status"
								value={formValues?.status}
								label="Status"
								name="status"
								onChange={handleOnChangeFormValue}
								MenuProps={{
									className: "select-input-modal",
								}}
							>
								{statusList?.map((status) => {
									return (
										<MenuItem key={status.value} value={status.value}>
											{status.text}
										</MenuItem>
									);
								})}
							</Select>
						</FormControl>
					</Grid>
					<Grid item xs={12} sm={6}>
						<FormControl fullWidth className="select-input">
							<InputLabel id="role-label">Role</InputLabel>
							<Select
								disabled={!isEditAccountInformation}
								labelId="role"
								id="role"
								value={formValues?.role}
								label="Role"
								name="role"
								onChange={handleOnChangeFormValue}
								MenuProps={{
									className: "select-input-modal",
								}}
							>
								{roleList?.map((role) => {
									return (
										<MenuItem key={role.value} value={role.value}>
											{role.text}
										</MenuItem>
									);
								})}
							</Select>
						</FormControl>
					</Grid>
				</Grid>
			</div>
			<div className="request-btn-group">
				{isEditAccountInformation ? (
					<>
						<Tooltip title="Save">
							<Button
								// onClick={handleSubmit(handleOnclickSave)}
								variant="contained"
							>
								Save
							</Button>
						</Tooltip>
						<Tooltip title="Cancel">
							<Button
								variant="outlined"
								onClick={() => {
									setIsEditAccountInformation(false);
								}}
							>
								Cancel
							</Button>
						</Tooltip>
					</>
				) : (
					<>
						<Tooltip title="Edit">
							<Button
								variant="contained"
								onClick={() => {
									setIsEditAccountInformation(true);
								}}
							>
								Edit
							</Button>
						</Tooltip>
						<Tooltip title="Reset Password">
							<Button variant="outlined">Reset Password</Button>
						</Tooltip>
					</>
				)}
			</div>
		</>
	);
}
