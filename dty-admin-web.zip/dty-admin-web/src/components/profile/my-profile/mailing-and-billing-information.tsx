import {
	Button,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import React, { useState } from "react";
import { IDropDownList, IMyProfileInfo } from "utility/interfaces";

type ComponentProps = {
	formValues: IMyProfileInfo;
	handleOnChangeFormValue: any;
};

export function MailingAndBillingInformation(props: ComponentProps) {
	// Extract Props
	const { formValues, handleOnChangeFormValue } = props;

	// useStates
	// TODO: Dynamic Value
	const [stateList, setStateList] = useState<IDropDownList[]>([
		{
			text: "State 1",
			value: 1,
		},
		{
			text: "State 2",
			value: 2,
		},
		{
			text: "State 3",
			value: 3,
		},
	]);
	const [isEditBillingInformation, setIsEditBillingInformation] =
		useState(false);

	return (
		<>
			<Typography variant="h4">Mailing & Billing Information</Typography>
			<div>
				<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditBillingInformation}
							id="address-1"
							label="Address 1"
							value={formValues.address1}
							name="address1"
							onChange={handleOnChangeFormValue}
							fullWidth
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditBillingInformation}
							id="block"
							label="Address 2"
							value={formValues.address2}
							name="address2"
							onChange={handleOnChangeFormValue}
							fullWidth
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditBillingInformation}
							fullWidth
							id="city"
							label="City"
							variant="outlined"
							name="city"
							value={formValues.city}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<FormControl fullWidth className="select-input">
							<InputLabel id="state-label">State</InputLabel>
							<Select
								disabled={!isEditBillingInformation}
								labelId="state"
								id="state"
								value={formValues?.state}
								label="State"
								name="state"
								onChange={handleOnChangeFormValue}
								MenuProps={{
									className: "select-input-modal",
								}}
							>
								{stateList?.map((state) => {
									return (
										<MenuItem key={state.value} value={state.value}>
											{state.text}
										</MenuItem>
									);
								})}
							</Select>
						</FormControl>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditBillingInformation}
							fullWidth
							id="zip"
							label="Zip"
							variant="outlined"
							name="zip"
							value={formValues.zip}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditBillingInformation}
							fullWidth
							id="alt-phone"
							label="Alternative Phone"
							variant="outlined"
							name="alternativePhone"
							value={formValues.alternativePhone}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
				</Grid>
			</div>
			<div className="request-btn-group">
				{isEditBillingInformation ? (
					<>
						<Tooltip title="Save">
							<Button
								// onClick={handleSubmit(handleOnclickSave)}
								variant="contained"
							>
								Save
							</Button>
						</Tooltip>
						<Tooltip title="Cancel">
							<Button
								variant="outlined"
								onClick={() => {
									setIsEditBillingInformation(false);
								}}
							>
								Cancel
							</Button>
						</Tooltip>
					</>
				) : (
					<>
						<Tooltip title="Edit">
							<Button
								variant="contained"
								onClick={() => {
									setIsEditBillingInformation(true);
								}}
							>
								Edit
							</Button>
						</Tooltip>
					</>
				)}
			</div>
		</>
	);
}
