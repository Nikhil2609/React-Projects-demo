import {
	Button,
	FormControl,
	FormControlLabel,
	FormGroup,
	Grid,
	TextField,
	Tooltip,
	Typography,
	Checkbox,
} from "@mui/material";
import { CheckIcon, UncheckIcon } from "assests/images";
import React, { useState } from "react";
import { IMyProfileInfo } from "utility/interfaces";

type ComponentProps = {
	formValues: IMyProfileInfo;
	handleOnChangeFormValue: any;
	handleOnCheckBoxCLick: any;
};

export function AdministratorInformation(props: ComponentProps) {
	// Extract Props
	const { formValues, handleOnChangeFormValue, handleOnCheckBoxCLick } = props;

	// useStates
	const [isEditAdministratorInformation, setIsEditAdministratorInformation] =
		useState(false);

	// Handled events and functions
	function CheckBoxIcon() {
		return <img src={UncheckIcon} alt="checkbox" />;
	}
	function CheckedBoxIcon() {
		return <img src={CheckIcon} alt="checkbox" />;
	}

	return (
		<>
			<Typography variant="h4">Administrator Information</Typography>
			<div>
				<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAdministratorInformation}
							fullWidth
							id="first-name"
							label="First Name"
							variant="outlined"
							name="firstName"
							value={formValues.firstName}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAdministratorInformation}
							fullWidth
							id="last-name"
							label="Last Name"
							variant="outlined"
							name="lastName"
							value={formValues.lastName}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAdministratorInformation}
							fullWidth
							id="email"
							label="Email"
							variant="outlined"
							name="email"
							value={formValues.email}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAdministratorInformation}
							fullWidth
							id="confirm-email"
							label="Confirm Email"
							variant="outlined"
							name="confirmEmail"
							value={formValues.confirmEmail}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<TextField
							disabled={!isEditAdministratorInformation}
							fullWidth
							id="mobile-number"
							label="Mobile Number"
							variant="outlined"
							name="mobileNumber"
							value={formValues.mobileNumber}
							onChange={handleOnChangeFormValue}
						/>
					</Grid>
					<Grid item xs={12} sm={6}>
						<FormControl component="fieldset" className="radio-inputs">
							<FormGroup row>
								<FormControlLabel
									value="end"
									control={
										<Checkbox
											disableFocusRipple
											disabled={!isEditAdministratorInformation}
											disableRipple
											icon={<CheckBoxIcon />}
											checked={formValues.districtOfColumbia}
											onChange={() =>
												handleOnCheckBoxCLick(
													"districtOfColumbia",
													!formValues.districtOfColumbia
												)
											}
											checkedIcon={<CheckedBoxIcon />}
										/>
									}
									label="District Of Columbia"
									labelPlacement="end"
								/>
								<FormControlLabel
									value="end"
									control={
										<Checkbox
											disabled={!isEditAdministratorInformation}
											disableFocusRipple
											disableRipple
											checked={formValues.newYork}
											onChange={() =>
												handleOnCheckBoxCLick("newYork", !formValues.newYork)
											}
											icon={<CheckBoxIcon />}
											checkedIcon={<CheckedBoxIcon />}
										/>
									}
									label="New York"
									labelPlacement="end"
								/>
								<FormControlLabel
									value="end"
									control={
										<Checkbox
											disabled={!isEditAdministratorInformation}
											disableFocusRipple
											disableRipple
											checked={formValues.virginia}
											onChange={() =>
												handleOnCheckBoxCLick("virginia", !formValues.virginia)
											}
											icon={<CheckBoxIcon />}
											checkedIcon={<CheckedBoxIcon />}
										/>
									}
									label="Virginia"
									labelPlacement="end"
								/>
								<FormControlLabel
									value="end"
									control={
										<Checkbox
											disabled={!isEditAdministratorInformation}
											disableFocusRipple
											disableRipple
											checked={formValues.maryland}
											onChange={() =>
												handleOnCheckBoxCLick("maryland", !formValues.maryland)
											}
											icon={<CheckBoxIcon />}
											checkedIcon={<CheckedBoxIcon />}
										/>
									}
									label="Maryland"
									labelPlacement="end"
								/>
							</FormGroup>
						</FormControl>
					</Grid>
				</Grid>
			</div>

			<div className="request-btn-group">
				{isEditAdministratorInformation ? (
					<>
						<Tooltip title="Save">
							<Button
								// onClick={handleSubmit(handleOnclickSave)}
								variant="contained"
							>
								Save
							</Button>
						</Tooltip>
						<Tooltip title="Cancel">
							<Button
								variant="outlined"
								onClick={() => {
									setIsEditAdministratorInformation(false);
								}}
							>
								Cancel
							</Button>
						</Tooltip>
					</>
				) : (
					<>
						<Tooltip title="Edit">
							<Button
								variant="contained"
								onClick={() => {
									setIsEditAdministratorInformation(true);
								}}
							>
								Edit
							</Button>
						</Tooltip>
					</>
				)}
			</div>
		</>
	);
}
