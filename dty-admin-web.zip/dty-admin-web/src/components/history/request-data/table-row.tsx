import React, { useState } from "react";
import {
	Button,
	TableCell,
	TableRow,
	ButtonProps,
	Card,
	CardContent,
	Typography,
	Collapse,
	CardHeader,
} from "@mui/material";
import {
	CalendarIcon,
	CheckIcon,
	MailPrimaryIcon,
	PhonePrimaryIcon,
	UncheckIcon,
} from "assests/images";
import { styled } from "@mui/material/styles";
import {
	IHistoryRequest,
	IRequestDataSearchCriteria,
} from "utility/interfaces";

type ComponentProps = {
	row: IHistoryRequest;
	isSmallDevice: boolean;
	searchCriteria: IRequestDataSearchCriteria;
};

interface ExpandMoreProps extends ButtonProps {
	expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
	const { expand, ...other } = props;
	return (
		<Button {...other} disableFocusRipple disableElevation disableRipple />
	);
})(({ theme, expand }) => ({
	marginLeft: "auto",
	transition: theme.transitions.create("transform", {
		duration: theme.transitions.duration.shortest,
	}),
}));

export function RequestDataTableRow(props: ComponentProps) {
	// useStates
	const [tableUser, setTableUser] = useState<null | HTMLElement>(null);
	const [expanded, setExpanded] = useState(false);
	const [isEmailModal, setIsEmailModal] = useState(false);
	const [isDownloadModal, setIsDownloadModal] = useState(false);

	// Extract Props
	const { row, isSmallDevice, searchCriteria } = props;

	// Handled events and functions
	function CheckBoxIcon() {
		return (
			<img src={UncheckIcon} style={{ display: "block" }} alt="checkbox" />
		);
	}
	function CheckedBoxIcon() {
		return <img src={CheckIcon} style={{ display: "block" }} alt="checkbox" />;
	}
	const handleTableMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
		event.stopPropagation();
		setTableUser(event.currentTarget);
	};
	const handleTableMenuClose = () => {
		setTableUser(null);
	};
	const handleExpandClick = () => {
		setExpanded(!expanded);
	};

	// Page level variables
	const tableMenuOpen = Boolean(tableUser);

	return (
		<>
			{!isSmallDevice ? (
				<>
					<TableRow className="bg-white">
						<TableCell
							component="th"
							scope="row"
							style={{ minWidth: 160, maxWidth: 160 }}
							className="wrap"
						>
							{row.patientName}
						</TableCell>
						<TableCell
							style={{ minWidth: 140, maxWidth: 140 }}
							className="wrap"
						>
							{row.requestor}
						</TableCell>
						<TableCell
							style={{ minWidth: 140, maxWidth: 140 }}
							className="wrap"
						>
							{row.dateOfService}
						</TableCell>
						<TableCell
							style={{ minWidth: 130, maxWidth: 130 }}
							className="wrap"
						>
							{row.caseCloseDate}
						</TableCell>
						<TableCell style={{ minWidth: 160 }} className="wrap">
							{row.email}
						</TableCell>
						<TableCell style={{ minWidth: 150 }} className="wrap">
							{row.phoneNumber}
						</TableCell>
						<TableCell
							style={{ minWidth: 250, maxWidth: 250 }}
							className="wrap"
						>
							{row.address}
						</TableCell>
						<TableCell
							style={{ minWidth: 100, maxWidth: 100 }}
							className="wrap"
						>
							{row.zipCode}
						</TableCell>
						<TableCell
							style={{ minWidth: 130, maxWidth: 130 }}
							className="wrap"
						>
							{row.transactionStatus}
						</TableCell>
						<TableCell
							style={{ minWidth: 130, maxWidth: 130 }}
							className="wrap"
						>
							{row.requestStatus}
						</TableCell>
						<TableCell
							style={{ minWidth: 150, maxWidth: 150 }}
							className="wrap"
						>
							{row.providerName}
						</TableCell>
						<TableCell
							style={{ minWidth: 230, maxWidth: 230 }}
							className="wrap"
						>
							{row.providerNote}
						</TableCell>
						<TableCell
							style={{ minWidth: 230, maxWidth: 230 }}
							className="wrap"
						>
							{row.cancelledByproviderNote}
						</TableCell>
						<TableCell
							style={{ minWidth: 230, maxWidth: 230 }}
							className="wrap"
						>
							{row.adminNote}
						</TableCell>
						<TableCell
							style={{ minWidth: 230, maxWidth: 230 }}
							className="wrap"
						>
							{row.patientNote}
						</TableCell>
						<TableCell align="center">
							<span className="table-cell-title">Actions</span>
							<Button
								id="table-button"
								aria-controls={tableMenuOpen ? "table-menu" : undefined}
								aria-haspopup="true"
								aria-expanded={tableMenuOpen ? "true" : undefined}
								onClick={handleTableMenu}
								className="action-btn action-btn-primary"
							>
								Delete
							</Button>
						</TableCell>
					</TableRow>
				</>
			) : (
				// Mobile view
				<Card className="bg-white">
					<div className="card-container">
						<ExpandMore
							expand={expanded}
							onClick={handleExpandClick}
							aria-expanded={expanded}
							aria-label="show more"
						>
							<CardHeader
								title={
									<React.Fragment>
										<span>{row.patientName}</span>
									</React.Fragment>
								}
							/>
							<CardContent className="card-header-content">
								<div className="card-subheader">
									<Typography variant="body2" color="text.secondary">
										{row.address}
									</Typography>
								</div>
							</CardContent>
						</ExpandMore>
						<Collapse in={expanded} timeout="auto" unmountOnExit>
							<CardContent>
								<div>
									<span>
										<img src={MailPrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Requestor:&nbsp;
										<span>{row.requestor}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={CalendarIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Date Of Service:&nbsp;
										<span>{row.dateOfService}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={CalendarIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Case Closed Date:&nbsp;
										<span>{row.caseCloseDate}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={MailPrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Email:&nbsp;
										<span>{row.email}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Phone:&nbsp;
										<span>{row.phoneNumber}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										ZipCode:&nbsp;
										<span>{row.zipCode}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Transaction Status:&nbsp;
										<span>{row.transactionStatus}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Request Status:&nbsp;
										<span>{row.requestStatus}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Provider:&nbsp;
										<span>{row.providerName}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Provider Note:&nbsp;
										<span>{row.providerNote}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Cancelled By Provider Note:&nbsp;
										<span>{row.providerNote}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Admin Note:&nbsp;
										<span>{row.adminNote}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Patient Note:&nbsp;
										<span>{row.patientNote}</span>
									</Typography>
								</div>
								<div className="table-cell-btn-group">
									<Button variant="outlined">Delete Permanently</Button>
								</div>
							</CardContent>
						</Collapse>
					</div>
				</Card>
			)}
		</>
	);
}
