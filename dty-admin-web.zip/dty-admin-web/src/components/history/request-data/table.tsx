import React from "react";
import {
	Box,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	Typography,
} from "@mui/material";
import { SortOrder } from "utility/enums/sort-order";
import {
	IHistoryRequestData,
	IRequestDataSearchCriteria,
} from "utility/interfaces";
import {
	RequestDataTableRow,
	RequestDataTableSearch,
	TablePagination,
} from "components";

type ComponentProps = {
	searchCriteria: IRequestDataSearchCriteria;
	handleOnSearchCriteriaChange: any;
	rowData: IHistoryRequestData | null;
};

export function RequestDataTable(props: ComponentProps) {
	// Extract Props
	const { searchCriteria, handleOnSearchCriteriaChange, rowData } = props;

	// Handled events and functions
	const handleOnPageNumberChange = (value: number) => {
		handleOnSearchCriteriaChange({ ...searchCriteria, PageIndexId: value });
	};
	const handleOnChangeSortDirection = (sortBy: string) => {
		handleOnSearchCriteriaChange({
			...searchCriteria,
			SortBy: sortBy,
			SortOrder:
				searchCriteria.SortOrder === SortOrder.ascending
					? SortOrder.descending
					: SortOrder.ascending,
		});
	};
	return (
		<Box className="table-box">
			<RequestDataTableSearch
				handleOnSearchCriteriaChange={handleOnSearchCriteriaChange}
			/>
			{rowData && rowData?.totalRecords > 0 ? (
				<>
					<TableContainer sx={{ display: { xs: "none", sm: "block" } }}>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell
										sx={{ textAlign: "center", minWidth: 160, maxWidth: 160 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "patientName"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("patientName")}
										>
											Patient Name
										</TableSortLabel>
									</TableCell>
									<TableCell sx={{ minWidth: 140, maxWidth: 140 }}>
										<TableSortLabel
											active={searchCriteria.SortBy === "requestor"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("requestor")}
										>
											Requestor
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 140, maxWidth: 140 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "dateOfService"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("dateOfService")
											}
										>
											Date Of Service
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 130, maxWidth: 130 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "caseCloseDate"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("caseCloseDate")
											}
										>
											Close Case Date
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 160, maxWidth: 160 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "email"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("email")}
										>
											Email
										</TableSortLabel>
									</TableCell>
									<TableCell sx={{ textAlign: "center", minWidth: 150 }}>
										<TableSortLabel
											active={searchCriteria.SortBy === "phoneNumber"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("phoneNumber")}
										>
											Phone Number
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 250, maxWidth: 250 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "address"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("address")}
										>
											Address
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 100, maxWidth: 100 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "zipCode"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("zipCode")}
										>
											Zip
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 130, maxWidth: 130 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "transactionStatus"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("transactionStatus")
											}
										>
											Transaction Status
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 130, maxWidth: 130 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "requestStatus"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("requestStatus")
											}
										>
											Request Status
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 150, maxWidth: 150 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "providerName"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("physicianName")
											}
										>
											Physician
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 230, maxWidth: 230 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "providerNote"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("providerNote")
											}
										>
											Physician Note
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 230, maxWidth: 230 }}
									>
										<TableSortLabel
											active={
												searchCriteria.SortBy === "cancelledByproviderNote"
											}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() =>
												handleOnChangeSortDirection("cancelledByproviderNote")
											}
										>
											Cancelled By Provider Note
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 230, maxWidth: 230 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "adminNote"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("adminNote")}
										>
											Admin Note
										</TableSortLabel>
									</TableCell>
									<TableCell
										sx={{ textAlign: "center", minWidth: 230, maxWidth: 230 }}
									>
										<TableSortLabel
											active={searchCriteria.SortBy === "patientNote"}
											direction={
												searchCriteria.SortOrder === SortOrder.ascending
													? "asc"
													: "desc"
											}
											onClick={() => handleOnChangeSortDirection("patientNote")}
										>
											Patient Note
										</TableSortLabel>
									</TableCell>
									<TableCell
										align="center"
										sx={{ minWidth: 110, maxWidth: 110 }}
									>
										Delete Permanently
									</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{rowData?.requests?.map((row, index) => (
									<RequestDataTableRow
										key={index}
										row={row}
										isSmallDevice={false}
										searchCriteria={searchCriteria}
									/>
								))}
							</TableBody>
						</Table>
					</TableContainer>
					<Box
						sx={{ display: { xs: "block", sm: "none" } }}
						className="tabledata-cards-group"
					>
						{rowData?.requests?.map((row, index) => (
							<RequestDataTableRow
								key={index}
								row={row}
								isSmallDevice={true}
								searchCriteria={searchCriteria}
							/>
						))}
					</Box>
					<TablePagination
						currentPageNumber={searchCriteria.PageIndexId}
						handleOnPageNumberChange={handleOnPageNumberChange}
						totalRecords={rowData?.totalRecords || 0}
						rowCount={rowData?.requests?.length || 0}
					/>
				</>
			) : (
				<Typography variant="h5" sx={{ padding: 3 }}>
					No Record(s) Found{" "}
				</Typography>
			)}
		</Box>
	);
}
