import React, { useContext, useEffect, useState } from "react";
import {
	Box,
	Button,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Tooltip,
} from "@mui/material";
import {
	IHistoryInfoSearchCriteria,
	IRequestDataSearchCriteria,
	IHistorySearchFields,
} from "utility/interfaces";
import { CustomDatePicker } from "components";
import { Constants } from "utility/enums/constants";
import { SortOrder } from "utility/enums/sort-order";
import { createCommonAPICall } from "utility/helpers";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import historyService from "services/history-service";
import { flexbox } from "@mui/system";

type ComponentProps = {
	handleOnSearchCriteriaChange: any;
};

export function RequestDataTableSearch(props: ComponentProps) {
	// Extract Props
	const { handleOnSearchCriteriaChange } = props;

	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// useStates
	const [formValues, setFormValues] = useState<IRequestDataSearchCriteria>({
		PageIndexId: 0,
		PageSize: Constants.DefaultTablePageSize.valueOf(),
		SortOrder: SortOrder.ascending,
		SortBy: "",
		SearchBy: "",
		paymentStatus: 0,
		requestType: 0,
		providerName: "",
		email: "",
		phoneNumber: "",
		fromDateOfService: "",
		patientName: "",
		toDateOfService: "",
	});
	const [searchFields, setSearchFields] = useState<IHistorySearchFields>({
		requestPaymentStatus: [],
		requestType: [],
	});

	// Handled events and functions
	const handleFormValueChange = (name: string, value: any) => {
		setFormValues({ ...formValues, [name]: value });
	};
	const handleOnClearForm = () => {
		handleOnSearchCriteriaChange({
			PageIndexId: 0,
			PageSize: Constants.DefaultTablePageSize.valueOf(),
			SortOrder: SortOrder.ascending,
			SortBy: "",
			SearchBy: "",
			paymentStatus: 0,
			requestType: 0,
			providerName: "",
			email: "",
			phoneNumber: "",
			fromDateOfService: "",
			patientName: "",
			toDateOfService: "",
		});
		setFormValues({
			PageIndexId: 0,
			PageSize: Constants.DefaultTablePageSize.valueOf(),
			SortOrder: SortOrder.ascending,
			SortBy: "",
			SearchBy: "",
			paymentStatus: 0,
			requestType: 0,
			providerName: "",
			email: "",
			phoneNumber: "",
			fromDateOfService: "",
			patientName: "",
			toDateOfService: "",
		});
	};

	const handleOnClickSearch = () => {
		handleOnSearchCriteriaChange(formValues);
	};

	const getSearchFields = async () => {
		const data = await createCommonAPICall({
			apiService: historyService.getSearchFields,
			showSuccessMessage: false,
			showErrorMessage: true,
			setSuccessErrorContext,
		});
		if (data && data.data) setSearchFields(data.data);
	};

	// useEffects
	useEffect(() => {
		getSearchFields();
	}, []);

	return (
		<>
			<div>
				<div className="history-table-header">
					<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
						<Grid item xs={12} sm={3}>
							<FormControl fullWidth className="select-input">
								<InputLabel id="business-label">
									Select Payment Status
								</InputLabel>
								<Select
									labelId="business-label"
									id="business-name"
									name="paymentStatus"
									value={formValues.paymentStatus || ""}
									onChange={(e) =>
										handleFormValueChange("paymentStatus", e.target.value)
									}
									label="Select Payment Status"
									MenuProps={{
										className: "select-input-modal",
									}}
								>
									{searchFields.requestPaymentStatus.map((item, index) => {
										return (
											<MenuItem key={index} value={item.value}>
												{item.text}
											</MenuItem>
										);
									})}
								</Select>
							</FormControl>
						</Grid>
						<Grid item xs={12} sm={3}>
							<TextField
								fullWidth
								id="patient_name"
								label="Patient Name"
								variant="outlined"
								name="patientName"
								value={formValues.patientName}
								onChange={(e) =>
									handleFormValueChange("patientName", e.target.value)
								}
							/>
						</Grid>
						<Grid item xs={12} sm={3}>
							<FormControl fullWidth className="select-input">
								<InputLabel id="business-label">Select Request Type</InputLabel>
								<Select
									labelId="business-label"
									id="request-type"
									name="requestType"
									value={formValues.requestType || ""}
									onChange={(e) =>
										handleFormValueChange("requestType", e.target.value)
									}
									label="Select Payment Status"
									MenuProps={{
										className: "select-input-modal",
									}}
								>
									{searchFields.requestType.map((item, index) => {
										return (
											<MenuItem key={index} value={item.value}>
												{item.text}
											</MenuItem>
										);
									})}
								</Select>
							</FormControl>
						</Grid>
						<Grid item xs={12} sm={3}>
							<CustomDatePicker
								value={formValues.fromDateOfService}
								label="From Date Of Service"
								onChange={handleFormValueChange}
								name="fromDateOfService"
								disabled={false}
							/>
						</Grid>
						<Grid item xs={12} sm={3}>
							<CustomDatePicker
								value={formValues.toDateOfService}
								label="To Date Of Service"
								onChange={handleFormValueChange}
								name="toDateOfService"
								disabled={false}
							/>
						</Grid>
						<Grid item xs={12} sm={3}>
							<TextField
								fullWidth
								id="provider-name"
								label="Provider Name"
								variant="outlined"
								name="providerName"
								value={formValues.providerName}
								onChange={(e) =>
									handleFormValueChange("providerName", e.target.value)
								}
							/>
						</Grid>
						<Grid item xs={12} sm={3}>
							<TextField
								fullWidth
								id="email"
								label="Email"
								variant="outlined"
								name="email"
								value={formValues.email}
								onChange={(e) => handleFormValueChange("email", e.target.value)}
							/>
						</Grid>
						<Grid item xs={12} sm={3}>
							<TextField
								fullWidth
								id="phoneNumber"
								label="Phone Number"
								variant="outlined"
								name="phoneNumber"
								value={formValues.phoneNumber}
								onChange={(e) =>
									handleFormValueChange("phoneNumber", e.target.value)
								}
							/>
						</Grid>
						<Grid item xs={12} sm={12}>
							<Box
								sx={{
									display: "flex",
									columnGap: "12px",
									justifyContent: "flex-end",
									marginBottom: "14px",
								}}
							>
								<div className="history-search-btn">
									<Tooltip title="Click To Search">
										<Button variant="outlined" onClick={handleOnClearForm}>
											<span className="button-link">Clear</span>
										</Button>
									</Tooltip>
								</div>
								<div className="history-search-btn">
									<Tooltip title="Click To Search">
										<Button variant="contained" onClick={handleOnClickSearch}>
											<span className="button-link">Search</span>
										</Button>
									</Tooltip>
								</div>
							</Box>
						</Grid>
					</Grid>
				</div>
			</div>
		</>
	);
}
