import React, { useContext, useEffect, useState } from "react";
import {
	Box,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
} from "@mui/material";
import { visuallyHidden } from "@mui/utils";
import { SortOrder } from "utility/enums/sort-order";
import { Constants } from "utility/enums/constants";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { IPatientRecord, ISearchCriteria } from "utility/interfaces";
import { PatientRecordTableRow, TablePagination } from "components";

export function PatientRecordTable() {
	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// useStates
	const [searchCriteria, setSearchCriteria] = useState<ISearchCriteria>({
		PageIndexId: 0,
		PageSize: Constants.DefaultTablePageSize.valueOf(),
		SortOrder: SortOrder.ascending,
		SortBy: "",
		SearchBy: "",
	});
	const [patientHistoryPageInfo, setPatientHistoryPageInfo] =
		React.useState<IPatientRecord>({
			history: [],
			totalRecords: 0,
		});

	// Handled events and functions
	const handleOnPageNumberChange = (value: number) => {
		setSearchCriteria({ ...searchCriteria, PageIndexId: value });
	};
	const handleOnChangeSortDirection = (sortBy: string) => {
		setSearchCriteria({
			...searchCriteria,
			SortBy: sortBy,
			SortOrder:
				searchCriteria.SortOrder === SortOrder.ascending
					? SortOrder.descending
					: SortOrder.ascending,
		});
	};

	const getPatientHistories = async () => {
		// const data = await createCommonAPICall({
		// 	requestBody: searchCriteria,
		// 	apiService: roleService.getGridRoles,
		// 	showSuccessMessage: false,
		// 	showErrorMessage: true,
		// 	setSuccessErrorContext,
		// });
		// if (data && data.data) setRolePageInfo(data.data);
		setPatientHistoryPageInfo({
			history: [
				{
					queryString: "history 1 20,",
					client: "history 1 20,history 1 20",
					createdDate: "feb 23, 2023",
					conformation: "12345678963214888",
					providerName: "Dr agola",
					concludedDate: "feb 23, 2023",
					status: "history 1 20",
				},
				{
					queryString: "history 1 20",
					client: "history 1 20",
					createdDate: "history 1 20",
					conformation: "history 1 20",
					providerName: "history 1 20",
					concludedDate: "history 1 20",
					status: "history 1 20",
				},
				{
					queryString: "history 1 20",
					client: "history 1 20",
					createdDate: "history 1 20",
					conformation: "history 1 20",
					providerName: "history 1 20",
					concludedDate: "history 1 20",
					status: "history 1 20",
				},
				{
					queryString: "history 1 20",
					client: "history 1 20",
					createdDate: "history 1 20",
					conformation: "history 1 20",
					providerName: "history 1 20",
					concludedDate: "history 1 20",
					status: "history 1 20",
				},
				{
					queryString: "history 1 20",
					client: "history 1 20 sssssssssssss",
					createdDate: "history 1 20",
					conformation: "history 1 20",
					providerName: "history 1 20 sssssssssssss",
					concludedDate: "history 1 20",
					status: "history 1 20",
				},
			],
			totalRecords: 10,
		});
	};
	// useEffects
	useEffect(() => {
		getPatientHistories();
	}, [searchCriteria]);

	return (
		<>
			<TableContainer className="upload-table-container">
				<Table className="upload-table conclude-table">
					<TableHead>
						<TableRow>
							<TableCell
								sortDirection={searchCriteria.SortOrder}
								sx={{ minWidth: 190, maxWidth: 190 }}
							>
								<TableSortLabel
									active={searchCriteria.SortBy === "client"}
									direction={searchCriteria.SortOrder}
									onClick={() => handleOnChangeSortDirection("client")}
								>
									CLient/Member
									<Box component="span" sx={visuallyHidden}>
										{searchCriteria.SortOrder === SortOrder.descending
											? "sorted descending"
											: "sorted ascending"}
									</Box>
								</TableSortLabel>
							</TableCell>
							<TableCell
								sortDirection={searchCriteria.SortOrder}
								sx={{ minWidth: 165, maxWidth: 165 }}
							>
								<TableSortLabel
									active={searchCriteria.SortBy === "createdDate"}
									direction={searchCriteria.SortOrder}
									onClick={() => handleOnChangeSortDirection("createdDate")}
								>
									Created Date
									<Box component="span" sx={visuallyHidden}>
										{searchCriteria.SortOrder === SortOrder.descending
											? "sorted descending"
											: "sorted ascending"}
									</Box>
								</TableSortLabel>
							</TableCell>
							<TableCell
								sortDirection={searchCriteria.SortOrder}
								sx={{ minWidth: 170, maxWidth: 170 }}
							>
								<TableSortLabel
									active={searchCriteria.SortBy === "conformation"}
									direction={searchCriteria.SortOrder}
									onClick={() => handleOnChangeSortDirection("conformation")}
								>
									Conformation
									<Box component="span" sx={visuallyHidden}>
										{searchCriteria.SortOrder === SortOrder.descending
											? "sorted descending"
											: "sorted ascending"}
									</Box>
								</TableSortLabel>
							</TableCell>
							<TableCell
								sortDirection={searchCriteria.SortOrder}
								sx={{ minWidth: 180, maxWidth: 180 }}
							>
								<TableSortLabel
									active={searchCriteria.SortBy === "providerName"}
									direction={searchCriteria.SortOrder}
									onClick={() => handleOnChangeSortDirection("providerName")}
								>
									Provider Name
									<Box component="span" sx={visuallyHidden}>
										{searchCriteria.SortOrder === SortOrder.descending
											? "sorted descending"
											: "sorted ascending"}
									</Box>
								</TableSortLabel>
							</TableCell>
							<TableCell
								sortDirection={searchCriteria.SortOrder}
								sx={{ minWidth: 190, maxWidth: 190 }}
							>
								<TableSortLabel
									active={searchCriteria.SortBy === "concludedDate"}
									direction={searchCriteria.SortOrder}
									onClick={() => handleOnChangeSortDirection("concludedDate")}
								>
									Concluded Date
									<Box component="span" sx={visuallyHidden}>
										{searchCriteria.SortOrder === SortOrder.descending
											? "sorted descending"
											: "sorted ascending"}
									</Box>
								</TableSortLabel>
							</TableCell>
							<TableCell
								sortDirection={searchCriteria.SortOrder}
								sx={{ minWidth: 125, maxWidth: 125 }}
							>
								<TableSortLabel
									active={searchCriteria.SortBy === "status"}
									direction={searchCriteria.SortOrder}
									onClick={() => handleOnChangeSortDirection("status")}
								>
									Status
									<Box component="span" sx={visuallyHidden}>
										{searchCriteria.SortOrder === SortOrder.descending
											? "sorted descending"
											: "sorted ascending"}
									</Box>
								</TableSortLabel>
							</TableCell>
							<TableCell align="center" sx={{ width: 142 }}>
								Actions
							</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{patientHistoryPageInfo.history.map((row, index) => {
							return (
								<TableRow hover tabIndex={-1} key={index}>
									<PatientRecordTableRow row={row} />
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</TableContainer>
			<div className="small-table-pagination">
				<TablePagination
					currentPageNumber={searchCriteria.PageIndexId}
					handleOnPageNumberChange={handleOnPageNumberChange}
					totalRecords={patientHistoryPageInfo?.totalRecords || 0}
					rowCount={patientHistoryPageInfo.history?.length || 0}
				/>
			</div>
		</>
	);
}
