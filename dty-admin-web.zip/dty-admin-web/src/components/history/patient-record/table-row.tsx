import React, { useContext, useState } from "react";
import { Box, Button, TableCell, Tooltip } from "@mui/material";
import { useNavigate } from "react-router";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { IPatientRecordHistory } from "utility/interfaces";

type ComponentProps = {
	row: IPatientRecordHistory;
};

export function PatientRecordTableRow(props: ComponentProps) {
	// Extract Props
	const { row } = props;

	// Page level variable
	const navigate = useNavigate();
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// useStates
	const [deleteModalOpen, setDeleteModalOpen] = useState(false);

	return (
		<>
			<TableCell className="wrap">
				<div>
					<Box className="display-small-table-label">CLient/Member: &nbsp;</Box>
					<span>{row.client}</span>
				</div>
			</TableCell>
			<TableCell>
				<Box className="display-small-table-label">Created Date: &nbsp;</Box>
				<span>{row.createdDate}</span>
			</TableCell>
			<TableCell>
				<div>
					<Box className="display-small-table-label">Conformation: &nbsp;</Box>
					<span>{row.conformation}</span>
				</div>
			</TableCell>
			<TableCell className="wrap">
				<Box className="display-small-table-label">Provider Name: &nbsp;</Box>
				<span>{row.providerName}</span>
			</TableCell>
			<TableCell>
				<div>
					<Box className="display-small-table-label">
						Concluded Date: &nbsp;
					</Box>
					<span>{row.concludedDate}</span>
				</div>
			</TableCell>
			<TableCell>
				<Box className="display-small-table-label">Status: &nbsp;</Box>
				<span>{row.status}</span>
			</TableCell>
			<TableCell align="center">
				<div className="upload-actions">
					<Tooltip title="Actions">
						<Button
							id="table-button-edit"
							variant="outlined"
							className="action-btn-primary action-btn"
							style={{ marginRight: 4 }}
						>
							Actions
						</Button>
					</Tooltip>
				</div>
			</TableCell>
		</>
	);
}
