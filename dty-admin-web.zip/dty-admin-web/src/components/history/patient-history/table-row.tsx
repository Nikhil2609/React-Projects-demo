import React, { useState } from "react";
import {
	Button,
	TableCell,
	TableRow,
	ButtonProps,
	Card,
	CardContent,
	Typography,
	Collapse,
	CardHeader,
} from "@mui/material";
import { CalendarIcon } from "assests/images";
import { styled } from "@mui/material/styles";
import {
	IHistoryData,
	IPatientHistorySearchCriteria,
} from "utility/interfaces";

type ComponentProps = {
	row: IHistoryData;
	isSmallDevice: boolean;
	searchCriteria: IPatientHistorySearchCriteria;
};

interface ExpandMoreProps extends ButtonProps {
	expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
	const { expand, ...other } = props;
	return (
		<Button {...other} disableFocusRipple disableElevation disableRipple />
	);
})(({ theme, expand }) => ({
	marginLeft: "auto",
	transition: theme.transitions.create("transform", {
		duration: theme.transitions.duration.shortest,
	}),
}));

export function PatientHistoryTableRowData(props: ComponentProps) {
	// useStates
	const [expanded, setExpanded] = useState(false);

	// Extract Props
	const { row, isSmallDevice, searchCriteria } = props;

	// Handled events and functions
	const handleExpandClick = () => {
		setExpanded(!expanded);
	};

	return (
		<>
			{!isSmallDevice ? (
				<>
					<TableRow className="bg-white">
						<TableCell
							component="th"
							scope="row"
							style={{ minWidth: 160 }}
							className="wrap"
						>
							{row.firstName}
						</TableCell>
						<TableCell style={{ minWidth: 140 }} className="wrap">
							{row.lastName}
						</TableCell>
						<TableCell style={{ minWidth: 150 }} className="wrap">
							{row.email}
						</TableCell>
						<TableCell style={{ minWidth: 130 }} className="wrap">
							{row.phoneNumber}
						</TableCell>
						<TableCell
							style={{ minWidth: 330, maxWidth: 330 }}
							className="wrap"
						>
							{row.address}
						</TableCell>
						<TableCell align="center">
							<span className="table-cell-title">Actions</span>
							<Button
								id="table-button"
								className="action-btn action-btn-primary"
							>
								Explore
							</Button>
						</TableCell>
					</TableRow>
				</>
			) : (
				// Mobile view
				<Card className="bg-white">
					<div className="card-container">
						<ExpandMore
							expand={expanded}
							onClick={handleExpandClick}
							aria-expanded={expanded}
							aria-label="show more"
						>
							<CardHeader
								title={
									<React.Fragment>
										<span>
											{row.firstName}&nbsp;{row.lastName}
										</span>
									</React.Fragment>
								}
							/>
							<CardContent className="card-header-content">
								<div className="card-subheader">
									<Typography variant="body2" color="text.secondary">
										{row.address}
									</Typography>
								</div>
								<div className="card-subheader">
									<Typography variant="body2" color="text.secondary">
										{row.phoneNumber}
									</Typography>
								</div>
							</CardContent>
						</ExpandMore>
						<Collapse in={expanded} timeout="auto" unmountOnExit>
							<CardContent>
								<div>
									<span>
										<img src={CalendarIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Email:&nbsp;
										<span>{row.email}</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={CalendarIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Phone:&nbsp;
										<span>{row.phoneNumber}</span>
									</Typography>
								</div>
								<div className="table-cell-btn-group">
									<Button variant="outlined">Explore</Button>
								</div>
							</CardContent>
						</Collapse>
					</div>
				</Card>
			)}
		</>
	);
}
