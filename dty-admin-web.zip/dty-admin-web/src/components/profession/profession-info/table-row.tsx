import React, { useState } from "react";
import { Box, Button, TableCell, Tooltip } from "@mui/material";
import { WarningModal } from "components";
import { CrossRedIcon } from "assests/images";
import { IProfessionInfo } from "utility/interfaces";

type ComponentProps = {
	row: IProfessionInfo;
	handleOnClickDelete: any;
	handleOnClickEdit: any;
};

export function ProfessionInfoTableRow(props: ComponentProps) {
	// Extract Props
	const { row, handleOnClickDelete, handleOnClickEdit } = props;
	// useStates
	const [deleteModalOpen, setDeleteModalOpen] = useState(false);

	return (
		<>
			<TableCell component="th" scope="row" className="upload-file-col">
				<div>
					<Box className="display-small-table-label">
						Profession Name: &nbsp;
					</Box>
					<span>{row.professionName}</span>
				</div>
			</TableCell>
			<TableCell>
				<Box className="display-small-table-label">Status: &nbsp;</Box>
				<span>{row.status}</span>
			</TableCell>
			<TableCell align="center">
				<div className="upload-actions">
					<Tooltip title="Edit">
						<Button
							id="table-button-edit"
							variant="outlined"
							className="action-btn-primary action-btn"
							style={{ marginRight: 4 }}
							onClick={() => handleOnClickEdit(row)}
						>
							Edit
						</Button>
					</Tooltip>
					<Tooltip title="Delete">
						<Button
							onClick={() => setDeleteModalOpen(true)}
							variant="outlined"
							className="action-btn-primary action-btn"
							id="table-button-delete"
						>
							Delete
						</Button>
					</Tooltip>
				</div>
			</TableCell>
			<WarningModal
				isModalOpen={deleteModalOpen}
				handleOnClickCloseModal={() => setDeleteModalOpen(false)}
				handleOnClickOk={() => handleOnClickDelete(row)}
				warningMessage={`Are sure, you want to delete role, ${row.professionName}?`}
				title={"Delete confirmation"}
				okButtonText={"Delete"}
				closeButtonText={"Cancel"}
				warningIcon={CrossRedIcon}
			/>
		</>
	);
}
