import {
	Box,
	Button,
	ButtonProps,
	Card,
	CardContent,
	CardHeader,
	Chip,
	Collapse,
	FormControl,
	IconButton,
	InputAdornment,
	InputLabel,
	Link,
	Menu,
	MenuItem,
	Modal,
	OutlinedInput,
	Pagination,
	Select,
	SelectChangeEvent,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	TextField,
	Typography,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import {
	AnalysisDarkIcon,
	AnalysisIcon,
	BlockDarkIcon,
	BlockIcon,
	CalendarIcon,
	CalendarPrimaryIcon,
	CallIcon,
	ChipDeleteIcon,
	ClockIcon,
	ClockPrimaryIcon,
	CloseWhiteIcon,
	CopyDarkIcon,
	CopyIcon,
	DocnotesIcon,
	DocnotesIconDark,
	DoctorLightIcon,
	DoctorPrimaryIcon,
	ErrorDarkIcon,
	ErrorDarkModeIcon,
	ExclamationIcon,
	HeartbeatIcon,
	HeartbeatIconDark,
	LinkIcon,
	MailIcon,
	MailPrimaryIcon,
	MaximizeIcon,
	MinimizeIcon,
	MoodIcon,
	NotesDarkIcon,
	NotesIcon,
	OrdersIcon,
	OrdersIconDark,
	PatientLightIcon,
	PatientPrimaryIcon,
	PhonePrimaryIcon,
	Profile,
	SendIcon,
	StatusCheckIcon,
	StatusCheckPrimaryIcon,
	TasksDarkIcon,
	TasksIcon,
	UploadfileIcon,
	UploadfileIconDark,
	VerticalMenuIcon,
} from "assests/images";
import moment from "moment";
import React from "react";
import { visuallyHidden } from "@mui/utils";

interface ExpandMoreProps extends ButtonProps {
	expand: boolean;
}
interface TableComponentProps {
	tabvalue: string;
}
const ExpandMore = styled((props: ExpandMoreProps) => {
	const { expand, ...other } = props;
	return (
		<Button {...other} disableFocusRipple disableElevation disableRipple />
	);
})(({ theme, expand }) => ({
	marginLeft: "auto",
	transition: theme.transitions.create("transform", {
		duration: theme.transitions.duration.shortest,
	}),
}));

// ---------------Sorting table lines------------
interface Data {
	id: number;
	name: string;
	address: string;
	reqdate: string;
	waittime: string;
	dob: string;
	phone: string;
	secondaryphone: string;
	status: string;
	classname: string;
}

function createData(
	id: number,
	name: string,
	address: string,
	reqdate: string,
	waittime: string,
	dob: string,
	phone: string,
	secondaryphone: string,
	status: string,
	classname: string
): Data {
	return {
		id,
		name,
		address,
		reqdate,
		waittime,
		dob,
		phone,
		secondaryphone,
		status,
		classname,
	};
}

// ---------------Sorting table lines------------

const rows = [
	createData(
		1,
		"Bessie Cooper",
		"6387 Arad Street, Niagara Falls, ON L2G 2Z7",
		"2018-02-10",
		"5h 30m",
		"2018-02-10",
		"(+33)6 55 53 38 10",
		" ",
		"unassigned",
		"bg-business"
	),
	createData(
		2,
		"Courtney Henry",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-08-27",
		"3h 19m",
		"2019-08-27",
		"(+33)7 75 55 9375",
		" ",
		"unassigned",
		"bg-patient"
	),
	createData(
		3,
		"Guy Hawkins",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-08-07",
		"6h 3m",
		"2019-08-07",
		"(+33)7 35 55 45 43",
		"(+33)7 75 55 87 24",
		"unassigned",
		"bg-family"
	),
	createData(
		4,
		"Jerome Bell",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2013-03-22",
		"10h 35m",
		"2013-03-22",
		"(+33)7 35 5 46 14",
		" ",
		"unassigned",
		"bg-concierge"
	),
	createData(
		5,
		"Cody Fisher",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2006-03-25",
		"34h 36m",
		"2006-03-25",
		"(+33)7 45 55 87 71",
		" ",
		"unassigned",
		"bg-declined"
	),
	createData(
		7,
		"Darrell Steward",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-03-02",
		"40h 23m",
		"2019-03-02",
		"(+33)7 35 55 50 46",
		" ",
		"unassigned",
		"bg-family"
	),
	createData(
		8,
		"Darrell Steward",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-03-02",
		"40h 23m",
		"2019-03-02",
		"(+33)7 00 55 59 27",
		" ",
		"unassigned",
		"bg-vip"
	),
	createData(
		9,
		"Darrell Steward",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-03-02",
		"40h 23m",
		"2019-03-02",
		"(+33)7 35 55 84 97",
		" ",
		"unassigned",
		"bg-vip"
	),
	createData(
		10,
		"Darrell Steward",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-03-02",
		"40h 23m",
		"2019-03-02",
		"(+33)6 55 51 05 09",
		" ",
		"unassigned",
		"bg-vip"
	),
	createData(
		11,
		"Darrell Steward",
		"1655 Island Pkwy, Kamloops, BC V2B 6Y9",
		"2019-03-02",
		"5h 30m",
		"2019-03-02",
		"(+33)7 00 55 54 79",
		" ",
		"unassigned",
		"bg-patient"
	),
];

// ---------------Sorting table lines------------
function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
	if (b[orderBy] < a[orderBy]) {
		return -1;
	}
	if (b[orderBy] > a[orderBy]) {
		return 1;
	}
	return 0;
}

type Order = "asc" | "desc";

function getComparator<Key extends keyof any>(
	order: Order,
	orderBy: Key
): (
	a: { [key in Key]: string | number },
	b: { [key in Key]: string | number }
) => number {
	return order === "desc"
		? (a, b) => descendingComparator(a, b, orderBy)
		: (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort<T>(
	array: readonly T[],
	comparator: (a: T, b: T) => number
) {
	const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
	stabilizedThis.sort((a, b) => {
		const order = comparator(a[0], b[0]);
		if (order !== 0) {
			return order;
		}
		return a[1] - b[1];
	});
	return stabilizedThis.map((el) => el[0]);
}

interface EnhancedTableProps {
	onRequestSort: (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => void;
	order: Order;
	orderBy: string;
}

function EnhancedTableHead(props: EnhancedTableProps) {
	const { order, orderBy, onRequestSort } = props;
	const createSortHandler =
		(property: keyof Data) => (event: React.MouseEvent<unknown>) => {
			onRequestSort(event, property);
		};

	return (
		<TableHead>
			<TableRow>
				<TableCell
					key="name"
					sortDirection={orderBy === "name" ? order : false}
					sx={{ minWidth: 165, maxWidth: 170 }}
				>
					<TableSortLabel
						active={orderBy === "name"}
						direction={orderBy === "name" ? order : "asc"}
						onClick={createSortHandler("name")}
					>
						Name
						{orderBy === "name" ? (
							<Box component="span" sx={visuallyHidden}>
								{order === "desc" ? "sorted descending" : "sorted ascending"}
							</Box>
						) : null}
					</TableSortLabel>
				</TableCell>
				{/* ----------Changes for arrow transition------------ */}
				{/* <TableCell
					key="name"
					sortDirection={orderBy === "name" ? order : false}
					sx={{ minWidth: 165, maxWidth: 170 }}
				>
					<TableSortLabel
						active={false}
						direction={orderBy === "name" ? order : "asc"}
						hideSortIcon={true}
						onClick={createSortHandler("name")}
					>
						Name					
						<svg
							className="MuiSvgIcon-root MuiTableSortLabel-icon"
							focusable="false"
							aria-hidden="true"
							viewBox="0 0 24 24"
							data-testid="ArrowDownwardIcon"
						>
							<path d="M20 12l-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8 8-8z"></path>
						</svg>
					</TableSortLabel>
				</TableCell> */}
				{/* ----------Changes for arrow transition------------ */}
				<TableCell sx={{ minWidth: 104, maxWidth: 110 }}>Wait Time</TableCell>
				<TableCell sx={{ minWidth: 139 }}>Requested Date</TableCell>
				<TableCell sx={{ minWidth: 190 }}>Phone</TableCell>
				<TableCell sx={{ minWidth: 210 }}>Address</TableCell>
				<TableCell sx={{ minWidth: 108 }}>Status</TableCell>
				<TableCell sx={{ minWidth: 210 }}>Chat With</TableCell>
				<TableCell align="center" sx={{ minWidth: 110 }}>
					Actions
				</TableCell>
			</TableRow>
		</TableHead>
	);
}
// ---------------Sorting table lines------------

const style = {
	position: "absolute" as "absolute",
	top: "50%",
	left: "50%",
	transform: "translate(-50%, -50%)",
	bgcolor: "background.paper",
	boxShadow: "0px 0px 16px rgba(0, 0, 0, 0.1)",
	borderRadius: "10px",
};

const ITEM_HEIGHT = 32;
const ITEM_PADDING_TOP = 10;
const MenuProps = {
	PaperProps: {
		style: {
			maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
		},
	},
	className: "select-input-modal",
};

function DeleteIcon() {
	return (
		<>
			<img src={ChipDeleteIcon} alt="close" />
		</>
	);
}

const names = [
	"Insurance Issue",
	"Cost Issue",
	"Item 2",
	"Item 3",
	"Item 4",
	"Item 5",
	"Item 6",
	"Item 7",
	"Item 8",
];

const DesignerTableComponent: React.FC<TableComponentProps> = (
	props: TableComponentProps
) => {
	const { tabvalue } = props;
	const [tableuser, setTableuser] = React.useState<null | HTMLElement>(null);
	const tablemenuopen = Boolean(tableuser);
	const handleTablemenu = (event: React.MouseEvent<HTMLButtonElement>) => {
		event.stopPropagation();
		setTableuser(event.currentTarget);
	};
	const handleTablemenuclose = () => {
		setTableuser(null);
	};
	const [expanded, setExpanded] = React.useState(false);

	const handleExpandClick = () => {
		setExpanded(!expanded);
	};
	const [blockopen, setblockOpen] = React.useState(false);
	const handleblockOpen = () => setblockOpen(true);
	const handleblockClose = () => setblockOpen(false);
	const [mailsendopen, setmailsendopen] = React.useState(false);
	const handlemailsendopen = (event: React.MouseEvent<HTMLButtonElement>) => {
		event.stopPropagation();
		setmailsendopen(true);
	};
	const handlemailClose = () => setmailsendopen(false);
	const [transferopen, settransferopen] = React.useState(false);
	const handletransferopen = () => settransferopen(true);
	const handletransferClose = () => settransferopen(false);
	const [cancelopen, setcancelopen] = React.useState(false);
	const handlecancelopen = () => setcancelopen(true);
	const handlecancelClose = () => setcancelopen(false);

	const [region, setregion] = React.useState("");

	const handleChange = (event: SelectChangeEvent) => {
		setregion(event.target.value as string);
	};
	const [physician, setphysician] = React.useState("");

	const handlePhysicianChange = (event: SelectChangeEvent) => {
		setphysician(event.target.value as string);
	};
	const [cancel, setcancel] = React.useState<string[]>([]);

	const handlecancelChange = (event: SelectChangeEvent<typeof cancel>) => {
		const {
			target: { value },
		} = event;
		setcancel(typeof value === "string" ? value.split(",") : value);
	};
	const handleDelete = () => {
		console.info("You clicked the delete icon.");
	};

	const [patientPopup, setPatientPopup] =
		React.useState<HTMLButtonElement | null>(null);

	const open = Boolean(patientPopup);
	const id = open ? "patient-popover" : undefined;

	const [chatMenu, setChatMenu] = React.useState<null | HTMLElement>(null);
	const chatmenuopen = Boolean(chatMenu);
	const handleChatMenuClick = (event: React.MouseEvent<HTMLElement>) => {
		setChatMenu(event.currentTarget);
	};
	const handleChatMenuClose = () => {
		setChatMenu(null);
	};
	const [chatMenuRight, setChatMenuRight] = React.useState<null | HTMLElement>(
		null
	);
	const chatmenuRightopen = Boolean(chatMenuRight);
	const handleChatMenuRightClick = (event: React.MouseEvent<HTMLElement>) => {
		setChatMenuRight(event.currentTarget);
	};
	const handleChatMenuRightClose = () => {
		setChatMenuRight(null);
	};

	// ---------------Sorting table lines------------
	const [order, setOrder] = React.useState<Order>("asc");
	const [orderBy, setOrderBy] = React.useState<keyof Data>("name");

	const handleRequestSort = (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => {
		const isAsc = orderBy === property && order === "asc";
		setOrder(isAsc ? "desc" : "asc");
		setOrderBy(property);
	};
	// ---------------Sorting table lines------------

	const [chatbox, setChatbox] = React.useState(false);
	return (
		<Box className="table-box">
			<div className="table-header">
				<TextField
					id="search"
					placeholder="Search Patients"
					variant="outlined"
				/>
				<div className="table-btn-group">
					<Button disableElevation disableRipple className="active">
						All
					</Button>
					<Button disableElevation disableRipple>
						<span className="bg-patient"></span>Patient
					</Button>
					<Button disableElevation disableRipple>
						<span className="bg-family"></span>Family/Friend
					</Button>
					<Button disableElevation disableRipple>
						<span className="bg-business"></span>Business
					</Button>
					<Button disableElevation disableRipple>
						<span className="bg-concierge"></span>Concierge
					</Button>
					<Button disableElevation disableRipple>
						<span className="bg-vip"></span>VIP
					</Button>
					<Button disableElevation disableRipple>
						<span className="bg-declined"></span>Declined By
					</Button>
				</div>
			</div>
			<TableContainer sx={{ display: { xs: "none", sm: "block" } }}>
				<Table>
					{/* ------------Sorting table changes------------ */}
					<EnhancedTableHead
						order={order}
						orderBy={orderBy}
						onRequestSort={handleRequestSort}
					/>
					<TableBody>
						{stableSort(rows, getComparator(order, orderBy)).map(
							(row, index) => {
								return (
									<TableRow key={row.id} className={row.classname}>
										<TableCell component="th" scope="row" className="wrap">
											<div className="cell-with-icons">
												<Box sx={{ display: "flex", alignItems: "flex-start" }}>
													<img
														src={ExclamationIcon}
														alt="exclamation"
														style={{ marginTop: "6px", marginRight: "4px" }}
													/>
													{row.name}
												</Box>
												<IconButton
													className="mail-btn"
													onClick={handlemailsendopen}
												>
													<img src={MailIcon} alt="call" />
												</IconButton>
											</div>
										</TableCell>
										<TableCell>{row.waittime}</TableCell>
										<TableCell>
											{moment(row.reqdate).format("MMM D, YYYY")}
										</TableCell>
										<TableCell>
											<div className="phone-numbers">
												<Button
													variant="outlined"
													href={"tel:" + `${row.phone}`}
												>
													<img src={CallIcon} alt="call" />
													{row.phone}
												</Button>
												{row.secondaryphone !== " " && (
													<Button
														variant="outlined"
														href={"tel:" + `${row.secondaryphone}`}
													>
														<img src={CallIcon} alt="call" />
														{row.secondaryphone}
													</Button>
												)}
											</div>
										</TableCell>
										<TableCell>{row.address}</TableCell>
										<TableCell>{row.status}</TableCell>
										<TableCell>
											<span className="table-cell-title">Chat With</span>
											<div className="table-cell-btn-group">
												<Button
													variant="outlined"
													onClick={(e) => {
														setChatbox(true);
														document.body.classList.toggle("chatbox-open");
													}}
												>
													<img src={PatientLightIcon} alt="" />
													Patient
												</Button>
												<Button
													variant="outlined"
													onClick={(e) => {
														setChatbox(true);
														document.body.classList.toggle("chatbox-open");
													}}
												>
													<img src={DoctorLightIcon} alt="" />
													Provider
												</Button>
											</div>
										</TableCell>
										<TableCell align="center">
											<span className="table-cell-title">Actions</span>
											<Button
												id="table-button"
												aria-controls={tablemenuopen ? "table-menu" : undefined}
												aria-haspopup="true"
												aria-expanded={tablemenuopen ? "true" : undefined}
												onClick={handleTablemenu}
												className="action-btn"
											>
												Actions
											</Button>
										</TableCell>
									</TableRow>
								);
							}
						)}
						{/* ----------Table sorting changes----------- */}
					</TableBody>
				</Table>
			</TableContainer>
			{tabvalue === "new" && (
				<Menu
					id="table-menu"
					anchorEl={tableuser}
					open={tablemenuopen}
					className="new-table-menu"
					onClose={handleTablemenuclose}
					anchorOrigin={{
						vertical: "bottom",
						horizontal: "right",
					}}
					transformOrigin={{
						vertical: "top",
						horizontal: "right",
					}}
				>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-case">
							<img src={AnalysisIcon} alt="analysis" className="light-icon" />
							<img
								src={AnalysisDarkIcon}
								alt="analysis"
								className="dark-icon"
							/>
							View Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-notes">
							<img src={NotesIcon} alt="notes" className="light-icon" />
							<img src={NotesDarkIcon} alt="notes" className="dark-icon" />
							View Notes
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handlecancelopen}>
							<img src={ErrorDarkIcon} alt="error" className="light-icon" />
							<img src={ErrorDarkModeIcon} alt="error" className="dark-icon" />
							Cancel Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handletransferopen}>
							<img src={TasksIcon} alt="tasks" className="light-icon" />
							<img src={TasksDarkIcon} alt="tasks" className="dark-icon" />
							Assign Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handleblockOpen}>
							<img src={BlockIcon} alt="error" className="light-icon" />
							<img src={BlockDarkIcon} alt="error" className="dark-icon" />
							Block Case
						</Link>
					</MenuItem>
				</Menu>
			)}
			{tabvalue === "working" && (
				<Menu
					id="table-menu"
					anchorEl={tableuser}
					open={tablemenuopen}
					className="new-table-menu"
					onClose={handleTablemenuclose}
					anchorOrigin={{
						vertical: "bottom",
						horizontal: "right",
					}}
					transformOrigin={{
						vertical: "top",
						horizontal: "right",
					}}
				>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-case">
							<img src={AnalysisIcon} alt="analysis" className="light-icon" />
							<img
								src={AnalysisDarkIcon}
								alt="analysis"
								className="dark-icon"
							/>
							View Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-uploads">
							<img src={UploadfileIcon} alt="files" className="light-icon" />
							<img src={UploadfileIconDark} alt="files" className="dark-icon" />
							View Uploads
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-notes">
							<img src={NotesIcon} alt="notes" className="light-icon" />
							<img src={NotesDarkIcon} alt="notes" className="dark-icon" />
							View Notes
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/orders">
							<img src={OrdersIcon} alt="orders" className="light-icon" />
							<img src={OrdersIconDark} alt="notes" className="dark-icon" />
							Orders
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handletransferopen}>
							<img src={TasksIcon} alt="tasks" className="light-icon" />
							<img src={TasksDarkIcon} alt="tasks" className="dark-icon" />
							Assign Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handlecancelopen}>
							<img src={ErrorDarkIcon} alt="error" className="light-icon" />
							<img src={ErrorDarkModeIcon} alt="error" className="dark-icon" />
							Cancel Case
						</Link>
					</MenuItem>
				</Menu>
			)}
			{tabvalue === "active" && (
				<Menu
					id="table-menu"
					anchorEl={tableuser}
					open={tablemenuopen}
					className="new-table-menu"
					onClose={handleTablemenuclose}
					anchorOrigin={{
						vertical: "bottom",
						horizontal: "right",
					}}
					transformOrigin={{
						vertical: "top",
						horizontal: "right",
					}}
				>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-case">
							<img src={AnalysisIcon} alt="analysis" className="light-icon" />
							<img
								src={AnalysisDarkIcon}
								alt="analysis"
								className="dark-icon"
							/>
							View Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-uploads">
							<img src={UploadfileIcon} alt="files" className="light-icon" />
							<img src={UploadfileIconDark} alt="files" className="dark-icon" />
							View Uploads
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-notes">
							<img src={NotesIcon} alt="notes" className="light-icon" />
							<img src={NotesDarkIcon} alt="notes" className="dark-icon" />
							View Notes
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/orders">
							<img src={OrdersIcon} alt="orders" className="light-icon" />
							<img src={OrdersIconDark} alt="notes" className="dark-icon" />
							Orders
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/doctors-note">
							<img src={DocnotesIcon} alt="notes" className="light-icon" />
							<img src={DocnotesIconDark} alt="notes" className="dark-icon" />
							Doctors Note
						</Link>
					</MenuItem>
				</Menu>
			)}
			{tabvalue === "conclude" && (
				<Menu
					id="table-menu"
					anchorEl={tableuser}
					open={tablemenuopen}
					className="new-table-menu"
					onClose={handleTablemenuclose}
					anchorOrigin={{
						vertical: "bottom",
						horizontal: "right",
					}}
					transformOrigin={{
						vertical: "top",
						horizontal: "right",
					}}
				>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-case">
							<img src={AnalysisIcon} alt="analysis" className="light-icon" />
							<img
								src={AnalysisDarkIcon}
								alt="analysis"
								className="dark-icon"
							/>
							View Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-uploads">
							<img src={UploadfileIcon} alt="files" className="light-icon" />
							<img src={UploadfileIconDark} alt="files" className="dark-icon" />
							View Uploads
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-notes">
							<img src={NotesIcon} alt="notes" className="light-icon" />
							<img src={NotesDarkIcon} alt="notes" className="dark-icon" />
							View Notes
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handletransferopen}>
							<img src={TasksIcon} alt="tasks" className="light-icon" />
							<img src={TasksDarkIcon} alt="tasks" className="dark-icon" />
							Assign Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/conclude-care">
							<img
								src={HeartbeatIcon}
								alt="heart-beat"
								className="light-icon"
							/>
							<img
								src={HeartbeatIconDark}
								alt="heart-beat"
								className="dark-icon"
							/>
							Conclude Care
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/doctors-note">
							<img src={DocnotesIcon} alt="notes" className="light-icon" />
							<img src={DocnotesIconDark} alt="notes" className="dark-icon" />
							Doctors Note
						</Link>
					</MenuItem>
				</Menu>
			)}
			{tabvalue === "to-close" && (
				<Menu
					id="table-menu"
					anchorEl={tableuser}
					open={tablemenuopen}
					className="new-table-menu"
					onClose={handleTablemenuclose}
					anchorOrigin={{
						vertical: "bottom",
						horizontal: "right",
					}}
					transformOrigin={{
						vertical: "top",
						horizontal: "right",
					}}
				>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-case">
							<img src={AnalysisIcon} alt="analysis" className="light-icon" />
							<img
								src={AnalysisDarkIcon}
								alt="analysis"
								className="dark-icon"
							/>
							View Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-uploads">
							<img src={UploadfileIcon} alt="files" className="light-icon" />
							<img src={UploadfileIconDark} alt="files" className="dark-icon" />
							View Uploads
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/view-notes">
							<img src={NotesIcon} alt="notes" className="light-icon" />
							<img src={NotesDarkIcon} alt="notes" className="dark-icon" />
							View Notes
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/orders">
							<img src={OrdersIcon} alt="orders" className="light-icon" />
							<img src={OrdersIconDark} alt="notes" className="dark-icon" />
							Orders
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="./designer-dashboard/close-case">
							<img src={ErrorDarkIcon} alt="error" className="light-icon" />
							<img src={ErrorDarkModeIcon} alt="error" className="dark-icon" />
							Close Case
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link href="/designer-dashboard/doctors-note">
							<img src={DocnotesIcon} alt="notes" className="light-icon" />
							<img src={DocnotesIconDark} alt="notes" className="dark-icon" />
							Doctors Note
						</Link>
					</MenuItem>
					<MenuItem
						onClick={handleTablemenuclose}
						disableRipple
						disableTouchRipple
					>
						<Link onClick={handlecancelopen}>
							<img src={ErrorDarkIcon} alt="error" className="light-icon" />
							<img src={ErrorDarkModeIcon} alt="error" className="dark-icon" />
							Cancel Case
						</Link>
					</MenuItem>
				</Menu>
			)}
			<Box
				sx={{ display: { xs: "block", sm: "none" } }}
				className="tabledata-cards-group"
			>
				{rows.map((row) => (
					<Card className={row.classname}>
						<div className="card-container">
							<ExpandMore
								expand={expanded}
								onClick={handleExpandClick}
								aria-expanded={expanded}
								aria-label="show more"
							>
								<Button
									id="table-button"
									aria-controls={tablemenuopen ? "table-menu" : undefined}
									aria-haspopup="true"
									aria-expanded={tablemenuopen ? "true" : undefined}
									onClick={handleTablemenu}
									className="action-btn"
								>
									Actions
								</Button>
								<IconButton className="mail-btn" onClick={handlemailsendopen}>
									<img src={MailIcon} alt="mail" />
								</IconButton>
								{/* ----------changes----------- */}
								{/* <IconButton
									className="copy-btn"
									onClick={(e) => e.stopPropagation()}
								>
									<img src={CopyIcon} alt="copy" />
								</IconButton> */}
								{/* ----------changes----------- */}
								<CardHeader
									title={
										<React.Fragment>
											<span>{row.name}</span>
											<IconButton
												className="copy-btn"
												onClick={(e) => e.stopPropagation()}
											>
												<img src={CopyIcon} alt="copy" />
											</IconButton>
										</React.Fragment>
									}
								/>
								{/* <CardHeader title={row.name} /> */}
								<CardContent className="card-header-content">
									<div className="card-subheader">
										<Typography variant="body2" color="text.secondary">
											{row.address}
											<IconButton
												className="copy-btn"
												onClick={(e) => e.stopPropagation()}
											>
												<img src={CopyIcon} alt="copy" />
											</IconButton>
										</Typography>
										<ExpandMore
											expand={expanded}
											onClick={handleExpandClick}
											aria-expanded={expanded}
											aria-label="show more"
										>
											Map Location
										</ExpandMore>
									</div>
									<Typography>
										<img src={ClockIcon} alt="time" />
										Wait Time ({moment(row.reqdate).format("MM/DD/YYYY")})
										:&nbsp;
										<span>{row.waittime}</span>
										<IconButton
											className="copy-btn"
											onClick={(e) => e.stopPropagation()}
										>
											<img src={CopyIcon} alt="copy" />
										</IconButton>
									</Typography>
								</CardContent>
							</ExpandMore>
							<Collapse in={expanded} timeout="auto" unmountOnExit>
								<CardContent>
									<div>
										<span>
											<img src={CalendarPrimaryIcon} alt="calender" />
										</span>
										<Typography variant="h6">
											Dob:&nbsp;
											<span>{row.dob}</span>
											<IconButton
												className="copy-btn"
												onClick={(e) => e.stopPropagation()}
											>
												<img src={CopyIcon} alt="copy" />
											</IconButton>
										</Typography>
									</div>
									<div>
										<span>
											<img src={CallIcon} alt="call" />
										</span>
										<Typography variant="h6">
											Patient:
											<span>
												<a href={"tel:" + `${row.phone}`}>
													{row.phone}
													<IconButton
														className="copy-btn"
														onClick={(e) => e.stopPropagation()}
													>
														<img src={CopyIcon} alt="copy" />
													</IconButton>
												</a>
												{row.secondaryphone !== " " && (
													<a href={"tel:" + `${row.secondaryphone}`}>
														{row.secondaryphone}
														<IconButton
															className="copy-btn"
															onClick={(e) => e.stopPropagation()}
														>
															<img src={CopyIcon} alt="copy" />
														</IconButton>
													</a>
												)}
											</span>
										</Typography>
									</div>
									<div>
										<span>
											<img src={StatusCheckIcon} alt="check" />
										</span>
										<Typography variant="h6">
											<span className="label">email:&nbsp;</span>
											<span className="word-break">
												rajeshsatvara@gmail.com
												<IconButton
													className="copy-btn"
													onClick={(e) => e.stopPropagation()}
												>
													<img src={CopyIcon} alt="copy" />
												</IconButton>
											</span>
										</Typography>
									</div>
									<div>
										<span>
											<img src={StatusCheckIcon} alt="check" />
										</span>
										<Typography variant="h6">
											<span>Status:&nbsp;</span>
											<span className="">{row.status}</span>
											<IconButton
												className="copy-btn"
												onClick={(e) => e.stopPropagation()}
											>
												<img src={CopyIcon} alt="copy" />
											</IconButton>
										</Typography>
									</div>
									<div className="table-cell-btn-group">
										<Button
											variant="outlined"
											onClick={(e) => {
												setChatbox(true);
												document.body.classList.toggle("chatbox-open");
											}}
										>
											<img src={PatientLightIcon} alt="" />
											Patient
										</Button>
										<Button
											variant="outlined"
											onClick={(e) => {
												setChatbox(true);
												document.body.classList.toggle("chatbox-open");
											}}
										>
											<img src={DoctorLightIcon} alt="" />
											Provider
										</Button>
									</div>
								</CardContent>
							</Collapse>
						</div>
					</Card>
				))}
			</Box>

			{/* --------------------Background white Cards changes------------------------ */}
			<Box
				sx={{ display: { xs: "block", sm: "none" } }}
				className="tabledata-cards-group"
			>
				<Card className="bg-white">
					<div className="card-container">
						<ExpandMore
							expand={expanded}
							onClick={handleExpandClick}
							aria-expanded={expanded}
							aria-label="show more"
						>
							<Button
								id="table-button"
								aria-controls={tablemenuopen ? "table-menu" : undefined}
								aria-haspopup="true"
								aria-expanded={tablemenuopen ? "true" : undefined}
								onClick={handleTablemenu}
								className="action-btn"
							>
								Actions
							</Button>
							<IconButton className="mail-btn" onClick={handlemailsendopen}>
								<img src={MailPrimaryIcon} alt="mail" />
							</IconButton>
							<CardHeader
								title={
									<React.Fragment>
										<span>Bessie Cooper</span>
										<IconButton
											className="copy-btn"
											onClick={(e) => e.stopPropagation()}
										>
											<img
												src={CopyDarkIcon}
												alt="copy"
												className="light-icon"
											/>
											<img src={CopyIcon} className="dark-icon" alt="copy" />
										</IconButton>
									</React.Fragment>
								}
							/>
							<CardContent className="card-header-content">
								<div className="card-subheader">
									<Typography variant="body2" color="text.secondary">
										6387 Arad Street, Niagara Falls, ON L2G 2Z7
										<IconButton
											className="copy-btn"
											onClick={(e) => e.stopPropagation()}
										>
											<img
												src={CopyDarkIcon}
												alt="copy"
												className="light-icon"
											/>
											<img src={CopyIcon} className="dark-icon" alt="copy" />
										</IconButton>
									</Typography>
									<ExpandMore
										expand={expanded}
										onClick={handleExpandClick}
										aria-expanded={expanded}
										aria-label="show more"
									>
										Map Location
									</ExpandMore>
								</div>
								<Typography>
									<img src={ClockPrimaryIcon} alt="time" />
									Wait Time 02/10/2018:&nbsp;
									<span>5h 30m</span>
									<IconButton
										className="copy-btn"
										onClick={(e) => e.stopPropagation()}
									>
										<img src={CopyDarkIcon} alt="copy" className="light-icon" />
										<img src={CopyIcon} className="dark-icon" alt="copy" />
									</IconButton>
								</Typography>
							</CardContent>
						</ExpandMore>
						<Collapse in={expanded} timeout="auto" unmountOnExit>
							<CardContent>
								<div>
									<span>
										<img src={CalendarIcon} alt="calender" />
									</span>
									<Typography variant="h6">
										Dob:&nbsp;
										<span>2018-02-10</span>
										<IconButton
											className="copy-btn"
											onClick={(e) => e.stopPropagation()}
										>
											<img
												src={CopyDarkIcon}
												alt="copy"
												className="light-icon"
											/>
											<img src={CopyIcon} className="dark-icon" alt="copy" />
										</IconButton>
									</Typography>
								</div>
								<div>
									<span>
										<img src={PhonePrimaryIcon} alt="call" />
									</span>
									<Typography variant="h6">
										Patient:
										<span>
											<a href={"tel:" + `(+33)6 55 53 38 10`}>
												(+33)6 55 53 38 10
												<IconButton
													className="copy-btn"
													onClick={(e) => e.stopPropagation()}
												>
													<img
														src={CopyDarkIcon}
														alt="copy"
														className="light-icon"
													/>
													<img
														src={CopyIcon}
														className="dark-icon"
														alt="copy"
													/>
												</IconButton>
											</a>
										</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={StatusCheckPrimaryIcon} alt="check" />
									</span>
									<Typography variant="h6">
										<span className="label">email:&nbsp;</span>
										<span className="word-break">
											rajeshsatvara@gmail.com
											<IconButton
												className="copy-btn"
												onClick={(e) => e.stopPropagation()}
											>
												<img
													src={CopyDarkIcon}
													alt="copy"
													className="light-icon"
												/>
												<img src={CopyIcon} className="dark-icon" alt="copy" />
											</IconButton>
										</span>
									</Typography>
								</div>
								<div>
									<span>
										<img src={StatusCheckPrimaryIcon} alt="check" />
									</span>
									<Typography variant="h6">
										<span>Status:&nbsp;</span>
										<span className="">unassigned</span>
										<IconButton
											className="copy-btn"
											onClick={(e) => e.stopPropagation()}
										>
											<img
												src={CopyDarkIcon}
												alt="copy"
												className="light-icon"
											/>
											<img src={CopyIcon} className="dark-icon" alt="copy" />
										</IconButton>
									</Typography>
								</div>
								<div className="table-cell-btn-group">
									<Button
										variant="outlined"
										onClick={(e) => {
											setChatbox(true);
											document.body.classList.toggle("chatbox-open");
										}}
									>
										<img src={PatientPrimaryIcon} alt="" />
										Patient
									</Button>
									<Button
										variant="outlined"
										onClick={(e) => {
											setChatbox(true);
											document.body.classList.toggle("chatbox-open");
										}}
									>
										<img src={DoctorPrimaryIcon} alt="" />
										Provider
									</Button>
								</div>
							</CardContent>
						</Collapse>
					</div>
				</Card>
			</Box>
			{/* --------------------Background white Cards changes------------------------ */}

			<div className="table-pagination">
				<Typography variant="h6" className="pagination-row">
					1–10 of 30
				</Typography>
				<Pagination count={10} variant="outlined" shape="rounded" />
			</div>
			<Modal open={blockopen} onClose={handleblockClose} className="send-modal">
				<Box sx={style}>
					<Box className="modal-header">
						<Typography variant="h5">Confirm Block</Typography>
						<IconButton onClick={handleblockClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="h6" className="patient-name">
								Patient Name :&nbsp;<span>Rajesh Satvara</span>
							</Typography>
							<TextField
								id="block"
								label="Reason for Block Request"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="modal-footer">
							<Button variant="contained" onClick={handleblockClose}>
								Confirm
							</Button>
							<Button variant="outlined" onClick={handleblockClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
			<Modal
				open={mailsendopen}
				onClose={handlemailClose}
				className="send-modal"
			>
				<Box sx={style}>
					<Box className="modal-header">
						<Typography variant="h5">Send Mail</Typography>
						<IconButton onClick={handlemailClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="h6" className="patient-name">
								Patient Name :&nbsp;
								<span>
									Rajesh Satvara<span>&#40;rajeshsatvara@gmail.com&#41;</span>
								</span>
							</Typography>
							<TextField
								id="block"
								label="Message"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="modal-footer">
							<Button variant="contained" onClick={handlemailClose}>
								Confirm
							</Button>
							<Button variant="outlined" onClick={handlemailClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
			<Modal
				open={transferopen}
				onClose={handletransferClose}
				className="send-modal"
			>
				<Box sx={style}>
					<Box className="modal-header">
						<Typography variant="h5">Transfer Request</Typography>
						<IconButton onClick={handletransferClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="body1" className="instruction">
								To transfer this request, search and select another Physician.
							</Typography>
							<FormControl fullWidth>
								<InputLabel id="region-label">
									Narrow Search by Region
								</InputLabel>
								<Select
									labelId="region-label"
									id="region"
									value={region}
									label="Narrow Search by Region"
									onChange={handleChange}
									MenuProps={{
										className: "select-input-modal",
									}}
								>
									<MenuItem value={1}>Item 1</MenuItem>
									<MenuItem value={2}>Item 2</MenuItem>
									<MenuItem value={3}>Item 3</MenuItem>
								</Select>
							</FormControl>
							<FormControl fullWidth>
								<InputLabel id="physician-label">Select Physician</InputLabel>
								<Select
									labelId="physician-label"
									id="physician"
									value={physician}
									label="Select Physician"
									onChange={handlePhysicianChange}
									MenuProps={{
										className: "select-input-modal",
									}}
								>
									<MenuItem value={1}>Item 1</MenuItem>
									<MenuItem value={2}>Item 2</MenuItem>
									<MenuItem value={3}>Item 3</MenuItem>
								</Select>
							</FormControl>
							<TextField
								id="block"
								label="Description"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="modal-footer">
							<Button variant="contained" onClick={handletransferClose}>
								Submit
							</Button>
							<Button variant="outlined" onClick={handletransferClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
			<Modal
				open={cancelopen}
				onClose={handlecancelClose}
				className="send-modal"
			>
				<Box sx={style}>
					<Box className="modal-header">
						<Typography variant="h5">Confirm Cancellation</Typography>
						<IconButton onClick={handlecancelClose}>
							<img src={CloseWhiteIcon} alt="close" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="h6" className="patient-name">
								Patient Name :&nbsp;<span>Rajesh Satvara</span>
							</Typography>
							<FormControl fullWidth>
								<InputLabel id="reason-label">
									Reasons for Cancellation
								</InputLabel>
								<Select
									labelId="reason-label"
									id="reason"
									value={cancel}
									multiple
									onChange={handlecancelChange}
									input={
										<OutlinedInput
											id="select-reason-chip"
											label="Reasons for Cancellation"
										/>
									}
									renderValue={(selected) => (
										<Box className="select-chips">
											{selected.map((value) => (
												<Chip
													key={value}
													label={value}
													onClick={handleDelete}
													onDelete={handleDelete}
													deleteIcon={<DeleteIcon />}
												/>
											))}
										</Box>
									)}
									MenuProps={MenuProps}
								>
									{names.map((name) => (
										<MenuItem key={name} value={name}>
											{name}
										</MenuItem>
									))}
								</Select>
							</FormControl>
							<TextField
								id="block"
								label="Provide Additional Notes"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="modal-footer">
							<Button variant="contained" onClick={handlecancelClose}>
								Confirm
							</Button>
							<Button variant="outlined" onClick={handlecancelClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
			{chatbox && (
				<div className="chat-popover">
					<div className="popover-header">
						<Typography variant="h5">
							<img src={Profile} alt="profile" />
							Satvara Rajesh
						</Typography>
						<div className="chat-action-group">
							<IconButton
								disableFocusRipple
								disableRipple
								className="chatbox-size-btn minimize-btn"
								onClick={(e) => {
									document.body.classList.add("minimize-chatbox");
									document.body.classList.toggle("chatbox-open");
									document.body.classList.remove("maximize-chatbox");
								}}
							>
								<img src={MinimizeIcon} alt="minimize" />
							</IconButton>
							<IconButton
								disableFocusRipple
								disableRipple
								className="chatbox-size-btn maximize-btn"
								onClick={(e) => {
									document.body.classList.add("maximize-chatbox");
									document.body.classList.toggle("chatbox-open");
									document.body.classList.remove("minimize-chatbox");
								}}
							>
								<img src={MaximizeIcon} alt="clmaximizeose" />
							</IconButton>
							<IconButton
								onClick={(e) => {
									setChatbox(false);
									document.body.classList.remove(
										"minimize-chatbox",
										"maximize-chatbox"
									);
									document.body.classList.remove("chatbox-open");
								}}
								disableFocusRipple
								disableRipple
							>
								<img src={CloseWhiteIcon} alt="close" />
							</IconButton>
						</div>
					</div>
					<div className="popover-body">
						<div className="popover-scroll">
							<div className="popover-scroll-inner">
								<span className="day">Today</span>
								<div className="messages right">
									<IconButton
										onClick={handleChatMenuClick}
										aria-haspopup="true"
										disableFocusRipple
										disableRipple
									>
										<img src={VerticalMenuIcon} alt="menu" />
									</IconButton>
									<div className="message">Hello</div>
									<Typography variant="body1">11:30 AM</Typography>
								</div>
								<div className="messages right">
									<IconButton
										onClick={handleChatMenuClick}
										aria-haspopup="true"
										disableFocusRipple
										disableRipple
									>
										<img src={VerticalMenuIcon} alt="menu" />
									</IconButton>
									<div className="message">Good Morning</div>
									<Typography variant="body1">11:32 AM</Typography>
								</div>
								<div className="messages left">
									<IconButton
										onClick={handleChatMenuRightClick}
										aria-haspopup="true"
										disableFocusRipple
										disableRipple
									>
										<img src={VerticalMenuIcon} alt="menu" />
									</IconButton>
									<div className="message">Good Morning</div>
									<Typography variant="body1">11:45 AM</Typography>
								</div>
								<div className="messages right">
									<IconButton
										onClick={handleChatMenuClick}
										aria-haspopup="true"
										disableFocusRipple
										disableRipple
									>
										<img src={VerticalMenuIcon} alt="menu" />
									</IconButton>
									<div className="message">
										Lorem ipsum dolor sit amet consectetur.
									</div>
									<Typography variant="body1">11:52 AM</Typography>
								</div>
							</div>
						</div>
					</div>
					<div className="popover-footer">
						<TextField
							placeholder="Type a message"
							id="chat"
							fullWidth
							className="with-icon-left"
							InputProps={{
								startAdornment: (
									<InputAdornment position="start">
										<IconButton edge="end" disableFocusRipple disableRipple>
											<img src={MoodIcon} alt="smiley" />
										</IconButton>
									</InputAdornment>
								),
							}}
						/>
						<IconButton className="contained">
							<img src={SendIcon} alt="send" />
						</IconButton>
						<IconButton className="outlined">
							<img src={LinkIcon} alt="link" />
						</IconButton>
					</div>
					<Menu
						id="chat-menu"
						anchorEl={chatMenu}
						open={chatmenuopen}
						onClose={handleChatMenuClose}
						anchorOrigin={{
							vertical: "top",
							horizontal: "left",
						}}
						transformOrigin={{
							vertical: "top",
							horizontal: "right",
						}}
						className="chat-menu"
					>
						<MenuItem onClick={handleChatMenuClose}>Copy</MenuItem>
						<MenuItem onClick={handleChatMenuClose}>Select</MenuItem>
						<MenuItem onClick={handleChatMenuClose}>Delete</MenuItem>
					</Menu>
					<Menu
						id="chat-menu-right"
						anchorEl={chatMenuRight}
						open={chatmenuRightopen}
						onClose={handleChatMenuRightClose}
						anchorOrigin={{
							vertical: "top",
							horizontal: "right",
						}}
						transformOrigin={{
							vertical: "top",
							horizontal: "left",
						}}
						className="chat-menu"
					>
						<MenuItem onClick={handleChatMenuRightClose}>Copy</MenuItem>
						<MenuItem onClick={handleChatMenuRightClose}>Select</MenuItem>
						<MenuItem onClick={handleChatMenuRightClose}>Delete</MenuItem>
					</Menu>
				</div>
			)}
		</Box>
	);
};
export default DesignerTableComponent;
