import { Divider } from "@mui/material";
import { FooterLogo, FooterLogoMobile } from "assests/images";
import React from "react";

const DesignerFooter: React.FC = () => {
	return (
		<footer>
			<a
				href="/designer-dashboard"
				className="footer-logo"
				title="Doctors To You"
			>
				<img src={FooterLogo} alt="Doctors To You" className="desktop" />
				<img src={FooterLogoMobile} alt="Doctors To You" className="mobile" />
			</a>
			<div className="footer-links">
				<a href="#" title="Terms of Conditions">
					Terms of Conditions
				</a>
				<Divider orientation="vertical" variant="middle" flexItem />
				<a href="#" title="Privacy Policy">
					Privacy Policy
				</a>
			</div>
		</footer>
	);
};

export default DesignerFooter;
