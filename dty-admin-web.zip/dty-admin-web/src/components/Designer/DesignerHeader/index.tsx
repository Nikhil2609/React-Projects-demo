import React, { useEffect, useState } from "react";
import {
	DarkIcon,
	Logo,
	MobileLogo,
	MenuIcon,
	LogoutIcon,
	LightIcon,
	ArrowDownIcon,
	ArrowDownIconDark,
} from "assests/images";
import {
	AppBar,
	Box,
	Button,
	Collapse,
	IconButton,
	Link,
	List,
	ListItemButton,
	MenuItem,
	MenuList,
	Popover,
	Toolbar,
	Typography,
} from "@mui/material";
import { LightDarkButton } from "components";

const DesignerHeader: React.FC = () => {
	const [providerMenu, setProviderMenu] = React.useState<null | HTMLElement>(
		null
	);
	const handleProviderMenuClick = (
		event: React.MouseEvent<HTMLButtonElement>
	) => {
		setProviderMenu(event.currentTarget);
	};
	const handleProviderMenuClose = () => {
		setProviderMenu(null);
	};

	const [provider, setProvider] = React.useState(false);

	const handleProviderClick = () => {
		setProvider(!provider);
	};

	return (
		<AppBar position="static" className="header">
			<Toolbar disableGutters sx={{ flexWrap: "wrap" }}>
				<Box className="header-container">
					<Box sx={{ display: "flex", alignItems: "center" }}>
						<IconButton
							size="large"
							onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
							sx={{ display: { xs: "flex", sm: "none" } }}
							className="menu-btn"
							disableRipple
							disableFocusRipple
						>
							<img src={MenuIcon} alt="menu" />
						</IconButton>
						<a
							href="/designer-dashboard"
							className="header-logo"
							title="Doctors To You"
						>
							<img src={Logo} alt="Doctors To You" className="desktop" />
							<img src={MobileLogo} alt="Doctors To You" className="mobile" />
						</a>
					</Box>
					<Box sx={{ flexGrow: 0 }} className="header-content">
						<Typography
							variant="h6"
							className="greetings"
							sx={{ display: { xs: "none", sm: "flex" } }}
						>
							Welcome,&nbsp;<span>Doctor Name</span>
						</Typography>
						<Button
							variant="outlined"
							size="small"
							href="/"
							className="logout-btn"
							title="Logout"
						>
							<img src={LogoutIcon} alt="logout" />
							<span>Logout</span>
						</Button>
						<LightDarkButton />
					</Box>
				</Box>
				<Box
					sx={{
						flexGrow: 1,
						display: { xs: "none", sm: "flex" },
						minWidth: "100%",
					}}
					className="menu-container"
				>
					<Button variant="text" className="menu-item active">
						<strong>Dashboard</strong>
						<span className="link-item">Dashboard</span>
					</Button>
					<Button variant="text" className="menu-item">
						<strong>Profile</strong>
						<span className="link-item">Profile</span>
					</Button>
					<ul>
						<li onMouseLeave={handleProviderMenuClose}>
							<Button
								id="provider-btn"
								aria-haspopup="true"
								className="menu-item"
								onMouseEnter={handleProviderMenuClick}
							>
								<strong>Provider</strong>
								<span className="link-item">Provider</span>
							</Button>
							<Popover
								id="provider-menu"
								anchorEl={providerMenu}
								open={Boolean(providerMenu)}
								onClose={handleProviderMenuClose}
								className="provider-menu"
								anchorOrigin={{
									vertical: "bottom",
									horizontal: "left",
								}}
								transformOrigin={{
									vertical: "top",
									horizontal: "left",
								}}
							>
								<MenuList>
									<MenuItem onClick={handleProviderMenuClose}>Roles</MenuItem>
									<MenuItem
										onClick={handleProviderMenuClose}
										className="active"
									>
										Provider
									</MenuItem>
									<MenuItem onClick={handleProviderMenuClose}>
										Scheduling
									</MenuItem>
									<MenuItem onClick={handleProviderMenuClose}>
										Accounts
									</MenuItem>
									<MenuItem onClick={handleProviderMenuClose}>
										Provider Location
									</MenuItem>
								</MenuList>
							</Popover>
						</li>
					</ul>
					<Button variant="text" className="menu-item">
						<strong>Profession</strong>
						<span className="link-item">Profession</span>
					</Button>
					<Button variant="text" className="menu-item">
						<strong>Halo</strong>
						<span className="link-item">Halo</span>
					</Button>
					<Button variant="text" className="menu-item">
						<strong>History</strong>
						<span className="link-item">History</span>
					</Button>
				</Box>
			</Toolbar>
			<nav className="sidebar">
				<Typography variant="h6" className="greetings" sx={{ display: "flex" }}>
					Welcome,&nbsp;<span>Doctor Name</span>
				</Typography>
				<List className="sidebar-menu">
					<ListItemButton disableRipple disableTouchRipple>
						<Link href="/designer-dashboard" className="active">
							Dashboard
						</Link>
					</ListItemButton>
					<ListItemButton disableRipple disableTouchRipple>
						<Link href="/designer-dashboard">Profile</Link>
					</ListItemButton>
					<ListItemButton disableRipple disableTouchRipple>
						<Link
							id="provider-link"
							onClick={handleProviderClick}
							className={provider ? "active-menu" : "default-menu"}
						>
							Provider
							<img src={ArrowDownIcon} alt="arrow" className="light-icon" />
							<img src={ArrowDownIconDark} alt="arrow" className="dark-icon" />
						</Link>
					</ListItemButton>
					<Collapse in={provider} timeout="auto" unmountOnExit>
						<List component="div">
							<ListItemButton
								onClick={handleProviderClick}
								disableRipple
								disableTouchRipple
							>
								Provider
							</ListItemButton>
							<ListItemButton
								onClick={handleProviderClick}
								disableRipple
								disableTouchRipple
							>
								Scheduling
							</ListItemButton>
							<ListItemButton
								onClick={handleProviderClick}
								disableRipple
								disableTouchRipple
							>
								Accounts
							</ListItemButton>
							<ListItemButton
								onClick={handleProviderClick}
								disableRipple
								disableTouchRipple
							>
								Provider Location
							</ListItemButton>
						</List>
					</Collapse>
					<ListItemButton disableRipple disableTouchRipple>
						<Link href="/designer-dashboard">Profession</Link>
					</ListItemButton>
					<ListItemButton disableRipple disableTouchRipple>
						<Link href="/designer-dashboard">Halo</Link>
					</ListItemButton>
					<ListItemButton disableRipple disableTouchRipple>
						<Link href="/designer-dashboard">History</Link>
					</ListItemButton>
				</List>
			</nav>
		</AppBar>
	);
};

export default DesignerHeader;
