import React from "react";
import { BrowserRouter } from "react-router-dom";
import { ThemeProvider } from "@mui/material/styles";
import { RouterConfig } from "utility/auth-guards/router-config";
import myCustomTheme from "app.theme";
import { SuccessErrorModal, Loader } from "components";
import { SuccessErrorModalProvider } from "contexts/success-error-context";
import { UserProvider } from "contexts/user-context";
import { ToastContainer } from "react-toastify";
import { MenuProvider } from "contexts/menu-context";

const App: React.FC = () => {
	return (
		<>
			<SuccessErrorModalProvider>
				<UserProvider>
					<MenuProvider>
						<ThemeProvider theme={myCustomTheme}>
							<SuccessErrorModal />
							<React.Suspense fallback={<Loader />}>
								<BrowserRouter>
									<RouterConfig />
									<ToastContainer />
								</BrowserRouter>
							</React.Suspense>
						</ThemeProvider>
					</MenuProvider>
				</UserProvider>
			</SuccessErrorModalProvider>
		</>
	);
};

export default App;
