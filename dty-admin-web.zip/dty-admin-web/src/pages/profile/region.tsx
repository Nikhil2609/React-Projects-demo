import { Box, Typography } from "@mui/material";
import {
	FollowupDefaultIcon,
	FollowupIcon,
	TocloseIconActive,
	TocloseIconDefault,
	UnassignedDefaultIcon,
	UnassignedIcon,
	WorkingIconActive,
	WorkingIconDefault,
} from "assests/images";
import { InformationTab, RegionTable } from "components";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import React, { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AppRoutings } from "utility/enums/app-routings";
import { Constants } from "utility/enums/constants";
import { RegionInformationTabStatus } from "utility/enums/region-tab-status";
import { SortOrder } from "utility/enums/sort-order";
import {
	getRegionTabStatusIdByName,
	getRegionTabStatusWiseName,
} from "utility/helpers";
import {
	IRegionSearchCriteria,
	IInformationTab,
	IRegionInfo,
} from "utility/interfaces";

const Region: React.FC = () => {
	// get query parameters
	const { tabStatus } = useParams();
	const { state } = window.history;

	// useStates
	const [regionPageInfo, setRegionPageInfo] =
		React.useState<IRegionInfo | null>({
			requestCounts: {
				unAssignedCount: 1000,
				followupCount: 1000,
				workingCount: 1000,
				closeCount: 1000,
			},
			requests: [
				{
					queryString: "abc",
					requestId: "1",
					waitTime: "10h 20m",
					clientMember: "Client member",
					business: "Business",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					requestStatus: "Accpet",
					requestStatusId: 1,
					physicianId: 11,
					physicianName: "physicianName",
					regionId: 12,
					regionName: "Dadar",
					phoneNumber: "8128791896",
				},
				{
					queryString: "abcdd",
					requestId: "10",
					waitTime: "10h 20m",
					clientMember: "Client member",
					business: "Business",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					requestStatus: "Accpet",
					requestStatusId: 1,
					physicianId: 11,
					physicianName: "physicianName",
					regionId: 12,
					regionName: "Dadar",
					phoneNumber: "8128791896",
				},
				{
					queryString: "abcdd",
					requestId: "11",
					waitTime: "10h 20m",
					clientMember: "Client member",
					business: "Business",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					requestStatus: "Accpet",
					requestStatusId: 1,
					physicianId: 11,
					physicianName: "physicianName",
					regionId: 12,
					regionName: "Dadar",
					phoneNumber: "8128791896",
				},
				{
					queryString: "abcd",
					requestId: "12",
					waitTime: "10h 20m",
					clientMember: "Client member",
					business: "Business",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					requestStatus: "Accpet",
					requestStatusId: 1,
					physicianId: 11,
					physicianName: "physicianName",
					regionId: 12,
					regionName: "Dadar",
					phoneNumber: "8128791896",
				},
			],
			gridButtons: {
				isEdit: true,
				isCall: true,
				isHouseCall: true,
				isFollowup: true,
				isCloseCase: true,
			},
			gridColumns: {
				isDisplayWaitTime: true,
				isDisplayClientMember: true,
				isDisplayBusiness: true,
				isDisplayAddress: true,
				isDisplayRequestStatus: true,
				isDisplayPhysician: true,
				isDisplayRegion: true,
			},
			totalRecords: 4,
		});
	const [searchCriteria, setSearchCriteria] = useState<IRegionSearchCriteria>({
		PageIndexId: state?.usr?.searchCriteria?.PageIndexId || 0,
		PageSize:
			state?.usr?.searchCriteria?.PageSize ||
			Constants.DefaultTablePageSize.valueOf(),
		SortOrder: state?.usr?.searchCriteria?.SortOrder || SortOrder.ascending,
		SortBy: state?.usr?.searchCriteria?.SortBy || "",
		SearchBy: state?.usr?.searchCriteria?.SearchBy || "",
		RequestStatusId:
			state?.usr?.searchCriteria?.RequestStatusId ||
			getRegionTabStatusIdByName(tabStatus ? tabStatus : ""),
		RegionId: state?.usr?.searchCriteria?.RegionId || 0,
	});

	// Handled events and functions
	const handleOnSearchCriteriaChange = (
		newSearchCriteria: IRegionSearchCriteria
	) => {
		setSearchCriteria(newSearchCriteria);
	};
	// const getRegionDetails = async () => {
	// 	try {
	// 		showLoader();
	// 		const response = await dashboardService.getDashboardInfo(searchCriteria);
	// 		if (response && response.status !== HttpStatusCodes.Unauthorized) {
	// 			const { data } = response;
	// 			if (data && data.isSuccessfull) {
	// 				console.log(data.data);
	// 			} else if (data && data.message) {
	// 				openSucessErrorModal(
	// 					setSuccessErrorContext,
	// 					"Error",
	// 					data.message,
	// 					false
	// 				);
	// 			}
	// 		}
	// 		hideLoader();
	// 	} catch (ex) {
	// 		hideLoader();
	// 		openSucessErrorModal(
	// 			setSuccessErrorContext,
	// 			"Error",
	// 			"Something went wrong, please try again!",
	// 			false
	// 		);
	// 	}
	// };
	const handleInfoTabChange = (tab: IInformationTab) => {
		const newSearchCriteria = {
			PageIndexId: 0,
			PageSize: Constants.DefaultTablePageSize.valueOf(),
			SortOrder: SortOrder.ascending,
			SortBy: "",
			SearchBy: "",
			RequestStatusId: tab.type,
			RegionId: 0,
		};
		navigate(
			`${AppRoutings.Region.replace(
				":tabStatus",
				`${getRegionTabStatusWiseName(tab.type).toLowerCase()}`
			)}`
		);
		handleOnSearchCriteriaChange(newSearchCriteria);
	};

	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);
	const navigate = useNavigate();
	const informationTabs: IInformationTab[] = [
		{
			id: 1,
			type: RegionInformationTabStatus.Unassigned,
			defaultIcon: UnassignedDefaultIcon,
			activeIcon: UnassignedIcon,
			title: "Unassigned",
			count: 1000,
			class: "new",
		},
		{
			id: 2,
			type: RegionInformationTabStatus.Working,
			defaultIcon: WorkingIconDefault,
			activeIcon: WorkingIconActive,
			title: "Working",
			count: 1000,
			class: "working",
		},
		{
			id: 3,
			type: RegionInformationTabStatus.FollowUp,
			defaultIcon: FollowupDefaultIcon,
			activeIcon: FollowupIcon,
			title: "Follow up",
			count: 1000,
			class: "active",
		},
		{
			id: 4,
			type: RegionInformationTabStatus.Closed,
			defaultIcon: TocloseIconDefault,
			activeIcon: TocloseIconActive,
			title: "To Close",
			count: 1000,
			class: "to-close",
		},
	];

	// useEffects
	useEffect(() => {
		// getRegionDetails();
		console.log(searchCriteria);
	}, [searchCriteria]);

	return (
		<>
			<Box>
				<div className="chatbox-overlay"></div>
				<main className="main-content">
					<div
						className="overlay"
						onClick={() => document.body.classList.toggle("sidebar-toggle")}
					></div>
					<InformationTab
						tabs={informationTabs}
						currentTabValue={+searchCriteria.RequestStatusId}
						handleTabChange={handleInfoTabChange}
						repeatSequence={4}
					/>
					<Box className="tab-item-header">
						<Typography variant="h2">
							Patients
							<span className="new">
								&nbsp;&#40;
								{getRegionTabStatusWiseName(searchCriteria.RequestStatusId)}
								&#41;
							</span>
						</Typography>
					</Box>
					<RegionTable
						handleOnSearchCriteriaChange={handleOnSearchCriteriaChange}
						searchCriteria={searchCriteria}
						regionPageInfo={regionPageInfo}
					></RegionTable>
				</main>
			</Box>
		</>
	);
};
export default Region;
