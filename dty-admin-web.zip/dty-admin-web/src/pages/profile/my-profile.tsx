import React, { useState } from "react";
import { Box, Button, Typography } from "@mui/material";
import { ArrowBack } from "assests/images";
import {
	AdministratorInformation,
	AccountInformation,
	MailingAndBillingInformation,
} from "components";
import { useNavigate } from "react-router-dom";
import { IMyProfileInfo } from "utility/interfaces";

const MyProfile: React.FC = () => {
	// useStates
	const [formValues, setFormValues] = useState<IMyProfileInfo>({
		userName: "",
		password: "",
		status: null,
		role: null,
		firstName: "",
		lastName: "",
		email: "",
		confirmEmail: "",
		mobileNumber: "",
		districtOfColumbia: false,
		newYork: false,
		virginia: false,
		maryland: false,
		city: "",
		state: null,
		zip: "",
		alternativePhone: "",
		address1: "",
		address2: "",
	});

	// Handled events and functions
	const handleOnChangeFormValue = (e: any) => {
		setFormValues({ ...formValues, [e.target.name]: e.target.value });
	};
	const handleOnCheckBoxCLick = (name: string, value: boolean) => {
		setFormValues({ ...formValues, [name]: value });
	};
	const handleOnClickBackCancel = () => navigate(-1);

	//Page level local variable
	const navigate = useNavigate();

	return (
		<Box>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">My Profile</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<AccountInformation
							formValues={formValues}
							handleOnChangeFormValue={handleOnChangeFormValue}
						/>
						<AdministratorInformation
							formValues={formValues}
							handleOnChangeFormValue={handleOnChangeFormValue}
							handleOnCheckBoxCLick={handleOnCheckBoxCLick}
						/>
						<MailingAndBillingInformation
							formValues={formValues}
							handleOnChangeFormValue={handleOnChangeFormValue}
						/>
					</Box>
				</Box>
			</main>
		</Box>
	);
};

export default MyProfile;
