import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Box, Button, Typography } from "@mui/material";
import { ArrowBack } from "assests/images";
import { PatientRecordTable } from "components";

const PatientRecord: React.FC = () => {
	// get query parameters
	const caseId = useParams()?.caseId || "";

	// Page level variable
	const navigate = useNavigate();

	return (
		<>
			<Box>
				<main className="main-content">
					<div
						className="overlay"
						onClick={() => document.body.classList.toggle("sidebar-toggle")}
					></div>
					<Box className="request-container-box">
						<div className="request-header">
							<Typography variant="h2">Patient Record</Typography>
							<Button variant="outlined" onClick={() => navigate(-1)}>
								<img src={ArrowBack} alt="arrow" />
								Back
							</Button>
						</div>
						<Box className="request-box">
							<div className="attachment">
								<Box
									className="selected-action-btn"
									sx={{ justifyContent: "flex-end", width: "100%" }}
								></Box>
							</div>
							<PatientRecordTable />
						</Box>
					</Box>
				</main>
			</Box>
		</>
	);
};

export default PatientRecord;
