import React, { useContext, useEffect, useState } from "react";
import { Box, Typography } from "@mui/material";
import { Constants } from "utility/enums/constants";
import { SortOrder } from "utility/enums/sort-order";
import {
	IPatientHistorySearchCriteria,
	IPatientHistory,
} from "utility/interfaces";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { PatientHistoryTable } from "components";

const PatientHistory: React.FC = () => {
	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// useStates
	const [patientHistoryPageInfo, setPatientHistoryPageInfo] =
		React.useState<IPatientHistory | null>(null);

	const [searchCriteria, setSearchCriteria] =
		useState<IPatientHistorySearchCriteria>({
			PageIndexId: 0,
			PageSize: Constants.DefaultTablePageSize.valueOf(),
			SortOrder: SortOrder.ascending,
			SortBy: "",
			SearchBy: "",
			firstName: "",
			lastName: "",
			email: "",
			phoneNumber: "",
		});

	// Handled events and functions
	const handleOnSearchCriteriaChange = (
		newSearchCriteria: IPatientHistorySearchCriteria
	) => {
		setSearchCriteria(newSearchCriteria);
	};
	const getHistoryPageGrids = async () => {
		console.log(searchCriteria);
		// const data = await createCommonAPICall({
		// 	requestBody: searchCriteria,
		// 	apiService: historyService.getSearchFields,
		// 	showSuccessMessage: false,
		// 	showErrorMessage: true,
		// 	setSuccessErrorContext,
		// });
		// if (data && data.data) setHistoryPageInfo(data.data);
		setPatientHistoryPageInfo({
			history: [
				{
					id: 1,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 1324,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 1222,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 133,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 13,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 112,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 122,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 12,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 111,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
				{
					id: 11,
					queryString: "Renish ribadiya",
					firstName: "Renish",
					lastName: "ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					phoneNumber: "+91 802181896",
					address:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
				},
			],
			totalRecords: 100,
		});
	};

	// useEffects
	useEffect(() => {
		getHistoryPageGrids();
	}, [searchCriteria]);

	return (
		<>
			<Box>
				<div className="chatbox-overlay"></div>
				<main className="main-content">
					<div
						className="overlay"
						onClick={() => document.body.classList.toggle("sidebar-toggle")}
					></div>
					<Box className="tab-item-header">
						<Typography variant="h2">Patient History</Typography>
					</Box>
					<PatientHistoryTable
						handleOnSearchCriteriaChange={handleOnSearchCriteriaChange}
						searchCriteria={searchCriteria}
						rowData={patientHistoryPageInfo}
					/>
				</main>
			</Box>
		</>
	);
};

export default PatientHistory;
