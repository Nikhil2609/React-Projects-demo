import React, { useContext, useEffect, useState } from "react";
import { Box, Button, Typography } from "@mui/material";
import { ExportallIcon } from "assests/images";
import { useNavigate } from "react-router-dom";
import { Constants } from "utility/enums/constants";
import { SortOrder } from "utility/enums/sort-order";
import {
	IRequestDataSearchCriteria,
	IHistoryRequestData,
} from "utility/interfaces";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { RequestDataTable } from "components";

const RequestData: React.FC = () => {
	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// useStates
	const [selectedRows, setSelectedRows] = React.useState<number[]>([]);
	const [requestDataPageInfo, setRequestDataPageInfo] =
		React.useState<IHistoryRequestData | null>(null);

	const [searchCriteria, setSearchCriteria] =
		useState<IRequestDataSearchCriteria>({
			PageIndexId: 0,
			PageSize: Constants.DefaultTablePageSize.valueOf(),
			SortOrder: SortOrder.ascending,
			SortBy: "",
			SearchBy: "",
			paymentStatus: 0,
			patientName: "",
			toDateOfService: "",
			fromDateOfService: "",
			requestType: 0,
			providerName: "",
			email: "",
			phoneNumber: "",
		});

	// Handled events and functions
	const handleOnSearchCriteriaChange = (
		newSearchCriteria: IRequestDataSearchCriteria
	) => {
		setSearchCriteria(newSearchCriteria);
	};
	const getHistoryPageGrids = async () => {
		console.log(searchCriteria);
		// const data = await createCommonAPICall({
		// 	requestBody: searchCriteria,
		// 	apiService: historyService.getSearchFields,
		// 	showSuccessMessage: false,
		// 	showErrorMessage: true,
		// 	setSuccessErrorContext,
		// });
		// if (data && data.data) setHistoryPageInfo(data.data);
		setRequestDataPageInfo({
			requests: [
				{
					id: 1,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 1324,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 1222,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 133,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 13,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 112,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 122,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 12,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 111,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
				{
					id: 11,
					queryString: "Renish ribadiya",
					patientName: "Renish ribadiya",
					phoneNumber: "Renish ribadiya",
					email: "renishkumar.ribadiya@tatvasoft.com",
					dateOfService: "Jun 8, 2018",
					caseCloseDate: "Jun 8, 2018",
					requestor: "Renish ribadiya",
					providerName: "Renish ribadiya",
					confirmation: "Renish ribadiya",
					zipCode: "888888",
					transactionId: "Renish ribadiya",
					status: "Renish ribadiya",
					address: "200 Ridgewood Road Baltimore, Maryland MD 21210",
					adminNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					cancelledByproviderNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					patientNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					providerNote:
						"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
					requestStatus: "Approved",
					transactionStatus: "Approved",
				},
			],
			totalRecords: 100,
		});
	};

	//Page level local variable
	const navigate = useNavigate();

	// useEffects
	useEffect(() => {
		getHistoryPageGrids();
	}, [searchCriteria]);

	return (
		<>
			<Box>
				<div className="chatbox-overlay"></div>
				<main className="main-content">
					<div
						className="overlay"
						onClick={() => document.body.classList.toggle("sidebar-toggle")}
					></div>
					<Box className="tab-item-header">
						<Typography variant="h2">Request Data</Typography>
						<Box className="tab-button-groups">
							<Button disabled={selectedRows.length === 0} variant="contained">
								<img src={ExportallIcon} alt="send history" />
								<span className="button-link">Export Data To Excel</span>
							</Button>
						</Box>
					</Box>
					<RequestDataTable
						handleOnSearchCriteriaChange={handleOnSearchCriteriaChange}
						searchCriteria={searchCriteria}
						rowData={requestDataPageInfo}
					/>
				</main>
			</Box>
		</>
	);
};

export default RequestData;
