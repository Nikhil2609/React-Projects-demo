import {
	Box,
	Button,
	Divider,
	FormControl,
	Grid,
	Hidden,
	IconButton,
	InputAdornment,
	InputLabel,
	Modal,
	OutlinedInput,
	Typography,
} from "@mui/material";
import {
	AccountIcon,
	ArrowBack,
	ArrowBackWhite,
	EyeClose,
	EyeOpen,
	LoginBanner,
	Logo,
	PasswordReset,
} from "assests/images";
import { LightDarkButton } from "components";
import React from "react";

const DesignerLoginPage: React.FC = () => {
	const [showPassword, setShowPassword] = React.useState(false);

	const handleClickShowPassword = () => setShowPassword((show) => !show);

	const handleMouseDownPassword = (event: { preventDefault: () => void }) => {
		event.preventDefault();
	};

	const [forgotPwd, setForgotPwd] = React.useState(false);

	const [open, setOpen] = React.useState(false);
	const handleOpen = () => setOpen(true);
	let handleClose = () => setOpen(false);

	return (
		<section className="login-wrapper">
			<Grid container className="login-container">
				<Hidden mdDown>
					<Grid item xs={12} md={6} className="login-banner">
						<img src={LoginBanner} alt="Banner" />
					</Grid>
				</Hidden>
				<Grid item xs={12} md={6} className="login-content-container">
					<LightDarkButton />
					<div className="login-content">
						<a href="/" className="logo" title="Doctors To You">
							<img src={Logo} alt="Doctors To You" />
						</a>
						<div className="login-content-form">
							{forgotPwd ? (
								<>
									<Typography variant="h1">Reset Your Password</Typography>
									<div
										className="login-form-control"
										style={{ display: "flex", flexDirection: "column" }}
									>
										<FormControl variant="outlined">
											<InputLabel htmlFor="username">Username</InputLabel>
											<OutlinedInput
												id="username"
												className="with-icon"
												endAdornment={
													<InputAdornment position="end">
														<IconButton edge="end">
															<img src={AccountIcon} alt="account" />
														</IconButton>
													</InputAdornment>
												}
												label="Username"
											/>
										</FormControl>
										<Button
											variant="contained"
											onClick={handleOpen}
											title="Reset Password"
										>
											Reset Password
										</Button>
										<Modal
											open={open}
											onClose={handleClose}
											className="reset-modal"
										>
											<Box>
												<img
													src={PasswordReset}
													alt="Done"
													className="reset-img"
												/>
												<Typography variant="h2">
													Forgot Password Confirmation.
												</Typography>
												<Typography variant="body1">
													We've sent an email to you to reset your password.
													Please follow the instructions in it.
												</Typography>
												<Button
													onClick={(e) => {
														setOpen(false);
														setForgotPwd(false);
													}}
													variant="contained"
													title="Back to Login"
													href="/"
												>
													<img src={ArrowBackWhite} alt="arrow" />
													Back to Login
												</Button>
											</Box>
										</Modal>
										<Button
											onClick={(e) => setForgotPwd(false)}
											className="back-login"
										>
											<img src={ArrowBack} alt="arrow" />
											Back to Login
										</Button>
									</div>
								</>
							) : (
								<>
									<Typography variant="h1">Sign in to your Account</Typography>
									<div
										className="login-form-control"
										style={{ display: "flex", flexDirection: "column" }}
									>
										<FormControl variant="outlined">
											<InputLabel htmlFor="username">Username</InputLabel>
											<OutlinedInput
												id="username"
												className="with-icon"
												endAdornment={
													<InputAdornment position="end">
														<IconButton
															edge="end"
															disableFocusRipple
															disableRipple
														>
															<img src={AccountIcon} alt="account" />
														</IconButton>
													</InputAdornment>
												}
												label="Username"
											/>
										</FormControl>
										<FormControl variant="outlined">
											<InputLabel htmlFor="password">Password</InputLabel>
											<OutlinedInput
												id="password"
												className="with-icon"
												type={showPassword ? "text" : "password"}
												endAdornment={
													<InputAdornment position="end">
														<IconButton
															onClick={handleClickShowPassword}
															onMouseDown={handleMouseDownPassword}
															edge="end"
															disableFocusRipple
															disableRipple
														>
															{showPassword ? (
																<img src={EyeClose} alt="show" />
															) : (
																<img src={EyeOpen} alt="hide" />
															)}
														</IconButton>
													</InputAdornment>
												}
												label="Password"
											/>
										</FormControl>
										<Button
											variant="contained"
											title="Sign In"
											href="/designer-dashboard"
											className="login-btn"
											disableElevation
											disableRipple
											disableFocusRipple
										>
											Sign In
										</Button>
										<Button
											onClick={(e) => setForgotPwd(true)}
											className="back-login"
										>
											Forgot password?
										</Button>
									</div>
								</>
							)}
						</div>
						<div className="login-links">
							<a href="#" title="Terms of Conditions">
								Terms of Conditions
							</a>
							<Divider orientation="vertical" variant="middle" flexItem />
							<a href="#" title="Privacy Policy">
								Privacy Policy
							</a>
						</div>
					</div>
				</Grid>
			</Grid>
		</section>
	);
};

export default DesignerLoginPage;
