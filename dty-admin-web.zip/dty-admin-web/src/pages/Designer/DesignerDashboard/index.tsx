import React from "react";
import DesignerHeader from "components/Designer/DesignerHeader";
import {
	Box,
	Button,
	Modal,
	Tab,
	Tabs,
	TextField,
	Typography,
} from "@mui/material";
import DesignerFooter from "components/Designer/DesignerFooter";
import {
	CheckedIconActive,
	CheckedIconDefault,
	CloseWhiteIcon,
	ConcludeIconActive,
	ConcludeIconDefault,
	DocRequestIcon,
	ExportallIcon,
	ExportIcon,
	NewIconActive,
	NewIconDefault,
	SendIcon,
	TocloseIconActive,
	TocloseIconDefault,
	UnpaidIconActive,
	UnpaidIconDefault,
	WorkingIconActive,
	WorkingIconDefault,
} from "assests/images";
import IconButton from "@mui/material/IconButton";
import DesignerTableComponent from "components/Designer/DesignerTable";

interface LinkTabProps {
	label?: any;
	onClick?: any;
}

function LinkTab(props: LinkTabProps) {
	return (
		<Tab
			component="a"
			disableFocusRipple
			disableTouchRipple
			disableRipple
			{...props}
		/>
	);
}

const style = {
	position: "absolute" as "absolute",
	top: "50%",
	left: "50%",
	transform: "translate(-50%, -50%)",
	bgcolor: "background.paper",
	boxShadow: "0px 0px 16px rgba(0, 0, 0, 0.1)",
	borderRadius: "10px",
};

const DesignerDashboard: React.FC = () => {
	const [value, setValue] = React.useState(0);

	const handleChange = (event: React.SyntheticEvent, newValue: number) => {
		setValue(newValue);
	};

	const [sendopen, setsendOpen] = React.useState(false);
	const handlesendOpen = () => setsendOpen(true);
	const handlesendClose = () => setsendOpen(false);

	const [tabval, setTabval] = React.useState("new");

	return (
		<Box>
			<div className="chatbox-overlay"></div>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Tabs value={value} onChange={handleChange} className="main-tabs">
					<LinkTab
						onClick={() => {
							setTabval("new");
						}}
						label={
							<React.Fragment>
								<Box className="tab-item new">
									<div className="tab-title">
										<img src={NewIconDefault} alt="new" className="default" />
										<img src={NewIconActive} alt="new" className="active" />
										New
									</div>
									<h2 className="counter">1428</h2>
								</Box>
							</React.Fragment>
						}
					/>
					<LinkTab
						onClick={() => {
							setTabval("working");
						}}
						label={
							<React.Fragment>
								<Box className="tab-item working">
									<div className="tab-title">
										<img
											src={WorkingIconDefault}
											alt="working"
											className="default"
										/>
										<img
											src={WorkingIconActive}
											alt="working"
											className="active"
										/>
										Working
									</div>
									<h2 className="counter">20</h2>
								</Box>
							</React.Fragment>
						}
					/>
					<LinkTab
						onClick={() => {
							setTabval("active");
						}}
						label={
							<React.Fragment>
								<Box className="tab-item active">
									<div className="tab-title">
										<img
											src={CheckedIconDefault}
											alt="new"
											className="default"
										/>
										<img src={CheckedIconActive} alt="new" className="active" />
										Active
									</div>
									<h2 className="counter">30</h2>
								</Box>
							</React.Fragment>
						}
					/>
					<LinkTab
						onClick={() => {
							setTabval("conclude");
						}}
						label={
							<React.Fragment>
								<Box className="tab-item conclude">
									<div className="tab-title">
										<img
											src={ConcludeIconDefault}
											alt="new"
											className="default"
										/>
										<img
											src={ConcludeIconActive}
											alt="new"
											className="active"
										/>
										Conclude
									</div>
									<h2 className="counter">1049</h2>
								</Box>
							</React.Fragment>
						}
					/>
					<LinkTab
						onClick={() => {
							setTabval("unpaid");
						}}
						label={
							<React.Fragment>
								<Box className="tab-item to-close">
									<div className="tab-title">
										<img
											src={TocloseIconDefault}
											alt="new"
											className="default"
										/>
										<img src={TocloseIconActive} alt="new" className="active" />
										To Close
									</div>
									<h2 className="counter">513</h2>
								</Box>
							</React.Fragment>
						}
					/>
					<LinkTab
						onClick={() => {
							setTabval("to-close");
						}}
						label={
							<React.Fragment>
								<Box className="tab-item unpaid">
									<div className="tab-title">
										<img
											src={UnpaidIconDefault}
											alt="new"
											className="default"
										/>
										<img src={UnpaidIconActive} alt="new" className="active" />
										Unpaid
									</div>
									<h2 className="counter">127</h2>
								</Box>
							</React.Fragment>
						}
					/>
				</Tabs>
				<Box className="tab-item-header">
					<Typography variant="h2">
						Patients
						{tabval === "new" && <span className={tabval}>&#40;New&#41;</span>}
						{tabval === "working" && (
							<span className={tabval}>&#40;Working&#41;</span>
						)}
						{tabval === "active" && (
							<span className={tabval}>&#40;Active&#41;</span>
						)}
						{tabval === "conclude" && (
							<span className={tabval}>&#40;Conclude&#41;</span>
						)}
						{tabval === "to-close" && (
							<span className={tabval}>&#40;To Close&#41;</span>
						)}
					</Typography>
					<Box className="tab-button-groups">
						<Button
							variant="contained"
							onClick={handlesendOpen}
							disableElevation
							disableRipple
							disableFocusRipple
						>
							<img src={SendIcon} alt="send link" />
							<span className="button-link">Send Link </span>
						</Button>
						<Button
							variant="contained"
							href="/designer-dashboard/create-request"
							disableElevation
							disableRipple
							disableFocusRipple
						>
							<img src={DocRequestIcon} alt="Create Request" />
							<span className="button-link">Create Requests</span>
						</Button>
						<Button
							variant="contained"
							disableElevation
							disableRipple
							disableFocusRipple
						>
							<img src={ExportIcon} alt="export" />
							<span className="button-link">Export</span>
						</Button>
						<Button
							variant="contained"
							disableElevation
							disableRipple
							disableFocusRipple
						>
							<img src={ExportallIcon} alt="export" />
							<span className="button-link">Export All</span>
						</Button>
					</Box>
				</Box>
				<DesignerTableComponent tabvalue={tabval} />
			</main>
			<DesignerFooter />
			<Modal open={sendopen} onClose={handlesendClose} className="send-modal">
				<Box sx={style}>
					<Box className="modal-header">
						<Typography variant="h5">
							Send mail to patient for submitting request{" "}
						</Typography>
						<IconButton onClick={handlesendClose}>
							<img src={CloseWhiteIcon} alt="/" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<TextField
								id="first-name"
								label="First Name"
								variant="outlined"
							/>
							<TextField id="last-name" label="Last Name" variant="outlined" />
							<TextField
								id="ph-number"
								type="tel"
								label="Phone Number"
								variant="outlined"
							/>
							<TextField
								id="email"
								type="email"
								label="Email"
								variant="outlined"
							/>
						</div>
						<div className="modal-footer">
							<Button variant="contained" onClick={handlesendClose}>
								Send
							</Button>
							<Button variant="outlined" onClick={handlesendClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
		</Box>
	);
};

export default DesignerDashboard;
