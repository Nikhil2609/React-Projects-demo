import React from "react";
import {
	Box,
	Button,
	Divider,
	FormControl,
	Grid,
	IconButton,
	InputAdornment,
	InputLabel,
	MenuItem,
	Modal,
	OutlinedInput,
	Select,
	SelectChangeEvent,
	TextField,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	CalendarDarkIcon,
	CallIconPrimary,
	CloseWhiteIcon,
	LocationIcon,
	SmartphoneIcon,
} from "assests/images";
import dayjs, { Dayjs } from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";
import { DesktopDatePicker } from "@mui/x-date-pickers";

function datepickerIcon() {
	return (
		<>
			<img src={CalendarDarkIcon} alt="calendar" />
		</>
	);
}
const style = {
	position: "absolute" as "absolute",
	top: "50%",
	left: "50%",
	transform: "translate(-50%, -50%)",
	bgcolor: "background.paper",
	boxShadow: "0px 0px 16px rgba(0, 0, 0, 0.1)",
	borderRadius: "10px",
};

const DesignerViewCase: React.FC = () => {
	const [value, setValue] = React.useState<Dayjs | null>(dayjs("1992-08-31"));
	const [edit, setEdit] = React.useState(false);
	const [transferopen, settransferopen] = React.useState(false);
	const handletransferopen = () => settransferopen(true);
	const handletransferClose = () => settransferopen(false);
	const [region, setregion] = React.useState("");

	const handleChange = (event: SelectChangeEvent) => {
		setregion(event.target.value as string);
	};
	const [physician, setphysician] = React.useState("");

	const handlePhysicianChange = (event: SelectChangeEvent) => {
		setphysician(event.target.value as string);
	};
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">
							New Request <span>Patient</span>
						</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div>
							<Typography variant="h4">Patient Information</Typography>
							<div className="confirm-number">
								<label>Confirmation Number</label>
								<Typography variant="h4">DC010423SARA0002</Typography>
							</div>
							<TextField
								id="physican-notes"
								label="Patient Notes"
								value="Hey Gary, This is a test from Carlos Fenwick"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
								disabled
							/>
						</div>
						<Divider />
						<div>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="first-name"
										label="First Name"
										variant="outlined"
										defaultValue="Rajesh"
										disabled={edit ? false : true}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
										defaultValue="Satvara"
										disabled={edit ? false : true}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<LocalizationProvider dateAdapter={AdapterDayjs}>
										<DesktopDatePicker
											label="Date of Birth"
											value={value}
											disabled={edit ? false : true}
											onChange={(newValue) => {
												setValue(newValue);
											}}
											components={{
												OpenPickerIcon: datepickerIcon,
											}}
											inputFormat="DD/MM/YYYY"
											renderInput={(params) => (
												<TextField
													{...params}
													className="datepicker"
													fullWidth
													// onClick={(e) => setOpen(true)}
													id="dob"
													autoComplete="off"
													inputProps={{
														...params.inputProps,
													}}
												/>
											)}
										/>
									</LocalizationProvider>
								</Grid>
								<Grid item xs={12} sm={6}>
									<div className="input-with-button">
										<FormControl variant="outlined" fullWidth>
											<InputLabel htmlFor="phone-num">Phone Number</InputLabel>
											<OutlinedInput
												id="phone-num"
												type="tel"
												defaultValue="(147) 147 - 1470"
												disabled={edit ? false : true}
												fullWidth
												className="with-icon"
												endAdornment={
													<InputAdornment position="end">
														<IconButton
															edge="end"
															disableFocusRipple
															disableRipple
														>
															<img src={SmartphoneIcon} alt="phone" />
														</IconButton>
													</InputAdornment>
												}
												label="phone-num"
											/>
										</FormControl>
										<IconButton>
											<img src={CallIconPrimary} alt="call" />
										</IconButton>
									</div>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="email"
										label="Email"
										variant="outlined"
										defaultValue="rajesh.sathvara@tatvasoft.com"
										disabled={edit ? false : true}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									{edit ? (
										<div className="verify-btn-group">
											<Button
												variant="contained"
												onClick={(e) => setEdit(false)}
											>
												Save
											</Button>
											<Button
												variant="outlined"
												onClick={(e) => setEdit(false)}
											>
												Cancel
											</Button>
										</div>
									) : (
										<div className="verify-btn-group">
											<Button variant="outlined" onClick={(e) => setEdit(true)}>
												Edit
											</Button>
										</div>
									)}
								</Grid>
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Location Information</Typography>
							<div>
								<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="region"
											label="Region"
											variant="outlined"
											value="District of Columbia"
											disabled
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<div className="input-with-button">
											<TextField
												fullWidth
												id="business-add"
												label="Business Name/Address"
												variant="outlined"
												value="1623 R Street NW,  Washington, DC - 20009"
												disabled
											/>
											<IconButton>
												<img src={LocationIcon} alt="location" />
											</IconButton>
										</div>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="room"
											label="Room #"
											variant="outlined"
											disabled
										/>
									</Grid>
								</Grid>
							</div>
						</div>
						<div className="request-btn-group">
							<Button variant="contained" onClick={handletransferopen}>
								Assign
							</Button>
							<Button variant="contained" href="/designer-dashboard/view-notes">
								View Notes
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
			<Modal
				open={transferopen}
				onClose={handletransferClose}
				className="send-modal"
			>
				<Box sx={style}>
					<Box className="modal-header">
						<Typography variant="h5">Transfer Request</Typography>
						<IconButton onClick={handletransferClose}>
							<img src={CloseWhiteIcon} alt="/" />
						</IconButton>
					</Box>
					<Box className="modal-body">
						<div>
							<Typography variant="body1" className="instruction">
								To transfer this request, search and select another Physician.
							</Typography>
							<FormControl fullWidth>
								<InputLabel id="region-label">
									Narrow Search by Region
								</InputLabel>
								<Select
									labelId="region-label"
									id="region"
									value={region}
									label="Narrow Search by Region"
									onChange={handleChange}
									MenuProps={{
										className: "select-input-modal",
									}}
								>
									<MenuItem value={1}>Item 1</MenuItem>
									<MenuItem value={2}>Item 2</MenuItem>
									<MenuItem value={3}>Item 3</MenuItem>
								</Select>
							</FormControl>
							<FormControl fullWidth>
								<InputLabel id="physician-label">Select Physician</InputLabel>
								<Select
									labelId="physician-label"
									id="physician"
									value={physician}
									label="Select Physician"
									onChange={handlePhysicianChange}
									className="select-input"
									MenuProps={{
										className: "select-input-modal",
									}}
								>
									<MenuItem value={1}>Item 1</MenuItem>
									<MenuItem value={2}>Item 2</MenuItem>
									<MenuItem value={3}>Item 3</MenuItem>
								</Select>
							</FormControl>
							<TextField
								id="block"
								label="Description"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="modal-footer">
							<Button variant="contained" onClick={handletransferClose}>
								Submit
							</Button>
							<Button variant="outlined" onClick={handletransferClose}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</Modal>
		</Box>
	);
};

export default DesignerViewCase;
