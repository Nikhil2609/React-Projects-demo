import React from "react";
import {
	Box,
	Button,
	FormControl,
	Grid,
	Hidden,
	InputAdornment,
	InputLabel,
	OutlinedInput,
	TextField,
	Typography,
} from "@mui/material";
import { ArrowBack, DollarIcon } from "assests/images";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";

const DesignerItemizedCosts: React.FC = () => {
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Itemized Costs</Typography>
						<Button variant="outlined" href="/designer-dashboard/close-case">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div>
							<Typography variant="h1" className="total-cost">
								$15.25
							</Typography>
							<Typography variant="h6" className="total-cost-label">
								Total Cost of Care
							</Typography>
							<Grid
								container
								maxWidth="768px"
								mx="auto"
								rowSpacing={{ xs: "30px", md: "10px" }}
							>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">House Call</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="house-call">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="house-call"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="house-call-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Travel</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="travel">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="travel"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="travel-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">After Hours</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="after-hrs">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="after-hrs"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="after-hrs-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Weekend</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="weekend">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="weekend"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="weekend-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Holiday</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="holiday">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="holiday"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="holiday-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Medication</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="medication">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="medication"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="medication-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Supplies</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="supplies">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="supplies"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="supplies-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Procedures</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="procedure">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="procedure"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="procedure-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Diagnostics</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="diagnostics">
													Enter Cost
												</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="diagnostics"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="diagnostics-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={12}>
									<Grid
										container
										className="itemized-subdata-container"
										columnSpacing="10px"
										rowSpacing="14px"
										alignItems="center"
									>
										<Grid item xs={4} sm={2}>
											<Typography variant="body1">Other</Typography>
										</Grid>
										<Grid item xs={8} sm={10} md={3}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="other">Enter Cost</InputLabel>
												<OutlinedInput
													label="Enter Cost"
													id="other"
													endAdornment={
														<InputAdornment position="end">
															<img src={DollarIcon} alt="dollar" />
														</InputAdornment>
													}
												/>
											</FormControl>
										</Grid>
										<Hidden smDown mdUp>
											<Grid item xs={12} sm={2}></Grid>
										</Hidden>
										<Grid item xs={12} sm={10} md={7}>
											<TextField
												id="other-desc"
												label="Description"
												variant="outlined"
												fullWidth
											/>
										</Grid>
									</Grid>
								</Grid>
							</Grid>
						</div>
						<div className="request-btn-group itemized-btn-group">
							<Button variant="contained" href="/designer-dashboard">
								Submit
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerItemizedCosts;
