import React from "react";
import {
	Box,
	Button,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	SelectChangeEvent,
	TextField,
	Typography,
} from "@mui/material";
import { ArrowBack } from "assests/images";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";

const DesignerOrders: React.FC = () => {
	const [business, setbusiness] = React.useState("");

	const handleBusinessChange = (event: SelectChangeEvent) => {
		setbusiness(event.target.value as string);
	};
	const [refill, setrefill] = React.useState("");

	const handlerefillChange = (event: SelectChangeEvent) => {
		setrefill(event.target.value as string);
	};
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Send Order</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div className="orders-input-container">
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<FormControl fullWidth className="select-input">
										<InputLabel id="business-label">
											Select Business Name
										</InputLabel>
										<Select
											labelId="business-label"
											id="business-name"
											value={business}
											label="Select Business Name"
											onChange={handleBusinessChange}
											MenuProps={{
												className: "select-input-modal",
											}}
										>
											<MenuItem value={1}>Item 1</MenuItem>
											<MenuItem value={2}>Item 2</MenuItem>
											<MenuItem value={3}>Item 3</MenuItem>
										</Select>
									</FormControl>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="email"
										label="Email"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="fax-num"
										label="Fax Number"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12}>
									<TextField
										id="physican-notes"
										label="Prescription or Order details"
										multiline
										className="textarea"
										maxRows={1}
										inputProps={{
											style: {
												minHeight: "80px",
												overflow: "auto",
											},
										}}
										fullWidth
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<FormControl fullWidth className="select-input">
										<InputLabel id="refill-label">Number Of Refill</InputLabel>
										<Select
											labelId="refill-label"
											id="refill-name"
											value={refill}
											label="Number Of Refill"
											onChange={handlerefillChange}
											MenuProps={{
												className: "select-input-modal",
											}}
										>
											<MenuItem value={1}>Item 1</MenuItem>
											<MenuItem value={2}>Item 2</MenuItem>
											<MenuItem value={3}>Item 3</MenuItem>
										</Select>
									</FormControl>
								</Grid>
							</Grid>
						</div>
						<div className="request-btn-group orders-btn-group">
							<Button variant="contained" href="/designer-dashboard">
								Submit
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerOrders;
