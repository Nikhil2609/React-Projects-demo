import React from "react";
import { Box, Button, Grid, Typography } from "@mui/material";
import DesignerFooter from "components/Designer/DesignerFooter";
import {
	AdministratorIcon,
	ArrowBack,
	DoctorDarkIcon,
	PatientDarkIcon,
	TransferIcon,
} from "assests/images";
import DesignerHeader from "components/Designer/DesignerHeader";

const DesignerViewNotes: React.FC = () => {
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Notes</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Grid container spacing={3}>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={PatientDarkIcon} alt="patient" />
								<div>
									<Typography variant="h6">Patient Notes</Typography>
									<Typography variant="body1">
										Lorem ipsum dolor sit amet consectetur. Ut velit mauris urna
										facilisis et.
									</Typography>
								</div>
							</Box>
						</Grid>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={TransferIcon} alt="transfer" />
								<div>
									<Typography variant="h6">Transfer Notes</Typography>
									<ol>
										<li>
											<Typography variant="body1">
												Admin transferred to Dr. Patel on 01/01/2023 at 11:34:30
												PM : aaa
											</Typography>
										</li>
										<li>
											<Typography variant="body1">
												Admin transferred to Dr. AGOLA on 01/01/2023 at 11:36:00
												PM : aa
											</Typography>
										</li>
									</ol>
								</div>
							</Box>
						</Grid>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={DoctorDarkIcon} alt="Doctor" />
								<div>
									<Typography variant="h6">Physician Notes</Typography>
									<Typography variant="body1">
										Lorem ipsum dolor sit amet consectetur. Ut velit mauris urna
										facilisis et.
									</Typography>
								</div>
							</Box>
						</Grid>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={AdministratorIcon} alt="Administrator" />
								<div>
									<Typography variant="h6">Admin Notes</Typography>
									<Typography variant="body1">-</Typography>
								</div>
							</Box>
						</Grid>
					</Grid>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerViewNotes;
