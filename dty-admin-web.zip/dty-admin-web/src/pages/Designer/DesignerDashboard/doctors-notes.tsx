import React from "react";
import {
	Box,
	Button,
	Checkbox,
	Divider,
	FormControl,
	FormControlLabel,
	FormGroup,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	SelectChangeEvent,
	Tab,
	Tabs,
	TextField,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	CalendarDarkIcon,
	CheckIcon,
	RadioCheckIcon,
	RadioUncheckIcon,
	RadioUncheckIconDark,
	UncheckIcon,
} from "assests/images";
import { Dayjs } from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";
import { DesktopDatePicker } from "@mui/x-date-pickers";

function datepickerIcon() {
	return (
		<>
			<img src={CalendarDarkIcon} alt="calendar" />
		</>
	);
}

interface TabPanelProps {
	children?: React.ReactNode;
	index: number;
	value: number;
}

function TabPanel(props: TabPanelProps) {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`radio-tabpanel-${index}`}
			aria-labelledby={`radio-tab-${index}`}
			{...other}
		>
			{value === index && (
				<Box className="radio-tab-content">
					<>{children}</>
				</Box>
			)}
		</div>
	);
}

function a11yProps(index: number) {
	return {
		id: `radio-tab-${index}`,
		"aria-controls": `radio-tabpanel-${index}`,
	};
}

function CheckboxIcon() {
	return <img src={UncheckIcon} alt="checkbox" />;
}
function CheckedboxIcon() {
	return <img src={CheckIcon} alt="checkbox" />;
}

const DesignerDoctorsNote: React.FC = () => {
	const [value, setValue] = React.useState<Dayjs | null>(null);
	const [Examvalue, setExamValue] = React.useState<Dayjs | null>(null);

	const [radiotabvalue, setradiotabValue] = React.useState(4);

	const handleTab = (event: React.SyntheticEvent, newValue: number) => {
		setradiotabValue(newValue);
	};
	const [business, setbusiness] = React.useState("");

	const handleBusinessChange = (event: SelectChangeEvent) => {
		setbusiness(event.target.value as string);
	};

	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Physician Recommendations</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div>
							<Typography variant="h4">Patient Information</Typography>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="first-name"
										label="First Name"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<LocalizationProvider dateAdapter={AdapterDayjs}>
										<DesktopDatePicker
											label="Date of Birth"
											value={value}
											inputFormat="DD/MM/YYYY"
											onChange={(newValue) => {
												setValue(newValue);
											}}
											components={{
												OpenPickerIcon: datepickerIcon,
											}}
											renderInput={(params) => (
												<TextField
													{...params}
													fullWidth
													id="dob"
													className="datepicker"
													autoComplete="off"
													inputProps={{
														...params.inputProps,
													}}
												/>
											)}
										/>
									</LocalizationProvider>
								</Grid>
								<Grid item xs={12} sm={6}>
									<LocalizationProvider dateAdapter={AdapterDayjs}>
										<DesktopDatePicker
											label="Date of Examination"
											value={Examvalue}
											inputFormat="DD/MM/YYYY"
											onChange={(newValue) => {
												setExamValue(newValue);
											}}
											components={{
												OpenPickerIcon: datepickerIcon,
											}}
											renderInput={(params) => (
												<TextField
													{...params}
													fullWidth
													id="date-of-exam"
													className="datepicker"
													autoComplete="off"
													inputProps={{
														...params.inputProps,
													}}
												/>
											)}
										/>
									</LocalizationProvider>
								</Grid>
							</Grid>
						</div>
						<div className="radio-tab-container">
							<Box className="radio-tabs">
								<Tabs
									value={radiotabvalue}
									onChange={handleTab}
									variant="scrollable"
									scrollButtons="auto"
								>
									<Tab
										disableFocusRipple
										disableRipple
										label={
											<React.Fragment>
												<img
													src={RadioCheckIcon}
													alt="radio"
													className="checked-icon"
												/>
												<img
													src={RadioUncheckIcon}
													alt="radio"
													className="check-icon light-icon"
												/>
												<img
													src={RadioUncheckIconDark}
													alt="radio"
													className="check-icon dark-icon"
												/>
												May Resume
											</React.Fragment>
										}
										{...a11yProps(0)}
									/>
									<Tab
										disableFocusRipple
										disableRipple
										label={
											<React.Fragment>
												<img
													src={RadioCheckIcon}
													alt="radio"
													className="checked-icon"
												/>
												<img
													src={RadioUncheckIcon}
													alt="radio"
													className="check-icon light-icon"
												/>
												<img
													src={RadioUncheckIconDark}
													alt="radio"
													className="check-icon dark-icon"
												/>
												May Not Resume
											</React.Fragment>
										}
										{...a11yProps(1)}
									/>
								</Tabs>
							</Box>
							<TabPanel value={radiotabvalue} index={0}>
								<FormControl component="fieldset" className="radio-inputs">
									<FormGroup row>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Travel"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Flight"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="School"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Work"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Sports"
											labelPlacement="end"
										/>
									</FormGroup>
								</FormControl>
								<div>
									<TextField
										id="others"
										label="Others"
										multiline
										maxRows={1}
										inputProps={{
											style: {
												minHeight: "80px",
												overflow: "auto",
											},
										}}
										fullWidth
										className="radio-inputs textarea"
									/>
								</div>
								<Grid container sx={{ marginBottom: "-1px" }}>
									<Grid item xs={12} sm={6}>
										<LocalizationProvider dateAdapter={AdapterDayjs}>
											<DesktopDatePicker
												label="On Date"
												value={Examvalue}
												inputFormat="DD/MM/YYYY"
												onChange={(newValue) => {
													setExamValue(newValue);
												}}
												components={{
													OpenPickerIcon: datepickerIcon,
												}}
												renderInput={(params) => (
													<TextField
														{...params}
														fullWidth
														id="date-of-exam"
														className="datepicker radio-inputs"
														autoComplete="off"
														inputProps={{
															...params.inputProps,
														}}
													/>
												)}
											/>
										</LocalizationProvider>
									</Grid>
								</Grid>
							</TabPanel>
							<TabPanel value={radiotabvalue} index={1}>
								<FormControl component="fieldset" className="radio-inputs">
									<FormGroup row>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Travel"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Flight"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
													defaultChecked
												/>
											}
											label="School"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
												/>
											}
											label="Work"
											labelPlacement="end"
										/>
										<FormControlLabel
											value="end"
											control={
												<Checkbox
													disableFocusRipple
													disableRipple
													icon={<CheckboxIcon />}
													checkedIcon={<CheckedboxIcon />}
													defaultChecked
												/>
											}
											label="Sports"
											labelPlacement="end"
										/>
									</FormGroup>
								</FormControl>
								<div>
									<TextField
										id="others"
										label="Others"
										multiline
										maxRows={1}
										inputProps={{
											style: {
												minHeight: "80px",
												overflow: "auto",
											},
										}}
										fullWidth
										className="radio-inputs textarea"
									/>
								</div>
								<Typography variant="body1" className="input-title">
									Until condition has improved in days after examination:
								</Typography>
								<Grid container sx={{ marginBottom: "-1px" }}>
									<Grid item xs={12} sm={6}>
										<FormControl
											fullWidth
											className="select-input radio-inputs"
										>
											<InputLabel id="business-label">
												Select Business Name
											</InputLabel>
											<Select
												labelId="business-label"
												id="business-name"
												value={business}
												label="Select Business Name"
												onChange={handleBusinessChange}
												MenuProps={{
													className: "select-input-modal",
												}}
											>
												<MenuItem value={1}>Item 1</MenuItem>
												<MenuItem value={2}>Item 2</MenuItem>
												<MenuItem value={3}>Item 3</MenuItem>
											</Select>
										</FormControl>
									</Grid>
								</Grid>
							</TabPanel>
						</div>
						<Divider />
						<div>
							<TextField
								id="restriction"
								label="Restriction or Accommodations"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="request-btn-group orders-btn-group">
							<Button variant="contained" href="/designer-dashboard">
								Save
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerDoctorsNote;
