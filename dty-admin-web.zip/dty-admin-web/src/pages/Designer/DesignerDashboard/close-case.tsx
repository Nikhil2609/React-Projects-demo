import React from "react";
import {
	Box,
	Button,
	Collapse,
	FormControl,
	Grid,
	Hidden,
	IconButton,
	InputAdornment,
	InputLabel,
	OutlinedInput,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	TextField,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	CalendarDarkIcon,
	CallIconPrimary,
	DownloadIcon,
	SmartphoneIcon,
} from "assests/images";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import dayjs, { Dayjs } from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import moment from "moment";
import { visuallyHidden } from "@mui/utils";

interface Data {
	doc: string;
	uploadDate: string;
	file: any;
}

function createData(doc: string, uploadDate: string, file: any): Data {
	return {
		doc,
		uploadDate,
		file,
	};
}

const rows = [
	createData(
		"Zoll_Genehmigung.doc",
		"2018-02-10",
		<img
			src={require("../../../assests/images/ic-doc-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Mietvertrag_Hohenzollernstraße.pdf",
		"2012-05-19",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Führungszeugnis.pdf",
		"2006-10-09",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
];

function datepickerIcon() {
	return (
		<>
			<img src={CalendarDarkIcon} alt="calendar" />
		</>
	);
}

interface HeadCell {
	id: keyof Data;
	label: string;
}

const headCells: readonly HeadCell[] = [
	{
		id: "uploadDate",
		label: "Upload Date",
	},
];

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
	if (b[orderBy] < a[orderBy]) {
		return -1;
	}
	if (b[orderBy] > a[orderBy]) {
		return 1;
	}
	return 0;
}

type Order = "asc" | "desc";

function getComparator<Key extends keyof any>(
	order: Order,
	orderBy: Key
): (a: { [key in Key]: string }, b: { [key in Key]: string }) => number {
	return order === "desc"
		? (a, b) => descendingComparator(a, b, orderBy)
		: (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort<T>(
	array: readonly T[],
	comparator: (a: T, b: T) => number
) {
	const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
	stabilizedThis.sort((a, b) => {
		const order = comparator(a[0], b[0]);
		if (order !== 0) {
			return order;
		}
		return a[1] - b[1];
	});
	return stabilizedThis.map((el) => el[0]);
}

interface EnhancedTableProps {
	onRequestSort: (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => void;
	order: Order;
	orderBy: string;
}

function EnhancedTableHead(props: EnhancedTableProps) {
	const { order, orderBy, onRequestSort } = props;
	const createSortHandler =
		(property: keyof Data) => (event: React.MouseEvent<unknown>) => {
			onRequestSort(event, property);
		};

	return (
		<TableHead>
			<TableRow>
				<TableCell align="center" sx={{ minWidth: 210 }}></TableCell>
				{headCells.map((headCell) => (
					<TableCell
						key={headCell.id}
						sortDirection={orderBy === headCell.id ? order : false}
						sx={{ minWidth: 160 }}
					>
						<TableSortLabel
							active={orderBy === headCell.id}
							direction={orderBy === headCell.id ? order : "asc"}
							onClick={createSortHandler(headCell.id)}
						>
							{headCell.label}
							{orderBy === headCell.id ? (
								<Box component="span" sx={visuallyHidden}>
									{order === "desc" ? "sorted descending" : "sorted ascending"}
								</Box>
							) : null}
						</TableSortLabel>
					</TableCell>
				))}
				<TableCell align="center" sx={{ width: 142 }}>
					Actions
				</TableCell>
			</TableRow>
		</TableHead>
	);
}

const DesignerCloseCase: React.FC = () => {
	const [encounterOpen, setEncounterOpen] = React.useState(false);

	const handleEncounterClick = () => {
		setEncounterOpen(!encounterOpen);
	};
	const [value, setValue] = React.useState<Dayjs | null>(dayjs("1992-08-31"));
	const [order, setOrder] = React.useState<Order>("asc");
	const [orderBy, setOrderBy] = React.useState<keyof Data>("uploadDate");

	const handleRequestSort = (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => {
		const isAsc = orderBy === property && order === "asc";
		setOrder(isAsc ? "desc" : "asc");
		setOrderBy(property);
	};
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Close Case</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div className="request-box-header">
							<div className="confirm-number uploaded-data">
								<label>Patient Name</label>
								<Typography variant="h4">
									Rajesh Satvara <span>&nbsp;&#40;DC010423SARA0002&#41;</span>
								</Typography>
							</div>
							<Hidden smDown smUp>
								<div className="close-case-btn-group">
									<Button
										variant="outlined"
										disableElevation
										disableFocusRipple
										disableRipple
										onClick={handleEncounterClick}
										className={
											encounterOpen ? "btn-encounter" : "btn-encounter-show"
										}
									>
										{encounterOpen ? "Hide Encounter" : "Review Encounter"}
									</Button>
									<Button
										variant="outlined"
										disableElevation
										disableFocusRipple
										disableRipple
										className="btn-costs"
										href="/designer-dashboard/close-case/itemized-costs"
									>
										Enter Costs
									</Button>
								</div>
							</Hidden>
						</div>
						<div className="attachment">
							<Typography variant="h4">Documents</Typography>
						</div>
						<TableContainer className="upload-table-container conclude-table-container">
							<Table className="upload-table conclude-table">
								<EnhancedTableHead
									order={order}
									orderBy={orderBy}
									onRequestSort={handleRequestSort}
								/>
								<TableBody>
									{stableSort(rows, getComparator(order, orderBy)).map(
										(row, index) => {
											return (
												<TableRow hover tabIndex={-1} key={row.doc}>
													<TableCell
														component="th"
														scope="row"
														className="upload-file-col"
													>
														<div className="upload-file">
															{row.file}
															<span>{row.doc}</span>
														</div>
													</TableCell>
													<TableCell>
														{moment(row.uploadDate).format("MMM D, YYYY")}
													</TableCell>
													<TableCell align="center">
														<div className="upload-actions">
															<IconButton disableFocusRipple disableRipple>
																<img src={DownloadIcon} alt="download" />
															</IconButton>
														</div>
													</TableCell>
												</TableRow>
											);
										}
									)}
								</TableBody>
							</Table>
						</TableContainer>
						<div>
							<Typography variant="h4">Patient Information</Typography>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="first-name"
										label="First Name"
										variant="outlined"
										value="Rajesh"
										disabled
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
										value="Satvara"
										disabled
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<LocalizationProvider dateAdapter={AdapterDayjs}>
										<DesktopDatePicker
											label="Date of Birth"
											value={value}
											inputFormat="DD/MM/YYYY"
											disabled
											onChange={(newValue) => {
												setValue(newValue);
											}}
											components={{
												OpenPickerIcon: datepickerIcon,
											}}
											renderInput={(params) => (
												<TextField
													{...params}
													className="datepicker"
													fullWidth
													// onClick={(e) => setOpen(true)}
													id="dob"
													autoComplete="off"
													inputProps={{
														...params.inputProps,
													}}
												/>
											)}
										/>
									</LocalizationProvider>
								</Grid>
								<Grid item xs={12} sm={6}>
									<div className="input-with-button">
										<FormControl variant="outlined" fullWidth>
											<InputLabel htmlFor="phone-num">Phone Number</InputLabel>
											<OutlinedInput
												id="phone-num"
												type="tel"
												value="(147) 147 - 1470"
												disabled
												fullWidth
												className="with-icon"
												endAdornment={
													<InputAdornment position="end">
														<IconButton
															edge="end"
															disableFocusRipple
															disableRipple
														>
															<img src={SmartphoneIcon} alt="phone" />
														</IconButton>
													</InputAdornment>
												}
												label="phone-num"
											/>
										</FormControl>
										<IconButton>
											<img src={CallIconPrimary} alt="call" />
										</IconButton>
									</div>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="email"
										label="Email"
										variant="outlined"
										value="rajesh.sathvara@tatvasoft.com"
										disabled
									/>
								</Grid>
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Requester</Typography>
							<div>
								<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="full-name"
											label="Full Name"
											variant="outlined"
											value="Rajesh Shah"
											disabled
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<FormControl variant="outlined" fullWidth>
											<InputLabel htmlFor="phone-num2">Phone Number</InputLabel>
											<OutlinedInput
												id="phone-num2"
												type="tel"
												value="(147) 147 - 1470"
												disabled
												fullWidth
												className="with-icon"
												endAdornment={
													<InputAdornment position="end">
														<IconButton
															edge="end"
															disableFocusRipple
															disableRipple
														>
															<img src={SmartphoneIcon} alt="phone" />
														</IconButton>
													</InputAdornment>
												}
												label="phone-num"
											/>
										</FormControl>
									</Grid>
								</Grid>
							</div>
						</div>
						<div className="request-btn-group">
							<Button variant="contained" href="/designer-dashboard">
								Save
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerCloseCase;
