import React from "react";
import {
	Box,
	Button,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	TextField,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	DeleteIcon,
	DownloadIcon,
	UploadcloudBlueIcon,
	UploadcloudIcon,
} from "assests/images";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";
import moment from "moment";
import { visuallyHidden } from "@mui/utils";

interface Data {
	doc: string;
	uploadDate: string;
	file: any;
}

function createData(doc: string, uploadDate: string, file: any): Data {
	return {
		doc,
		uploadDate,
		file,
	};
}

const rows = [
	createData(
		"Zoll_Genehmigung.doc",
		"2002-05-30",
		<img
			src={require("../../../assests/images/ic-doc-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Mietvertrag_Hohenzollernstraße.pdf",
		"2002-05-22",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Führungszeugnis.pdf",
		"2000-03-21",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
];

interface HeadCell {
	id: keyof Data;
	label: string;
}

const headCells: readonly HeadCell[] = [
	{
		id: "uploadDate",
		label: "Upload Date",
	},
];

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
	if (b[orderBy] < a[orderBy]) {
		return -1;
	}
	if (b[orderBy] > a[orderBy]) {
		return 1;
	}
	return 0;
}

type Order = "asc" | "desc";

function getComparator<Key extends keyof any>(
	order: Order,
	orderBy: Key
): (a: { [key in Key]: string }, b: { [key in Key]: string }) => number {
	return order === "desc"
		? (a, b) => descendingComparator(a, b, orderBy)
		: (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort<T>(
	array: readonly T[],
	comparator: (a: T, b: T) => number
) {
	const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
	stabilizedThis.sort((a, b) => {
		const order = comparator(a[0], b[0]);
		if (order !== 0) {
			return order;
		}
		return a[1] - b[1];
	});
	return stabilizedThis.map((el) => el[0]);
}

interface EnhancedTableProps {
	onRequestSort: (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => void;
	order: Order;
	orderBy: string;
}

function EnhancedTableHead(props: EnhancedTableProps) {
	const { order, orderBy, onRequestSort } = props;
	const createSortHandler =
		(property: keyof Data) => (event: React.MouseEvent<unknown>) => {
			onRequestSort(event, property);
		};

	return (
		<TableHead>
			<TableRow>
				<TableCell align="center" sx={{ minWidth: 210 }}></TableCell>
				{headCells.map((headCell) => (
					<TableCell
						key={headCell.id}
						sortDirection={orderBy === headCell.id ? order : false}
						sx={{ minWidth: 160 }}
					>
						<TableSortLabel
							active={orderBy === headCell.id}
							direction={orderBy === headCell.id ? order : "asc"}
							onClick={createSortHandler(headCell.id)}
						>
							{headCell.label}
							{orderBy === headCell.id ? (
								<Box component="span" sx={visuallyHidden}>
									{order === "desc" ? "sorted descending" : "sorted ascending"}
								</Box>
							) : null}
						</TableSortLabel>
					</TableCell>
				))}
				<TableCell align="center" sx={{ width: 142 }}>
					Actions
				</TableCell>
			</TableRow>
		</TableHead>
	);
}

const DesignerConcludeCare: React.FC = () => {
	const [order, setOrder] = React.useState<Order>("asc");
	const [orderBy, setOrderBy] = React.useState<keyof Data>("uploadDate");

	const handleRequestSort = (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => {
		const isAsc = orderBy === property && order === "asc";
		setOrder(isAsc ? "desc" : "asc");
		setOrderBy(property);
	};
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Conclude Care</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div className="confirm-number uploaded-data">
							<label>Patient Name</label>
							<Typography variant="h4">Rajesh Satvara</Typography>
						</div>
						<FormControl fullWidth variant="outlined">
							<OutlinedInput
								id="upload-file"
								type="text"
								className="upload-input"
								placeholder="Select File"
								endAdornment={
									<InputAdornment position="end">
										<Button
											variant="contained"
											component="label"
											disableElevation
											disableFocusRipple
											disableRipple
										>
											<img src={UploadcloudIcon} alt="" />
											<span>Upload</span>
											<input hidden accept="*" multiple type="file" />
										</Button>
									</InputAdornment>
								}
								label="Password"
							/>
						</FormControl>
						<div className="attachment">
							<Typography variant="h4">Documents</Typography>
						</div>
						<TableContainer className="upload-table-container conclude-table-container">
							<Table className="upload-table conclude-table">
								<EnhancedTableHead
									order={order}
									orderBy={orderBy}
									onRequestSort={handleRequestSort}
								/>
								<TableBody>
									{stableSort(rows, getComparator(order, orderBy)).map(
										(row, index) => {
											return (
												<TableRow hover tabIndex={-1} key={row.doc}>
													<TableCell
														component="th"
														scope="row"
														className="upload-file-col"
													>
														<div className="upload-file">
															{row.file}
															<span>{row.doc}</span>
														</div>
													</TableCell>
													<TableCell>
														{moment(row.uploadDate).format("MMM D, YYYY")}
													</TableCell>
													<TableCell align="center">
														<div className="upload-actions">
															<IconButton disableFocusRipple disableRipple>
																<img src={DownloadIcon} alt="download" />
															</IconButton>
															<IconButton disableFocusRipple disableRipple>
																<img src={DeleteIcon} alt="delete" />
															</IconButton>
														</div>
													</TableCell>
												</TableRow>
											);
										}
									)}
								</TableBody>
							</Table>
						</TableContainer>
						<div>
							<Typography variant="body1" className="input-title">
								Provider Notes
							</Typography>
							<TextField
								id="description"
								label="Description"
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="request-btn-group">
							<Button variant="contained" href="/designer-dashboard">
								Save
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerConcludeCare;
