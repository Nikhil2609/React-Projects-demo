import React from "react";
import {
	Box,
	Button,
	Checkbox,
	FormControl,
	IconButton,
	InputAdornment,
	OutlinedInput,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableSortLabel,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	CheckIcon,
	DeleteAllIcon,
	DeleteIcon,
	DownloadAllIcon,
	DownloadIcon,
	MailIconBlue,
	UncheckIcon,
	UploadcloudIcon,
} from "assests/images";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";
import myCustomTheme from "app.theme";
import moment from "moment";
import { visuallyHidden } from "@mui/utils";

interface Data {
	doc: string;
	file: any;
	uploadDate: string;
}

function createData(doc: string, uploadDate: string, file: any): Data {
	return {
		doc,
		file,
		uploadDate,
	};
}

const rows = [
	createData(
		"Zoll_Genehmigung.doc",
		"2018-02-10",
		<img
			src={require("../../../assests/images/ic-doc-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Passbild.jpg",
		"2019-08-14",
		<img
			src={require("../../../assests/images/ic-jpg-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Sozialversicherungsnachweis.jpeg",
		"2008-12-29",
		<img
			src={require("../../../assests/images/ic-jpg-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Mietvertrag_Hohenzollernstraße.pdf",
		"1998-06-22",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Führungszeugnis.pdf",
		"2005-10-02",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Krankenkassenbescheinigung.doc",
		"2008-12-29",
		<img
			src={require("../../../assests/images/ic-doc-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Teilnahme_Bescheinigung_Fortbildung_xy.docx",
		"2013-05-15",
		<img
			src={require("../../../assests/images/ic-doc-file.svg").default}
			alt="file"
		/>
	),
	createData(
		"Lohnsteuerbescheinigung.pdf",
		"2010-04-30",
		<img
			src={require("../../../assests/images/ic-pdf-file.svg").default}
			alt="file"
		/>
	),
];

interface HeadCell {
	id: keyof Data;
	label: string;
}

const headCells: readonly HeadCell[] = [
	{
		id: "uploadDate",
		label: "Upload Date",
	},
];

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
	if (b[orderBy] < a[orderBy]) {
		return -1;
	}
	if (b[orderBy] > a[orderBy]) {
		return 1;
	}
	return 0;
}

type Order = "asc" | "desc";

function getComparator<Key extends keyof any>(
	order: Order,
	orderBy: Key
): (a: { [key in Key]: string }, b: { [key in Key]: string }) => number {
	return order === "desc"
		? (a, b) => descendingComparator(a, b, orderBy)
		: (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort<T>(
	array: readonly T[],
	comparator: (a: T, b: T) => number
) {
	const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
	stabilizedThis.sort((a, b) => {
		const order = comparator(a[0], b[0]);
		if (order !== 0) {
			return order;
		}
		return a[1] - b[1];
	});
	return stabilizedThis.map((el) => el[0]);
}

interface EnhancedTableProps {
	numSelected: number;
	onRequestSort: (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => void;
	order: Order;
	orderBy: string;
	onSelectAllClick: (event: React.ChangeEvent<HTMLInputElement>) => void;
	rowCount: number;
}

function CheckboxIcon() {
	return <img src={UncheckIcon} alt="checkbox" />;
}
function CheckedboxIcon() {
	return <img src={CheckIcon} alt="checkbox" />;
}

function EnhancedTableHead(props: EnhancedTableProps) {
	const {
		onSelectAllClick,
		order,
		orderBy,
		numSelected,
		rowCount,
		onRequestSort,
	} = props;
	const createSortHandler =
		(property: keyof Data) => (event: React.MouseEvent<unknown>) => {
			onRequestSort(event, property);
		};

	return (
		<TableHead>
			<TableRow>
				<TableCell
					padding="checkbox"
					sx={{
						minWidth: 72,
						[myCustomTheme.breakpoints.down("sm")]: {
							minWidth: 62,
						},
					}}
					align="center"
				>
					<Checkbox
						icon={<CheckboxIcon />}
						checkedIcon={<CheckedboxIcon />}
						color="primary"
						checked={rowCount > 0 && numSelected === rowCount}
						onChange={onSelectAllClick}
						disableRipple
						disableFocusRipple
						inputProps={{
							"aria-label": "select all files",
						}}
					/>
				</TableCell>
				<TableCell align="center" sx={{ minWidth: 210 }}></TableCell>
				{headCells.map((headCell) => (
					<TableCell
						key={headCell.id}
						sortDirection={orderBy === headCell.id ? order : false}
						sx={{ minWidth: 160 }}
					>
						<TableSortLabel
							active={orderBy === headCell.id}
							direction={orderBy === headCell.id ? order : "asc"}
							onClick={createSortHandler(headCell.id)}
						>
							{headCell.label}
							{orderBy === headCell.id ? (
								<Box component="span" sx={visuallyHidden}>
									{order === "desc" ? "sorted descending" : "sorted ascending"}
								</Box>
							) : null}
						</TableSortLabel>
					</TableCell>
				))}
				<TableCell align="center" sx={{ width: 142 }}>
					Actions
				</TableCell>
			</TableRow>
		</TableHead>
	);
}

interface EnhancedTableToolbarProps {
	numSelected: number;
}

function EnhancedTableToolbar(props: EnhancedTableToolbarProps) {
	const { numSelected } = props;

	return (
		<Box>
			<Button
				variant="outlined"
				disableElevation
				disableRipple
				disableFocusRipple
				title="Download all"
				disabled={numSelected > 0 ? false : true}
				sx={{
					minWidth: "111px",
					[myCustomTheme.breakpoints.down("sm")]: {
						minWidth: "0",
					},
				}}
			>
				<span>Download all</span>
				<img src={DownloadAllIcon} alt="download" />
			</Button>
			<Button
				variant="outlined"
				disableElevation
				disableRipple
				disableFocusRipple
				title="Delete all"
				disabled={numSelected > 0 ? false : true}
				sx={{
					minWidth: "111px",
					[myCustomTheme.breakpoints.down("sm")]: {
						minWidth: "0",
					},
				}}
			>
				<span>Delete all</span>
				<img src={DeleteAllIcon} alt="delete" />
			</Button>
			<Button
				variant="outlined"
				disableElevation
				disableRipple
				disableFocusRipple
				title="Send Mail"
				disabled={numSelected > 0 ? false : true}
				sx={{
					minWidth: "111px",
					[myCustomTheme.breakpoints.down("sm")]: {
						minWidth: "0",
					},
				}}
			>
				<span>Send Mail</span>
				<img src={MailIconBlue} alt="mail" />
			</Button>
		</Box>
	);
}

const DesignerViewUploads: React.FC = () => {
	const [selected, setSelected] = React.useState<readonly string[]>([]);

	const handleSelectAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
		if (event.target.checked) {
			const newSelected = rows.map((n) => n.doc);
			setSelected(newSelected);
			return;
		}
		setSelected([]);
	};

	const handleClick = (event: React.MouseEvent<unknown>, doc: string) => {
		const selectedIndex = selected.indexOf(doc);
		let newSelected: readonly string[] = [];

		if (selectedIndex === -1) {
			newSelected = newSelected.concat(selected, doc);
		} else if (selectedIndex === 0) {
			newSelected = newSelected.concat(selected.slice(1));
		} else if (selectedIndex === selected.length - 1) {
			newSelected = newSelected.concat(selected.slice(0, -1));
		} else if (selectedIndex > 0) {
			newSelected = newSelected.concat(
				selected.slice(0, selectedIndex),
				selected.slice(selectedIndex + 1)
			);
		}
		setSelected(newSelected);
	};

	const [order, setOrder] = React.useState<Order>("asc");
	const [orderBy, setOrderBy] = React.useState<keyof Data>("uploadDate");

	const handleRequestSort = (
		event: React.MouseEvent<unknown>,
		property: keyof Data
	) => {
		const isAsc = orderBy === property && order === "asc";
		setOrder(isAsc ? "desc" : "asc");
		setOrderBy(property);
	};

	const isSelected = (doc: string) => selected.indexOf(doc) !== -1;
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Documents</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div className="confirm-number uploaded-data">
							<label>Patient Name</label>
							<Typography variant="h4">
								Rajesh Satvara <span>&nbsp;&#40;DC010423SARA0002&#41;</span>
							</Typography>
						</div>
						<Typography variant="body1" className="instruction">
							Check here to review and add files that you or the Client/Member
							has attached to the Request.
						</Typography>
						<FormControl fullWidth variant="outlined">
							<OutlinedInput
								id="upload-file"
								type="text"
								className="upload-input"
								placeholder="Select File"
								endAdornment={
									<InputAdornment position="end">
										<Button
											variant="contained"
											component="label"
											disableElevation
											disableFocusRipple
											disableRipple
										>
											<img src={UploadcloudIcon} alt="" />
											<span>Upload</span>
											<input hidden accept="*" multiple type="file" />
										</Button>
									</InputAdornment>
								}
								label="Password"
							/>
						</FormControl>
						<div className="attachment">
							<Typography variant="h4">Documents</Typography>
							<Box className="selected-action-btn">
								<EnhancedTableToolbar numSelected={selected.length} />
							</Box>
						</div>
						<TableContainer className="upload-table-container">
							<Table className="upload-table">
								<EnhancedTableHead
									numSelected={selected.length}
									onSelectAllClick={handleSelectAllClick}
									rowCount={rows.length}
									order={order}
									orderBy={orderBy}
									onRequestSort={handleRequestSort}
								/>
								<TableBody>
									{stableSort(rows, getComparator(order, orderBy)).map(
										(row, index) => {
											const isItemSelected = isSelected(row.doc);
											const labelId = `table-checkbox-${index}`;
											return (
												<TableRow
													hover
													role="checkbox"
													tabIndex={-1}
													key={row.doc}
													selected={isItemSelected}
												>
													<TableCell padding="checkbox" align="center">
														<Checkbox
															onClick={(event) => handleClick(event, row.doc)}
															icon={<CheckboxIcon />}
															checkedIcon={<CheckedboxIcon />}
															checked={isItemSelected}
															disableRipple
															disableFocusRipple
															inputProps={{
																"aria-labelledby": labelId,
															}}
														/>
													</TableCell>
													<TableCell
														component="th"
														id={labelId}
														scope="row"
														padding="none"
														className="upload-file-col"
													>
														<div className="upload-file">
															{row.file}
															<span>{row.doc}</span>
														</div>
													</TableCell>
													<TableCell>
														{moment(row.uploadDate).format("MMM D, YYYY")}
													</TableCell>
													<TableCell align="center">
														<div className="upload-actions">
															<IconButton disableFocusRipple disableRipple>
																<img src={DownloadIcon} alt="download" />
															</IconButton>
															<IconButton disableFocusRipple disableRipple>
																<img src={DeleteIcon} alt="delete" />
															</IconButton>
															<IconButton disableFocusRipple disableRipple>
																<img src={MailIconBlue} alt="mail" />
															</IconButton>
														</div>
													</TableCell>
												</TableRow>
											);
										}
									)}
								</TableBody>
							</Table>
						</TableContainer>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerViewUploads;
