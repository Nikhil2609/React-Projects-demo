import React from "react";
import {
	Box,
	Button,
	Grid,
	InputLabel,
	OutlinedInput,
	TextField,
	Typography,
} from "@mui/material";
import { ArrowBack, CalendarDarkIcon, LocationIcon } from "assests/images";
import { Dayjs } from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import DesignerHeader from "components/Designer/DesignerHeader";
import DesignerFooter from "components/Designer/DesignerFooter";
import { DesktopDatePicker } from "@mui/x-date-pickers";

function datepickerIcon() {
	return (
		<>
			<img src={CalendarDarkIcon} alt="calendar" />
		</>
	);
}

function addClass() {
	const formGp = document.getElementById("formGroup");
	if (formGp) {
		formGp.classList.add("focused");
	}
}

function removeClass() {
	const formGp = document.getElementById("formGroup");
	if (formGp) {
		formGp.classList.remove("focused");
	}
}

const DesignerCreateRequest: React.FC = () => {
	const [value, setValue] = React.useState<Dayjs | null>(null);
	return (
		<Box>
			<DesignerHeader />
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Submit Information</Typography>
						<Button variant="outlined" href="/designer-dashboard">
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div>
							<Typography variant="h4">Patient</Typography>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										error
										id="first-name"
										label="First Name"
										variant="outlined"
										helperText="Incorrect entry."
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="ph-num"
										label="Phone Number"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="email"
										label="Email"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									{/* ----------------------Double Input----------------- */}
									<Box className="form-group" id="formGroup">
										<InputLabel htmlFor="bp">BP</InputLabel>
										<Box className="input-group">
											<OutlinedInput
												id="bp"
												fullWidth
												onFocus={addClass}
												onBlur={removeClass}
											/>
											<span>&#47;</span>
											<OutlinedInput
												id="bp-2"
												fullWidth
												onFocus={addClass}
												onBlur={removeClass}
											/>
										</Box>
										<div className="fieldset"></div>
									</Box>
									{/* ----------------------Double Input----------------- */}
								</Grid>
								<Grid item xs={12} sm={6}>
									<LocalizationProvider dateAdapter={AdapterDayjs}>
										<DesktopDatePicker
											label={
												<React.Fragment>
													Date of Birth&nbsp;<span>&#40;Optional&#41;</span>
												</React.Fragment>
											}
											value={value}
											inputFormat="DD/MM/YYYY"
											onChange={(newValue) => {
												setValue(newValue);
											}}
											components={{
												OpenPickerIcon: datepickerIcon,
											}}
											renderInput={(params) => (
												<TextField
													{...params}
													fullWidth
													id="dob"
													className="datepicker"
													autoComplete="off"
													inputProps={{
														...params.inputProps,
													}}
												/>
											)}
										/>
									</LocalizationProvider>
								</Grid>
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Location</Typography>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="street"
										label="Street"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="city"
										label="City"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="state"
										label="State"
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="zipcode"
										label={
											<React.Fragment>
												Zip Code&nbsp;<span>&#40;Optional&#41;</span>
											</React.Fragment>
										}
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="first-name"
										label={
											<React.Fragment>
												Room #&nbsp;<span>&#40;Optional&#41;</span>
											</React.Fragment>
										}
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<div className="verify-btn-group">
										<Button variant="outlined">Verify</Button>
										<Button variant="outlined">
											<img src={LocationIcon} alt="location" />
											Map
										</Button>
									</div>
								</Grid>
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Notes</Typography>
							<TextField
								id="physican-notes"
								label={
									<React.Fragment>
										Physician Notes&nbsp;<span>&#40;Optional&#41;</span>
									</React.Fragment>
								}
								multiline
								className="textarea"
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
								disabled
							/>
							<TextField
								id="physican-notes"
								label={
									<React.Fragment>
										Admin Notes&nbsp;<span>&#40;Optional&#41;</span>
									</React.Fragment>
								}
								className="textarea"
								multiline
								maxRows={1}
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="request-btn-group">
							<Button variant="contained" href="/designer-dashboard">
								Save
							</Button>
							<Button variant="outlined" href="/designer-dashboard">
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<DesignerFooter />
		</Box>
	);
};

export default DesignerCreateRequest;
