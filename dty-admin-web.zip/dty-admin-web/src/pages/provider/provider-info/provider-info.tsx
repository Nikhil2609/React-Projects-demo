import React, { useEffect, useState } from "react";
import {
	Box,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Typography,
	TableSortLabel,
	Tooltip,
	Button,
	MenuItem,
	Select,
	FormControl,
} from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";
import { visuallyHidden } from "@mui/utils";
import {
	IProviderInfo,
	IProviderInfoSearchCriteria,
	IDropDownList,
} from "utility/interfaces";
import { TablePagination, ProviderInfoTableRow } from "components";
import { Constants } from "utility/enums/constants";
import { SortOrder } from "utility/enums/sort-order";

const ProviderInfo: React.FC = () => {
	// get query parameters
	const { caseId } = useParams();

	// useStates
	const [searchCriteria, setSearchCriteria] =
		useState<IProviderInfoSearchCriteria>({
			PageIndexId: 0,
			PageSize: Constants.DefaultTablePageSize.valueOf(),
			SortOrder: SortOrder.ascending,
			SortBy: "providerName",
			SearchBy: "",
			RegionId: 0,
		});
	// TODO: Dynamic
	const [providerInfo, setProviderInfo] = useState<IProviderInfo>({
		totalRecords: 100,
		providers: [
			{
				queryString: "abc1",
				isNotificationStoped: true,
				onCallStatus: "Available",
				providerId: "7",
				providerName: "Provider 1",
				role: "Provider Role",
			},
			{
				queryString: "abc1",
				isNotificationStoped: true,
				onCallStatus: "Available",
				providerId: "6",
				providerName: "Provider 2",
				role: "Provider Role",
			},
			{
				queryString: "abc2",
				isNotificationStoped: true,
				onCallStatus: "Available-1",
				providerId: "5",
				providerName: "Provider 1",
				role: "Provider Roleq",
			},
			{
				queryString: "abc23",
				isNotificationStoped: true,
				onCallStatus: "Availablee",
				providerId: "4",
				providerName: "Provider 1",
				role: "Provider Rolwe",
			},
			{
				queryString: "abc344",
				isNotificationStoped: true,
				onCallStatus: "Availables",
				providerId: "3",
				providerName: "Provider 1",
				role: "Provider Rodle",
			},
			{
				queryString: "abc41",
				isNotificationStoped: true,
				onCallStatus: "AvailableZ",
				providerId: "2",
				providerName: "Provider 1",
				role: "Provider Rolte",
			},
		],
	});
	const [regions, setRegions] = useState<IDropDownList[]>([
		{
			text: "All",
			value: 0,
		},
		{
			text: "Regions 1",
			value: 1,
		},
		{
			text: "Regions 2",
			value: 2,
		},
		{
			text: "Regions 3",
			value: 3,
		},
	]);

	// Handled event(s)
	const handleOnPageNumberChange = (value: number) => {
		setSearchCriteria({ ...searchCriteria, PageIndexId: value });
	};
	const getNoteDetails = () => {
		// TODO API call here
		console.log(caseId);
	};
	const handleOnSelectRow = (providerId: string) => {
		const providers = providerInfo.providers.map((info) => {
			if (info.providerId === providerId)
				info.isNotificationStoped = !info.isNotificationStoped;
			return info;
		});

		setProviderInfo({ ...providerInfo, providers });
	};
	const handleOnChangeSortDirection = (sortBy: string) => {
		setSearchCriteria({
			...searchCriteria,
			SortBy: sortBy,
			SortOrder:
				searchCriteria.SortOrder === SortOrder.ascending
					? SortOrder.descending
					: SortOrder.ascending,
		});
	};

	// useEffects
	useEffect(() => {
		if (caseId) getNoteDetails();
	}, []);

	return (
		<>
			<Box>
				<main className="main-content">
					<div
						className="overlay"
						onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
					></div>
					<Box className="request-container-box">
						<div className="request-header">
							<Typography variant="h2">Provider Information</Typography>
						</div>
						<Box className="request-box">
							<div className="table-header region-table-header">
								<FormControl className="region-search">
									<Select
										labelId="region-label"
										id="region"
										value={searchCriteria.RegionId}
										name="region"
										label="Search by Region"
										onChange={(event) => {
											setSearchCriteria({
												...searchCriteria,
												RegionId: +event.target.value,
											});
										}}
									>
										{regions.map((region) => {
											return (
												<MenuItem key={region.value} value={region.value}>
													{region.text}
												</MenuItem>
											);
										})}
									</Select>
								</FormControl>
								<div className="tab-button-groups">
									<Tooltip title="Request DTY Support">
										<Button
											variant="contained"
											style={{ paddingTop: "9px", paddingBottom: "9px" }}
										>
											Save
										</Button>
									</Tooltip>
								</div>
							</div>
							<TableContainer className="upload-table-container">
								<Table className="upload-table checkbox-table">
									<TableHead>
										<TableRow>
											<TableCell sx={{ minWidth: 160 }} align="center">
												Stop Notification
											</TableCell>
											<TableCell
												sortDirection={searchCriteria.SortOrder}
												sx={{ minWidth: 200 }}
											>
												<TableSortLabel
													active={searchCriteria.SortBy === "providerName"}
													direction={searchCriteria.SortOrder}
													onClick={() =>
														handleOnChangeSortDirection("providerName")
													}
												>
													Provider Name
													<Box component="span" sx={visuallyHidden}>
														{searchCriteria.SortOrder === SortOrder.descending
															? "sorted descending"
															: "sorted ascending"}
													</Box>
												</TableSortLabel>
											</TableCell>
											<TableCell
												sortDirection={searchCriteria.SortOrder}
												sx={{ minWidth: 160 }}
											>
												<TableSortLabel
													active={searchCriteria.SortBy === "role"}
													direction={searchCriteria.SortOrder}
													onClick={() => handleOnChangeSortDirection("role")}
												>
													Role
													<Box component="span" sx={visuallyHidden}>
														{searchCriteria.SortOrder === SortOrder.descending
															? "sorted descending"
															: "sorted ascending"}
													</Box>
												</TableSortLabel>
											</TableCell>
											<TableCell
												sortDirection={searchCriteria.SortOrder}
												sx={{ minWidth: 200 }}
											>
												<TableSortLabel
													active={searchCriteria.SortBy === "onCallStatus"}
													direction={searchCriteria.SortOrder}
													onClick={() =>
														handleOnChangeSortDirection("onCallStatus")
													}
												>
													On Call Status
													<Box component="span" sx={visuallyHidden}>
														{searchCriteria.SortOrder === SortOrder.descending
															? "sorted descending"
															: "sorted ascending"}
													</Box>
												</TableSortLabel>
											</TableCell>
											<TableCell align="center" sx={{ width: 142 }}>
												Actions
											</TableCell>
										</TableRow>
									</TableHead>
									<TableBody>
										{providerInfo.providers.map((row, index) => {
											return (
												<TableRow hover tabIndex={-1} key={index}>
													<ProviderInfoTableRow
														index={index}
														handleOnSelectRow={handleOnSelectRow}
														row={row}
													/>
												</TableRow>
											);
										})}
									</TableBody>
								</Table>
							</TableContainer>
							<div className="small-table-pagination">
								<TablePagination
									currentPageNumber={searchCriteria.PageIndexId}
									handleOnPageNumberChange={handleOnPageNumberChange}
									totalRecords={providerInfo?.totalRecords || 0}
									rowCount={providerInfo?.providers?.length || 0}
								/>
							</div>
						</Box>
					</Box>
				</main>
			</Box>
		</>
	);
};

export default ProviderInfo;
