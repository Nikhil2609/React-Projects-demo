import React, { useContext, useEffect, useState } from "react";
import {
	Box,
	Button,
	Grid,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import {
	AdministratorIcon,
	ArrowBack,
	DoctorDarkIcon,
	PatientDarkIcon,
	TransferIcon,
} from "assests/images";
import { useNavigate, useParams } from "react-router-dom";
import { AppRoutings } from "utility/enums/app-routings";
import { getTabStatusWiseName, createCommonAPICall } from "utility/helpers";
import dashboardService from "services/dashboard-service";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { IViewNoteInfo } from "utility/interfaces";

const ViewNotes: React.FC = () => {
	// get query parameters
	const { caseId } = useParams();

	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);
	const navigate = useNavigate();

	// get state value
	const { state } = window.history;

	// useStates
	const [adminNotes, setAdminNotes] = useState("");
	const [viewNotePageInfo, setViewNotePageInfo] =
		React.useState<IViewNoteInfo | null>({
			queryString: "",
			requestId: 0,
			patientNotes: "",
			physicianNotes: "",
			adminNotes: "",
			transferNotes: "",
			notes: "",
			adminSelectedCancellationNotes: "",
			physicianSelectedCancellationNotes: "",
			patientSelectedCancellationNotes: "",
		});
	// Handled events and functions
	const handleOnClickBackCancel = () =>
		navigate(
			state?.usr?.backURL ||
				AppRoutings.Dashboard.replace(
					":tabStatus",
					getTabStatusWiseName(
						state?.usr?.searchCriteria?.RequestStatusId
					).toLocaleLowerCase()
				),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);
	const handleOnChangeAdminNote = (e: any) => {
		setAdminNotes(e.target.value);
	};
	const handleOnClickSaveChanges = (e: any) => {
		console.log(adminNotes);
	};
	const getNoteDetails = async () => {
		const data = await createCommonAPICall({
			requestBody: { requestId: caseId },
			apiService: dashboardService.getViewNoteInfo,
			showSuccessMessage: false,
			showErrorMessage: true,
			setSuccessErrorContext,
		});
		if (data && data.data) setViewNotePageInfo(data.data);
	};

	// useEffects
	useEffect(() => {
		if (caseId) getNoteDetails();
	}, []);

	return (
		<Box>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Notes</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Grid container spacing={3}>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={PatientDarkIcon} alt="patient" />
								<div>
									<Typography variant="h6">Patient Notes</Typography>
									<Typography variant="body1">
										{viewNotePageInfo?.patientNotes || "-"}
									</Typography>
								</div>
							</Box>
						</Grid>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={TransferIcon} alt="transfer" />
								<div>
									<Typography variant="h6">Transfer Notes</Typography>
									<Typography variant="body1">
										{viewNotePageInfo?.transferNotes || "-"}
									</Typography>
								</div>
							</Box>
						</Grid>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={DoctorDarkIcon} alt="Doctor" />
								<div>
									<Typography variant="h6">Physician Notes</Typography>
									<Typography variant="body1">
										{viewNotePageInfo?.physicianNotes || "-"}
									</Typography>
								</div>
							</Box>
						</Grid>
						<Grid item xs={12} md={6}>
							<Box className="notes-box">
								<img src={AdministratorIcon} alt="Administrator" />
								<div>
									<Typography variant="h6">Admin Notes</Typography>
									<Typography variant="body1">
										{viewNotePageInfo?.adminNotes || "-"}
									</Typography>
								</div>
							</Box>
						</Grid>
					</Grid>
					<Box sx={{ mt: 3 }} className="request-box">
						<Grid container spacing={3} sx={{ mt: 0.5 }}>
							<Grid item xs={12} md={12}>
								<TextField
									autoFocus
									inputProps={{
										style: { minHeight: "80px" },
									}}
									id="admin-notes"
									label={<React.Fragment>Admin Notes</React.Fragment>}
									multiline
									value={adminNotes}
									rows={2}
									fullWidth
									name="physicianNote"
									onChange={handleOnChangeAdminNote}
								/>
							</Grid>
						</Grid>
						<div className="request-btn-group">
							<Tooltip title="Save Changes">
								<Button
									onClick={() =>
										adminNotes?.trim() ? handleOnClickSaveChanges : undefined
									}
									variant="contained"
								>
									Save Changes
								</Button>
							</Tooltip>
						</div>
					</Box>
				</Box>
			</main>
		</Box>
	);
};

export default ViewNotes;
