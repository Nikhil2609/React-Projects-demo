import React, { useState } from "react";
import {
	Box,
	Button,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	TextField,
	Typography,
	Autocomplete,
	Tooltip,
} from "@mui/material";
import { ArrowBack } from "assests/images";
import { useNavigate, useParams } from "react-router-dom";
import { IDropDownList } from "utility/interfaces";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { sendOrderSchema } from "utility/validations";
import { AppRoutings } from "utility/enums/app-routings";
import { getTabStatusWiseName } from "utility/helpers";

const Orders: React.FC = () => {
	// Page level interface
	interface ISendOrder {
		business: string;
		refill: string;
		businessContact: string;
		email: string;
		faxNumber: string;
		prescription: string;
	}

	// get query parameters
	const { caseId } = useParams();

	// get state value
	const { state } = window.history;

	// useStates
	const [formValues, setFormValues] = useState<ISendOrder>({
		business: "",
		refill: "",
		businessContact: "",
		email: "",
		faxNumber: "",
		prescription: "",
	});

	const [businessList, setBusinessList] = useState<IDropDownList[]>([
		{
			text: "Business 1",
			value: 1,
		},
		{
			text: "Business 2",
			value: 2,
		},
		{
			text: "Business 3",
			value: 3,
		},
	]);
	const [refillList, setRefillList] = useState<IDropDownList[]>([
		{
			text: "Refill 1",
			value: 1,
		},
		{
			text: "Refill 2",
			value: 2,
		},
		{
			text: "Refill 3",
			value: 3,
		},
	]);

	// Handled events and functions
	const handleOnFormValueChange = (e: any) => {
		setFormValues({ ...formValues, [e.target.name]: e.target.value });
	};
	const handleOnBusinessValueChange = (value: string | null) => {
		setFormValues({ ...formValues, business: value ? value : "" });
	};

	const handleOnClickBackCancel = () =>
		navigate(
			AppRoutings.Dashboard.replace(
				":tabStatus",
				getTabStatusWiseName(
					state?.usr?.searchCriteria?.RequestStatusId
				).toLocaleLowerCase()
			),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);
	const handleOnClickSubmit = () => {
		console.log("On click submit : Send order", formValues);
	};

	// Page level variables
	const navigate = useNavigate();

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(sendOrderSchema),
	});

	return (
		<main className="main-content">
			<div
				className="overlay"
				onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
			></div>
			<Box className="request-container-box">
				<div className="request-header">
					<Typography variant="h2">Send Order</Typography>
					<Button variant="outlined" onClick={handleOnClickBackCancel}>
						<img src={ArrowBack} alt="arrow" />
						Back
					</Button>
				</div>
				<Box className="request-box">
					<div className="orders-input-container">
						<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
							<Grid item xs={12} sm={6}>
								<Autocomplete
									className="c-autotextbox"
									freeSolo
									options={businessList.map((option) => option.text)}
									onChange={(event: any, newValue: string | null) => {
										handleOnBusinessValueChange(newValue);
									}}
									value={formValues.business}
									renderInput={(params) => (
										<TextField
											{...register("business")}
											{...params}
											label="Business"
											variant="outlined"
											onChange={(e) => {
												setFormValues({
													...formValues,
													business: e.target.value ? e.target.value : "",
												});
											}}
											value={formValues.business}
											error={errors?.business?.message ? true : false}
											helperText={errors?.business?.message?.toString()}
										/>
									)}
								/>
							</Grid>
							<Grid item xs={12} sm={6}>
								<TextField
									fullWidth
									id="businessContact"
									label="Business contact"
									variant="outlined"
									value={formValues?.businessContact}
									name="businessContact"
									onChange={handleOnFormValueChange}
								/>
							</Grid>
							<Grid item xs={12} sm={6}>
								<TextField
									fullWidth
									id="email"
									{...register("email")}
									label="Email"
									variant="outlined"
									name="email"
									value={formValues?.email}
									onChange={handleOnFormValueChange}
									helperText={errors?.email?.message?.toString()}
									error={errors?.email?.message ? true : false}
								/>
							</Grid>
							<Grid item xs={12} sm={6}>
								<TextField
									fullWidth
									id="fax-num"
									label="Fax Number"
									variant="outlined"
									name="faxNumber"
									value={formValues?.faxNumber}
									onChange={handleOnFormValueChange}
								/>
							</Grid>
							<Grid item xs={12}>
								<TextField
									{...register("prescription")}
									id="physican-notes"
									label="Prescription or Order details"
									multiline
									className="textarea"
									maxRows={1}
									inputProps={{
										style: {
											minHeight: "80px",
											overflow: "auto",
										},
									}}
									name="prescription"
									onChange={handleOnFormValueChange}
									fullWidth
									value={formValues?.prescription}
									error={errors?.prescription?.message ? true : false}
									helperText={errors?.prescription?.message?.toString()}
								/>
							</Grid>
							<Grid item xs={12} sm={6}>
								<FormControl fullWidth className="select-input">
									<InputLabel id="refill-label">Number Of Refill</InputLabel>
									<Select
										labelId="refill-label"
										id="refill-name"
										value={formValues?.refill}
										label="Number Of Refill"
										name="refill"
										onChange={handleOnFormValueChange}
										MenuProps={{
											className: "select-input-modal",
										}}
									>
										{refillList?.map((refill) => {
											return (
												<MenuItem key={refill.value} value={refill.value}>
													{refill.text}
												</MenuItem>
											);
										})}
									</Select>
								</FormControl>
							</Grid>
						</Grid>
					</div>
					<div className="request-btn-group orders-btn-group">
						<Button
							variant="contained"
							onClick={handleSubmit(handleOnClickSubmit)}
						>
							<Tooltip title="Submit">
								<>Submit</>
							</Tooltip>
						</Button>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<Tooltip title="Cancel">
								<>Cancel</>
							</Tooltip>
						</Button>
					</div>
				</Box>
			</Box>
		</main>
	);
};

export default Orders;
