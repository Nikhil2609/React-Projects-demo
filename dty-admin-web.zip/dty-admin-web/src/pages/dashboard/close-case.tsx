import React, { useEffect, useState } from "react";
import {
	Box,
	Button,
	IconButton,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TextField,
	Typography,
	Collapse,
	Grid,
	FormControl,
	InputLabel,
	OutlinedInput,
	InputAdornment,
	FormHelperText,
	TableSortLabel,
	Tooltip,
} from "@mui/material";
import {
	ArrowBack,
	DownloadIcon,
	CallIconPrimary,
	SmartphoneIcon,
} from "assests/images";
import { useNavigate, useParams } from "react-router-dom";
import { IDocumentInfo } from "utility/interfaces";
import { getComparator, getFileIconByType, stableSort } from "utility/helpers";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { closeCaseSchema } from "utility/validations";
import { visuallyHidden } from "@mui/utils";
import moment from "moment";
import { CustomDatePicker } from "components";

const CloseCase: React.FC = () => {
	// get state value
	const { state } = window.history;

	// Page level interfaces
	interface ICloseCase {
		firstName: string;
		lastName: string;
		dateOfBirth: string;
		phoneNumber: string;
		email: string;
		updatedPhoneNumber: string;
		updatedEmail: string;
		patientId: string;
	}
	// get query parameters
	const { caseId } = useParams();

	// useStates
	type Order = "asc" | "desc";
	const [orderDirection, setOrderDirection] = useState<Order>("asc");
	const [isEdit, setIsEdit] = useState(false);
	const [formValues, setFormValues] = useState<ICloseCase>({
		firstName: "Rajesh",
		lastName: "Satvara",
		email: "rajeshsatvara@gmail.com",
		dateOfBirth: "",
		phoneNumber: "8128791896",
		updatedPhoneNumber: "",
		updatedEmail: "",
		patientId: "#123456DH78",
	});
	// TODO: Dynamic
	const [documentList, setDocumentList] = useState<IDocumentInfo[]>([
		{
			id: 1,
			name: "document 1",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
		{
			id: 2,
			name: "document 2",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
		{
			id: 3,
			name: "document 3",
			type: "pdf",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2008-10-02",
		},
		{
			id: 4,
			name: "document 4",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2009-10-02",
		},
	]);

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
		clearErrors,
		reset,
	} = useForm({
		resolver: yupResolver(closeCaseSchema),
	});

	// Handled events and functions
	const handleOnClickBackCancel = () =>
		navigate(state?.usr?.backURL, {
			state: {
				searchCriteria: state?.usr?.searchCriteria,
			},
		});

	// const handleOnClickEnterCost = () => {
	// 	navigate(
	// 		AppRoutings.ItemizedCosts.replace(":caseId", caseId ? caseId : ""),
	// 		{
	// 			state: {
	// 				searchCriteria: state?.usr?.searchCriteria,
	// 			},
	// 		}
	// 	);
	// };
	const onFormValueChange = (e: any) => {
		setFormValues({ ...formValues, [e.target.name]: e.target.value });
	};
	const handleOnClickCloseCase = () => {
		console.log("On close button click handle here.");
	};
	const handleOnClickSave = () => {
		console.log("On save button click handle here.");
	};
	const handleOnClickCancle = () => {
		clearErrors();
		reset();
		setFormValues({
			...formValues,
			updatedEmail: formValues.email,
			updatedPhoneNumber: formValues.phoneNumber,
		});
		setIsEdit(!isEdit);
	};

	// Handled event(s)
	const handleOnChangeSortDirection = () => {
		const isAsc = orderDirection === "asc";
		setOrderDirection(isAsc ? "desc" : "asc");
	};
	const getNoteDetails = () => {
		// TODO API call here
		console.log(caseId);
	};

	// Page level variables
	const navigate = useNavigate();

	// useEffects
	useEffect(() => {
		if (caseId) getNoteDetails();
	}, []);

	useEffect(() => {
		clearErrors();
		reset();
	}, [isEdit]);

	return (
		<>
			<Box>
				<main className="main-content">
					<div
						className="overlay"
						onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
					></div>
					<Box className="request-container-box">
						<div className="request-header">
							<Typography variant="h2">Close Case</Typography>
							<Button variant="outlined" onClick={handleOnClickBackCancel}>
								<img src={ArrowBack} alt="arrow" />
								Back
							</Button>
						</div>
						<Box className="request-box">
							<div className="request-box-header">
								<div className="confirm-number uploaded-data">
									<label>Patient Name</label>
									<Typography variant="h4">
										{formValues.firstName} {formValues.lastName}
										<span>&nbsp;&#40;{formValues.patientId}&#41;</span>
									</Typography>
								</div>
								{/* <div className="close-case-btn-group">
									<Button
										variant="outlined"
										disableElevation
										disableFocusRipple
										disableRipple
										className="btn-costs"
										onClick={handleOnClickEnterCost}
									>
										Enter Costs
									</Button>
								</div> */}
							</div>
							<div className="attachment">
								<Typography variant="h4">Documents</Typography>
							</div>
							<TableContainer className="upload-table-container conclude-table-container">
								<Table className="upload-table conclude-table">
									<TableHead>
										<TableRow>
											<TableCell sx={{ minWidth: 210 }}></TableCell>
											<TableCell
												sortDirection={orderDirection}
												sx={{ minWidth: 160 }}
											>
												<TableSortLabel
													active={true}
													direction={orderDirection}
													onClick={handleOnChangeSortDirection}
												>
													Upload Date
													<Box component="span" sx={visuallyHidden}>
														{orderDirection === "desc"
															? "sorted descending"
															: "sorted ascending"}
													</Box>
												</TableSortLabel>
											</TableCell>
											<TableCell align="center" sx={{ width: 142 }}>
												Actions
											</TableCell>
										</TableRow>
									</TableHead>
									<TableBody>
										{stableSort(
											documentList,
											getComparator(orderDirection, "uploadDate")
										).map((row, index) => {
											return (
												<TableRow hover tabIndex={-1} key={row.id}>
													<TableCell
														component="th"
														scope="row"
														className="upload-file-col"
													>
														<div className="upload-file">
															<img
																src={getFileIconByType(row.type)}
																alt="file"
															/>
															<span>{row.name}</span>
														</div>
													</TableCell>
													<TableCell>
														{moment(row.uploadDate).format("MMM D, YYYY")}
													</TableCell>
													<TableCell align="center">
														<Tooltip title="Download">
															<div className="upload-actions">
																<IconButton disableFocusRipple disableRipple>
																	<img src={DownloadIcon} alt="download" />
																</IconButton>
															</div>
														</Tooltip>
													</TableCell>
												</TableRow>
											);
										})}
									</TableBody>
								</Table>
							</TableContainer>
							<div>
								<Typography variant="h4">Patient Information</Typography>
								<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="first-name"
											label="First Name"
											variant="outlined"
											value={formValues.firstName}
											disabled
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="last-name"
											label="Last Name"
											variant="outlined"
											value={formValues.lastName}
											disabled
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<CustomDatePicker
											label="Date of Birth"
											onChange={undefined}
											name=""
											value={formValues.dateOfBirth}
											disabled={true}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<div className="input-with-button">
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="phone-num">
													Phone Number
												</InputLabel>
												<OutlinedInput
													{...register("updatedPhoneNumber")}
													id="phone-num"
													type="tel"
													name="updatedPhoneNumber"
													onChange={onFormValueChange}
													value={
														isEdit
															? formValues.updatedPhoneNumber
															: formValues.phoneNumber
													}
													disabled={!isEdit}
													fullWidth
													error={
														errors?.updatedPhoneNumber?.message ? true : false
													}
													className="with-icon"
													endAdornment={
														<InputAdornment position="end">
															<IconButton
																edge="end"
																disableFocusRipple
																disableRipple
															>
																<img src={SmartphoneIcon} alt="phone" />
															</IconButton>
														</InputAdornment>
													}
													label="phone-num"
												/>
												<FormHelperText error id="component-error-text">
													<>{errors?.updatedPhoneNumber?.message}</>
												</FormHelperText>
											</FormControl>
											<Tooltip title="Call">
												<IconButton href={`tel: ${formValues.phoneNumber}`}>
													<img src={CallIconPrimary} alt="call" />
												</IconButton>
											</Tooltip>
										</div>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											{...register("updatedEmail")}
											fullWidth
											id="email"
											label="Email"
											variant="outlined"
											name="updatedEmail"
											onChange={onFormValueChange}
											value={
												isEdit ? formValues.updatedEmail : formValues.email
											}
											disabled={!isEdit}
											error={errors?.updatedEmail?.message ? true : false}
											helperText={errors?.updatedEmail?.message?.toString()}
										/>
									</Grid>
								</Grid>
							</div>
							{/* <div>
								<Typography variant="h4">Requester</Typography>
								<div>
									<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
										<Grid item xs={12} sm={6}>
											<TextField
												fullWidth
												id="full-name"
												label="Full Name"
												variant="outlined"
												value="Rajesh Shah"
												disabled
											/>
										</Grid>
										<Grid item xs={12} sm={6}>
											<FormControl variant="outlined" fullWidth>
												<InputLabel htmlFor="phone-num2">
													Phone Number
												</InputLabel>
												<OutlinedInput
													id="phone-num2"
													type="tel"
													value="(147) 147 - 1470"
													disabled
													fullWidth
													className="with-icon"
													endAdornment={
														<InputAdornment position="end">
															<IconButton
																edge="end"
																disableFocusRipple
																disableRipple
															>
																<img src={SmartphoneIcon} alt="phone" />
															</IconButton>
														</InputAdornment>
													}
													label="phone-num"
												/>
											</FormControl>
										</Grid>
									</Grid>
								</div>
							</div> */}
							{isEdit ? (
								<div className="request-btn-group">
									<Tooltip title="Save">
										<Button
											variant="contained"
											onClick={handleSubmit(handleOnClickSave)}
										>
											Save
										</Button>
									</Tooltip>
									<Tooltip title="Cancel">
										<Button variant="outlined" onClick={() => setIsEdit(false)}>
											Cancel
										</Button>
									</Tooltip>
								</div>
							) : (
								<div className="request-btn-group">
									<Tooltip title="Edit">
										<Button variant="contained" onClick={handleOnClickCancle}>
											Edit
										</Button>
									</Tooltip>
									<Tooltip title="Close Case">
										<Button variant="outlined" onClick={handleOnClickCloseCase}>
											Close Case
										</Button>
									</Tooltip>
								</div>
							)}
						</Box>
					</Box>
				</main>
			</Box>
		</>
	);
};

export default CloseCase;
