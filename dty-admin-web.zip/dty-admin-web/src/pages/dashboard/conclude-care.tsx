import React, { useEffect } from "react";
import {
	Box,
	Button,
	IconButton,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TextField,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	DeleteIcon,
	DownloadIcon,
	UploadcloudBlueIcon,
} from "assests/images";
import { useNavigate, useParams } from "react-router-dom";
import { IDocumentInfo } from "utility/interfaces";
import { getFileIconByType, getTabStatusWiseName } from "utility/helpers";
import { AppRoutings } from "utility/enums/app-routings";

const ConcludeCare: React.FC = () => {
	// get query parameters
	const { caseId } = useParams();

	// useStates
	const [providerNotes, setProviderNotes] = React.useState<string>("");
	// TODO: Dynamic
	const [documentList, setDocumentList] = React.useState<IDocumentInfo[]>([
		{
			id: 1,
			name: "document 1",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
		{
			id: 2,
			name: "document 2",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
		{
			id: 3,
			name: "document 3",
			type: "pdf",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
		{
			id: 4,
			name: "document 4",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
	]);

	// get state value
	const { state } = window.history;

	// Handled events and functions
	const handleOnClickBackCancel = () =>
		navigate(
			AppRoutings.Dashboard.replace(
				":tabStatus",
				getTabStatusWiseName(
					state?.usr?.searchCriteria?.RequestStatusId
				).toLocaleLowerCase()
			),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);

	const handleOnClickSave = () => {
		console.log("On save button click handle here.", providerNotes);
	};

	// Handled event(s)
	const onSelectNewFiles = (event: any) => {
		const fileNames: string[] = [];
		if (event.target.files && event.target.files.length > 0) {
			Array.prototype.forEach.call(event.target.files, (file: any) => {
				fileNames.push(file.name);
			});
			console.log("Upload login here");
		}
	};

	const getNoteDetails = () => {
		// TODO API call here
		console.log(caseId);
	};

	// Page level variables
	const navigate = useNavigate();

	// useEffects
	useEffect(() => {
		if (caseId) getNoteDetails();
	}, []);

	return (
		<>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Conclude Care</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div className="confirm-number uploaded-data">
							<label>Patient Name</label>
							<Typography variant="h4">Rajesh Satvara</Typography>
						</div>
						<div className="attachment">
							<Typography variant="h4">Encounter Forms</Typography>
							<Button
								variant="outlined"
								component="label"
								disableElevation
								disableRipple
								disableFocusRipple
								sx={{ minWidth: "114px" }}
							>
								<img src={UploadcloudBlueIcon} alt="upload" />
								<span>Upload</span>
								<input
									onChange={onSelectNewFiles}
									hidden
									accept="*"
									multiple
									type="file"
								/>
							</Button>
						</div>
						<TableContainer className="upload-table-container conclude-table-container">
							<Table className="upload-table conclude-table">
								<TableHead>
									<TableRow>
										<TableCell sx={{ minWidth: 210 }}>Documents</TableCell>
										<TableCell align="center" sx={{ width: 142 }}>
											Actions
										</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{documentList.map((row, index) => {
										return (
											<TableRow hover tabIndex={-1} key={row.id}>
												<TableCell
													component="th"
													scope="row"
													className="upload-file-col"
												>
													<div className="upload-file">
														<img src={getFileIconByType(row.type)} alt="file" />
														<span>{row.name}</span>
													</div>
												</TableCell>
												<TableCell align="center">
													<div className="upload-actions">
														<IconButton disableFocusRipple disableRipple>
															<img src={DownloadIcon} alt="download" />
														</IconButton>
														<IconButton disableFocusRipple disableRipple>
															<img src={DeleteIcon} alt="delete" />
														</IconButton>
													</div>
												</TableCell>
											</TableRow>
										);
									})}
								</TableBody>
							</Table>
						</TableContainer>
						<div>
							<Typography variant="body1" className="input-title">
								Provider Notes
							</Typography>
							<TextField
								id="description"
								label="Provider Notes"
								multiline
								maxRows={1}
								value={providerNotes}
								onChange={(e) => {
									setProviderNotes(e.target.value);
								}}
								className="textarea"
								inputProps={{
									style: {
										minHeight: "80px",
										overflow: "auto",
									},
								}}
								fullWidth
							/>
						</div>
						<div className="request-btn-group">
							<Button variant="contained" onClick={handleOnClickSave}>
								Save
							</Button>
							<Button variant="outlined" onClick={handleOnClickBackCancel}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
		</>
	);
};

export default ConcludeCare;
