import React from "react";
import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import { ArrowBack, CalendarDarkIcon, LocationIcon } from "assests/images";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { createRequestSchema } from "utility/validations";
import { ICreateRequest } from "utility/interfaces";
import { DesktopDatePicker } from "@mui/x-date-pickers";
import { AppRoutings } from "utility/enums/app-routings";
import { getTabStatusWiseName } from "utility/helpers";

function datepickerIcon() {
	return <img src={CalendarDarkIcon} alt="calendar" />;
}

const CreateRequest: React.FC = () => {
	// get state value
	const { state } = window.history;
	// useStates
	const [formValues, setFormValues] = React.useState<ICreateRequest>({
		firstName: "",
		lastName: "",
		phoneNumber: "",
		email: "",
		dateOfBirth: undefined,
		street: "",
		city: "",
		state: "",
		zipCode: "",
		room: "",
		physicianNote: "",
		adminNote: "",
	});

	// Page level variables
	const navigate = useNavigate();

	// Handled events and functions
	const handleOnclickSave = () => {
		console.log("Click", formValues);
	};
	const handleOnChangeFormValue = (e: any, value: any) => {
		setFormValues({ ...formValues, [e.target.name]: value });
	};
	const handleOnChangeDateOfBirth = (value: any) => {
		setFormValues({ ...formValues, dateOfBirth: value });
	};
	const handleOnClickBackCancel = () =>
		navigate(
			AppRoutings.Dashboard.replace(
				":tabStatus",
				getTabStatusWiseName(
					state?.usr?.searchCriteria?.RequestStatusId
				).toLocaleLowerCase()
			),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);

	// Yup resolver
	const {
		register,
		handleSubmit,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(createRequestSchema),
	});

	return (
		<Box>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Submit Information</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<Typography variant="h4">Patient</Typography>
						<div>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										error={errors?.firstName?.message ? true : false}
										{...register("firstName")}
										fullWidth
										id="first-name"
										label="First Name"
										variant="outlined"
										name="firstName"
										value={formValues.firstName}
										helperText={errors?.firstName?.message?.toString()}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										error={errors?.lastName?.message ? true : false}
										{...register("lastName")}
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
										name="lastName"
										value={formValues.lastName}
										helperText={errors?.lastName?.message?.toString()}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										error={errors?.phoneNumber?.message ? true : false}
										fullWidth
										id="ph-num"
										{...register("phoneNumber")}
										label="Phone Number"
										variant="outlined"
										name="phoneNumber"
										value={formValues.phoneNumber}
										helperText={errors?.phoneNumber?.message?.toString()}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										{...register("email")}
										fullWidth
										id="email"
										label="Email"
										variant="outlined"
										name="email"
										value={formValues.email}
										helperText={errors?.email?.message?.toString()}
										error={errors?.email?.message ? true : false}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<LocalizationProvider dateAdapter={AdapterDayjs}>
										<DesktopDatePicker
											label={
												<React.Fragment>
													Date of Birth&nbsp;<span>&#40;Optional&#41;</span>
												</React.Fragment>
											}
											value={formValues?.dateOfBirth || null}
											onChange={(newValue) => {
												handleOnChangeDateOfBirth(newValue);
											}}
											components={{
												OpenPickerIcon: datepickerIcon,
											}}
											renderInput={(params) => (
												<TextField
													error={false}
													{...params}
													fullWidth
													id="dob"
													className="with-icon"
													autoComplete="off"
													inputProps={{
														...params.inputProps,
													}}
												/>
											)}
										/>
									</LocalizationProvider>
								</Grid>
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Location</Typography>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										{...register("street")}
										fullWidth
										id="street"
										label="Street"
										variant="outlined"
										name="street"
										value={formValues.street}
										helperText={errors?.street?.message?.toString()}
										error={errors?.street?.message ? true : false}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										{...register("city")}
										fullWidth
										id="city"
										label="City"
										variant="outlined"
										helperText={errors?.city?.message?.toString()}
										error={errors?.city?.message ? true : false}
										name="city"
										value={formValues.city}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										{...register("state")}
										id="state"
										label="State"
										variant="outlined"
										name="state"
										value={formValues.state}
										helperText={errors?.state?.message?.toString()}
										error={errors?.state?.message ? true : false}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="zipcode"
										label={
											<React.Fragment>
												Zip Code&nbsp;<span>&#40;Optional&#41;</span>
											</React.Fragment>
										}
										value={formValues.zipCode}
										variant="outlined"
										name="zipCode"
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="first-name"
										label={
											<React.Fragment>
												Room #&nbsp;<span>&#40;Optional&#41;</span>
											</React.Fragment>
										}
										name="room"
										value={formValues.room}
										onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
										variant="outlined"
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<div className="verify-btn-group">
										<Button variant="outlined">Verify</Button>
										<Button variant="outlined">
											<img src={LocationIcon} alt="location" />
											Map
										</Button>
									</div>
								</Grid>
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Notes</Typography>
							<TextField
								inputProps={{
									style: { minHeight: "80px" },
								}}
								id="physican-notes"
								label={
									<React.Fragment>
										Physician Notes&nbsp;<span>&#40;Optional&#41;</span>
									</React.Fragment>
								}
								multiline
								rows={2}
								fullWidth
								value={formValues.physicianNote}
								name="physicianNote"
								onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
							/>
							<TextField
								inputProps={{
									style: { minHeight: "80px" },
								}}
								id="physican-notes"
								label={
									<React.Fragment>
										Admin Notes&nbsp;<span>&#40;Optional&#41;</span>
									</React.Fragment>
								}
								multiline
								rows={2}
								value={formValues.adminNote}
								fullWidth
								name="adminNote"
								onChange={(e) => handleOnChangeFormValue(e, e.target.value)}
							/>
						</div>
						<div className="request-btn-group">
							<Button
								onClick={handleSubmit(handleOnclickSave)}
								variant="contained"
							>
								Save
							</Button>
							<Button variant="outlined" onClick={handleOnClickBackCancel}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
		</Box>
	);
};

export default CreateRequest;
