import React, { useContext, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
	Box,
	Button,
	Divider,
	FormControl,
	Grid,
	IconButton,
	InputAdornment,
	InputLabel,
	OutlinedInput,
	TextField,
	Tooltip,
	Typography,
} from "@mui/material";
import {
	ArrowBack,
	CalendarDarkIcon,
	CallIconPrimary,
	LocationIcon,
	SmartphoneIcon,
} from "assests/images";
import { AppRoutings } from "utility/enums/app-routings";
import { IViewCaseInfo } from "utility/interfaces";
import dashboardService from "services/dashboard-service";
import { SuccessErrorModalDispatchContext } from "contexts/success-error-context";
import { getTabStatusWiseName, createCommonAPICall } from "utility/helpers";
import { CustomDatePicker, AssignTransferCaseModal } from "components";

function datePickerIcon() {
	return (
		<>
			<img src={CalendarDarkIcon} alt="calendar" />
		</>
	);
}
const ViewCase: React.FC = () => {
	// get query parameters
	const caseId = useParams()?.caseId || "";

	//Page level local variable
	const setSuccessErrorContext = useContext(SuccessErrorModalDispatchContext);

	// get state value
	const { state } = window.history;

	// useStates
	const [assignCaseModalOpen, setAssignCaseModalOpen] = React.useState(false);
	const [viewCasePageInfo, setViewCasePageInfo] =
		React.useState<IViewCaseInfo | null>({
			requestId: 0,
			requestTypeId: 0,
			physicianId: 0,
			regionId: 0,
			queryString: "",
			requestTypeName: "",
			firstName: "",
			lastName: "",
			phoneNumber: "",
			email: "",
			dateOfBirth: "",
			physicianName: "",
			confirmationNumber: "",
			patientNotes: "",
			regionName: "",
			address: "",
			roomNumber: "",
			requesterName: "",
			requesterPhoneNumber: "",
		});

	// Handled events and functions
	const handleAssignCaseModalOpen = () => setAssignCaseModalOpen(true);
	const assignCaseModalClose = () => setAssignCaseModalOpen(false);
	const handleOnClickBackCancel = () =>
		navigate(
			state?.usr?.backURL ||
				AppRoutings.Dashboard.replace(
					":tabStatus",
					getTabStatusWiseName(
						state?.usr?.searchCriteria?.RequestStatusId
					).toLocaleLowerCase()
				),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);

	const getCaseDetails = async () => {
		const data = await createCommonAPICall({
			requestBody: { requestId: caseId },
			apiService: dashboardService.getViewCaseInfo,
			showSuccessMessage: false,
			showErrorMessage: true,
			setSuccessErrorContext,
		});
		if (data && data.data) setViewCasePageInfo(data.data);
	};

	// Page level variables
	const navigate = useNavigate();

	// useEffects
	useEffect(() => {
		if (caseId) getCaseDetails();
	}, []);

	return (
		<Box>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">
							New Request <span>Patient</span>
						</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div>
							<Typography variant="h4">Patient Information</Typography>
							<div className="confirm-number">
								<label>Confirmation Number</label>
								<Typography variant="h4">
									{viewCasePageInfo?.confirmationNumber}
								</Typography>
							</div>
							<TextField
								id="patient-notes"
								label="Patient Notes"
								value={viewCasePageInfo?.patientNotes || ""}
								multiline
								inputProps={{
									style: { minHeight: "80px" },
								}}
								fullWidth
								disabled
							/>
						</div>
						<Divider />
						<div>
							<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="first-name"
										label="First Name"
										variant="outlined"
										value={viewCasePageInfo?.firstName || ""}
										disabled
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="last-name"
										label="Last Name"
										variant="outlined"
										value={viewCasePageInfo?.lastName || ""}
										disabled
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<CustomDatePicker
										disabled={true}
										label="Date of Birth"
										name=""
										onChange={undefined}
										value={viewCasePageInfo?.dateOfBirth || ""}
									/>
								</Grid>
								<Grid item xs={12} sm={6}>
									<div className="input-with-button">
										<FormControl variant="outlined" fullWidth>
											<InputLabel htmlFor="phone-num">Phone Number</InputLabel>
											<OutlinedInput
												id="phone-num"
												type="tel"
												value={viewCasePageInfo?.phoneNumber || ""}
												disabled
												fullWidth
												className="with-icon"
												endAdornment={
													<InputAdornment position="end">
														<IconButton
															edge="end"
															disableFocusRipple
															disableRipple
														>
															<img src={SmartphoneIcon} alt="phone" />
														</IconButton>
													</InputAdornment>
												}
												label="phone-num"
											/>
										</FormControl>
										<IconButton href={`tel: ${viewCasePageInfo?.phoneNumber}`}>
											<Tooltip title="Call">
												<img src={CallIconPrimary} alt="call" />
											</Tooltip>
										</IconButton>
									</div>
								</Grid>
								<Grid item xs={12} sm={6}>
									<TextField
										fullWidth
										id="email"
										label="Email"
										variant="outlined"
										value={viewCasePageInfo?.email || ""}
										disabled
									/>
								</Grid>
								{/* <Grid item xs={12} sm={6}>
                                    {edit ? (
                                        <div className="verify-btn-group">
                                            <Button
                                                variant="contained"
                                                onClick={(e) => setEdit(false)}
                                            >
                                                Save
                                        </Button>
                                            <Button
                                                variant="outlined"
                                                onClick={(e) => setEdit(false)}
                                            >
                                                Cancel
                                        </Button>
                                        </div>
                                    ) : (
                                            <div className="verify-btn-group">
                                                <Button variant="outlined" onClick={(e) => setEdit(true)}>
                                                    Edit
                                        </Button>
                                            </div>
                                        )}
                                </Grid> */}
							</Grid>
						</div>
						<div>
							<Typography variant="h4">Location Information</Typography>
							<div>
								<Grid container columnSpacing={{ sm: 2, lg: 3 }}>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="region"
											label="Region"
											variant="outlined"
											value={viewCasePageInfo?.regionName || ""}
											disabled
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<div className="input-with-button">
											<TextField
												fullWidth
												id="business-add"
												label="Business Name/Address"
												variant="outlined"
												value={viewCasePageInfo?.address || ""}
												disabled
											/>
											<IconButton>
												<img src={LocationIcon} alt="location" />
											</IconButton>
										</div>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="room"
											label="Room #"
											variant="outlined"
											disabled
											value={viewCasePageInfo?.roomNumber || ""}
										/>
									</Grid>
								</Grid>
							</div>
						</div>
						<div className="request-btn-group">
							<Button variant="contained" onClick={handleAssignCaseModalOpen}>
								<Tooltip title="Assign">
									<>Assign</>
								</Tooltip>
							</Button>
							<Button
								variant="contained"
								onClick={() => {
									navigate(
										AppRoutings.ViewNotes.replace(
											":caseId",
											viewCasePageInfo?.queryString || ""
										),
										{
											state: {
												backURL: AppRoutings.ViewCase.replace(
													":caseId",
													viewCasePageInfo?.queryString || ""
												),
												searchCriteria: state?.usr?.searchCriteria,
											},
										}
									);
								}}
							>
								<Tooltip title="View Notes">
									<>View Notes</>
								</Tooltip>
							</Button>
							<Button variant="outlined" onClick={handleOnClickBackCancel}>
								<Tooltip title="Cancel">
									<>Cancel</>
								</Tooltip>
							</Button>
						</div>
					</Box>
				</Box>
			</main>
			<AssignTransferCaseModal
				assignTransferCaseModalClose={assignCaseModalClose}
				assignTransferCaseModalOpen={assignCaseModalOpen}
				isTransfer={false}
				queryString={viewCasePageInfo?.queryString || ""}
				requestId={viewCasePageInfo?.requestId || 0}
			/>
		</Box>
	);
};

export default ViewCase;
