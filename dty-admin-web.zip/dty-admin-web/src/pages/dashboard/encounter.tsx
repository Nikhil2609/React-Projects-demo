import React, { useEffect } from "react";
import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import { ArrowBack } from "assests/images";
import { useNavigate, useParams } from "react-router-dom";
import { AppRoutings } from "utility/enums/app-routings";
import { IEncounter } from "utility/interfaces";
import { getTabStatusWiseName } from "utility/helpers";
import { CustomDatePicker, CustomTimePicker } from "components";

const Encounter: React.FC = () => {
	// Page level variables
	const navigate = useNavigate();

	// get query parameters
	const { caseId } = useParams();

	// get state value
	const { state } = window.history;

	// useStates
	const [formValues, setFormValues] = React.useState<IEncounter>({
		firstName: "",
		lastName: "",
		dateOfBirth: "",
		location: "",
		date: "",
		time: "",
		phoneNumber: "",
		email: "",
		historyOfPresentIllnessOrInjury: "",
		medicalHistory: "",
		allergies: "",
		medications: "",
		temp: "",
		hr: "",
		rr: "",
		bp1: "",
		bp2: "",
		o2: "",
		pain: "",
		heent: "",
		cv: "",
		chest: "",
		abd: "",
		extr: "",
		skin: "",
		neuro: "",
		other: "",
		diagnosis: "",
		treatmentPlan: "",
		medicationsDispensed: "",
		procedures: "",
		followup: "",
		totalTime: "",
		cardNumber: "",
		exp: "",
		securityCode: "",
		zip: "",
		providerSignature: "",
		signDate: "",
		providerName: "",
		npiNumber: "",
	});

	// Handled events and functions
	const handleOnChangeFormValue = (name: string, value: any) => {
		setFormValues({ ...formValues, [name]: value });
	};
	const getEncounterDetails = () => {
		console.log(caseId);
	};
	const handleOnClickBackCancel = () =>
		navigate(
			AppRoutings.Dashboard.replace(
				":tabStatus",
				getTabStatusWiseName(
					state?.usr?.searchCriteria?.RequestStatusId
				).toLocaleLowerCase()
			),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);

	// useEffects
	useEffect(() => {
		if (caseId) getEncounterDetails();
	}, []);

	return (
		<>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Encounter Form</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<Box className="request-box">
						<div>
							<Typography className="total-cost">
								Medical Report-Confidential
							</Typography>
							<div style={{ marginTop: 20 }}>
								<Grid container columnSpacing={{ xs: 2, lg: 3 }}>
									<Grid item xs={12} sm={6}>
										<TextField
											autoFocus
											fullWidth
											id="first-name"
											label="First Name"
											variant="outlined"
											name="firstName"
											value={formValues.firstName}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="last-name"
											label="Last Name"
											variant="outlined"
											name="lastName"
											value={formValues.lastName}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<CustomDatePicker
											value={formValues.dateOfBirth}
											label="Date Of Birth"
											onChange={handleOnChangeFormValue}
											name="dateOfBirth"
											disabled={false}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="location"
											label="Location"
											variant="outlined"
											name="location"
											value={formValues.location}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<CustomDatePicker
											value={formValues.date}
											label="Date"
											onChange={handleOnChangeFormValue}
											name="date"
											disabled={false}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										{/* <TextField
											fullWidth
											id="time"
											label="Time"
											variant="outlined"
											name="time"
											value={formValues.time}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/> */}
										<CustomTimePicker
											value={formValues.time}
											label="Time"
											onChange={handleOnChangeFormValue}
											name="time"
											disabled={false}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="phoneNumber"
											label="Phone Number"
											variant="outlined"
											type="number"
											name="phoneNumber"
											value={formValues.phoneNumber}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="email"
											label="Email"
											variant="outlined"
											name="email"
											value={formValues.email}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
								</Grid>
								<Grid container columnSpacing={{ xs: 2, lg: 3 }}>
									<Grid item xs={12} sm={6}>
										<TextField
											inputProps={{
												style: { minHeight: "50px" },
											}}
											fullWidth
											multiline
											rows={1}
											id="present-illness"
											label="History Of Present Illness Or Injury"
											variant="outlined"
											name="historyOfPresentIllnessOrInjury"
											value={formValues.historyOfPresentIllnessOrInjury}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											inputProps={{
												style: { minHeight: "50px" },
											}}
											fullWidth
											multiline
											rows={1}
											id="medical-history"
											label="Medical History"
											variant="outlined"
											name="medicalHistory"
											value={formValues.medicalHistory}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											inputProps={{
												style: { minHeight: "50px" },
											}}
											fullWidth
											multiline
											rows={1}
											id="medication"
											label="Medications"
											variant="outlined"
											name="medications"
											value={formValues.medications}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											inputProps={{
												style: { minHeight: "50px" },
											}}
											fullWidth
											multiline
											rows={1}
											id="allergies"
											label="Allergies"
											variant="outlined"
											name="allergies"
											value={formValues.allergies}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
								</Grid>
								<Grid container columnSpacing={{ xs: 2, lg: 3 }}>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="temp"
											label="Temp"
											variant="outlined"
											name="temp"
											value={formValues.temp}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="hr"
											label="HR"
											variant="outlined"
											name="hr"
											value={formValues.hr}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="rr"
											label="RR"
											variant="outlined"
											name="rr"
											value={formValues.rr}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="bp1"
											label="Blood Pressure"
											variant="outlined"
											name="bp1"
											value={formValues.bp1}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="o2"
											label="O2"
											variant="outlined"
											name="o2"
											value={formValues.o2}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="pain"
											label="Pain"
											variant="outlined"
											name="pain"
											value={formValues.pain}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="heent"
											label="Heent"
											variant="outlined"
											name="heent"
											value={formValues.heent}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="cv"
											label="CV"
											variant="outlined"
											name="cv"
											value={formValues.cv}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="chest"
											label="Chest"
											variant="outlined"
											name="chest"
											value={formValues.chest}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="abd"
											label="ABD"
											variant="outlined"
											name="abd"
											value={formValues.abd}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="extr"
											label="Extr"
											variant="outlined"
											name="extr"
											value={formValues.extr}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="skin"
											label="Skin"
											variant="outlined"
											name="skin"
											value={formValues.skin}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="neuro"
											label="Neuro"
											variant="outlined"
											name="neuro"
											value={formValues.neuro}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="other"
											label="Other"
											variant="outlined"
											name="other"
											value={formValues.other}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="diagnosis"
											label="Diagnosis"
											variant="outlined"
											name="diagnosis"
											value={formValues.diagnosis}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="treatmentPlan"
											label="Treatment Plan"
											variant="outlined"
											name="treatmentPlan"
											value={formValues.treatmentPlan}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="medicationsDispensed"
											label="Medications Dispensed"
											variant="outlined"
											name="medicationsDispensed"
											value={formValues.medicationsDispensed}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="procedures"
											label="Procedures"
											variant="outlined"
											name="procedures"
											value={formValues.procedures}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={12}>
										<TextField
											fullWidth
											multiline
											inputProps={{
												style: { minHeight: "50px" },
											}}
											rows={1}
											id="followup"
											label="Followup"
											variant="outlined"
											name="followup"
											value={formValues.followup}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
								</Grid>
								<Grid container columnSpacing={{ xs: 2, lg: 3 }}>
									<Grid item xs={12} sm={5}>
										<TextField
											fullWidth
											id="cardNumber"
											label="Card Number"
											variant="outlined"
											name="cardNumber"
											value={formValues.cardNumber}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={4}>
										<TextField
											fullWidth
											id="exp"
											label="Expiry"
											variant="outlined"
											name="exp"
											value={formValues.exp}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={3}>
										<TextField
											fullWidth
											id="security Code"
											label="SecurityCode"
											variant="outlined"
											name="securityCode"
											value={formValues.securityCode}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={3}>
										<TextField
											fullWidth
											id="totalTime"
											label="Total Time"
											variant="outlined"
											name="totalTime"
											value={formValues.totalTime}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={3}>
										<TextField
											fullWidth
											id="zip"
											label="Zip"
											variant="outlined"
											name="zip"
											value={formValues.zip}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={3}>
										<TextField
											fullWidth
											id="providerSignature"
											label="providerSignature"
											variant="outlined"
											name="providerSignature"
											value={formValues.providerSignature}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={6} sm={3}>
										<TextField
											fullWidth
											id="signDate"
											label="Date"
											variant="outlined"
											name="signDate"
											value={formValues.signDate}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="providerName"
											label="Provider Name"
											variant="outlined"
											name="providerName"
											value={formValues.providerName}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											id="npiNumber"
											label="Npi Number"
											variant="outlined"
											name="npiNumber"
											value={formValues.npiNumber}
											onChange={(e) =>
												handleOnChangeFormValue(e.target.name, e.target.value)
											}
										/>
									</Grid>
								</Grid>
							</div>
						</div>
						<div className="request-btn-group">
							<Button variant="contained">Save Changes</Button>
							<Button variant="outlined" onClick={handleOnClickBackCancel}>
								Cancel
							</Button>
						</div>
					</Box>
				</Box>
			</main>
		</>
	);
};

export default Encounter;
