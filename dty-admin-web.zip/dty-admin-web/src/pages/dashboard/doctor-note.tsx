import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Box, Button, Typography } from "@mui/material";
import { ArrowBack } from "assests/images";
import { DoctorNoteForm } from "components";
import { IDoctorNote } from "utility/interfaces";
import { AppRoutings } from "utility/enums/app-routings";
import { getTabStatusWiseName } from "utility/helpers";

const DoctorNote: React.FC = () => {
	// get query parameters
	const { caseId } = useParams();

	// get state value
	const { state } = window.history;

	// page level interfaces
	interface TabPanelProps {
		children?: React.ReactNode;
		index: number;
		value: number;
	}

	// Page level variables
	const navigate = useNavigate();

	// useStates
	const [formValues, setFormValues] = useState<IDoctorNote>({
		firstName: "",
		lastName: "",
		dateOfBirth: "",
		dateOfExamination: "",
		mayResume: 0,
		travel: false,
		flight: false,
		school: false,
		work: false,
		sports: false,
		other: "",
		onDate: "",
		improveDayAfter: 0,
		restriction: "",
	});

	// Handled events and functions
	const handleOnClickBackCancel = () =>
		navigate(
			AppRoutings.Dashboard.replace(
				":tabStatus",
				getTabStatusWiseName(
					state?.usr?.searchCriteria?.RequestStatusId
				).toLocaleLowerCase()
			),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);

	const handleFormValueChange = (name: string, value: any) => {
		setFormValues({ ...formValues, [name]: value });
	};

	return (
		<Box>
			<main className="main-content">
				<div
					className="overlay"
					onClick={(e) => document.body.classList.toggle("sidebar-toggle")}
				></div>
				<Box className="request-container-box">
					<div className="request-header">
						<Typography variant="h2">Physician Recommendations</Typography>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							<img src={ArrowBack} alt="arrow" />
							Back
						</Button>
					</div>
					<DoctorNoteForm
						handleFormValueChange={handleFormValueChange}
						formValues={formValues}
					/>
					<div className="request-btn-group orders-btn-group">
						<Button variant="contained" href="/designer-dashboard">
							Save
						</Button>
						<Button variant="outlined" onClick={handleOnClickBackCancel}>
							Cancel
						</Button>
					</div>
				</Box>
			</main>
		</Box>
	);
};
export default DoctorNote;
