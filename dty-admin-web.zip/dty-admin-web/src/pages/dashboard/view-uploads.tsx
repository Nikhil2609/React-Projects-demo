import React, { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getTabStatusWiseName } from "utility/helpers";
import { AppRoutings } from "utility/enums/app-routings";
import { IDocumentInfo } from "utility/interfaces";
import { ViewDocuments } from "components";

const ViewUploads: React.FC = () => {
	// get query parameters
	const { caseId } = useParams();

	// get state value
	const { state } = window.history;

	// useStates
	// TODO: Dynamic
	const [documentList, setDocumentList] = React.useState<IDocumentInfo[]>([
		{
			id: 1,
			name: "document 1",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2006-10-02",
		},
		{
			id: 2,
			name: "document 2",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2005-10-02",
		},
		{
			id: 3,
			name: "document 3",
			type: "pdf",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2004-10-02",
		},
		{
			id: 4,
			name: "document 4",
			type: "image",
			url: "https://www.africau.edu/images/default/sample.pdf",
			uploadDate: "2010-10-02",
		},
	]);

	// Handled events and functions
	const handleOnClickBackCancel = () =>
		navigate(
			AppRoutings.Dashboard.replace(
				":tabStatus",
				getTabStatusWiseName(
					state?.usr?.searchCriteria?.RequestStatusId
				).toLocaleLowerCase()
			),
			{
				state: {
					searchCriteria: state?.usr?.searchCriteria,
				},
			}
		);

	const getUploadDetails = () => {
		// TODO API call here
		console.log(caseId);
	};

	// Page level variables
	const navigate = useNavigate();

	// useEffects
	useEffect(() => {
		if (caseId) getUploadDetails();
	}, []);

	return (
		<>
			<ViewDocuments
				documentList={documentList}
				handleOnClickBackCancel={handleOnClickBackCancel}
			/>
		</>
	);
};

export default ViewUploads;
