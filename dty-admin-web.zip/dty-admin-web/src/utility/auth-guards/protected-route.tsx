import { MenuContext, MenuDispatchContext } from "contexts/menu-context";
import React, { useContext, useEffect } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { AppRoutings } from "utility/enums/app-routings";
import { IMenu, IMenuPermissions } from "utility/interfaces";
import tokenManager from "./token-manager";

type ComponentProps = {
	element: any;
	menuKey: string | undefined;
};

export const ProtectedRoute = (props: ComponentProps) => {
	// Extract Props
	const { element, menuKey } = props;
	const sessionToken = tokenManager.getToken();
	const menuDetails: IMenu = useContext(MenuContext);
	const setMenuContext = useContext(MenuDispatchContext);
	const menuPermissions: IMenuPermissions[] = menuDetails.menus || [];

	const checkPathHaveAccess = () => {
		const permission =
			menuPermissions.filter((menu) => menu.MenuKey === menuKey).length > 0
				? true
				: false;
		return permission;
	};

	useEffect(() => {
		if (menuKey !== "")
			setMenuContext({
				...menuDetails,
				selectedMenuKey: menuKey,
			});
	}, [element]);

	return sessionToken ? (
		<>
			{checkPathHaveAccess() && menuKey ? (
				element || <Outlet />
			) : (
				<Navigate to={AppRoutings.AccessDenied} />
			)}
		</>
	) : (
		<Navigate to={AppRoutings.Root} />
	);
};
