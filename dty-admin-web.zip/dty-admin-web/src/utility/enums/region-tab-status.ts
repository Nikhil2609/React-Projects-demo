export enum RegionInformationTabStatus {
	Unassigned = 1,
	Working = 2,
	FollowUp = 3,
	Closed = 4,
}
