export enum AppRoutings {
	// Account
	Root = "/",
	ResetPassword = "/account/reset-password",
	NotFound = "/*",
	AccessDenied = "/access-denied",
	SSOLogin = "/sso-login",

	// Dashboard
	DesignerDashboard = "/designer-dashboard",
	CreateRequest1 = "/designer-dashboard/create-request",
	Dashboard = "/dashboard/:tabStatus",
	CreateRequest = "/dashboard/request",
	ViewNotes = "/dashboard/view-notes/:caseId",
	ViewCase = "/dashboard/view-case/:caseId",
	ViewUploads = "/dashboard/view-uploads/:caseId",
	Orders = "/dashboard/order/:caseId",
	DoctorsNote = "/dashboard/doctor-note/:caseId",
	ConcludeCare = "/dashboard/conclude-care/:caseId",
	CloseCase = "/dashboard/close-case/:caseId",
	ItemizedCosts = "/dashboard/close-case/itemized-costs/:caseId",
	Encounter = "/dashboard/encounter/:caseId",

	// Profile
	Region = "/profile/regions/:tabStatus",
	MyProfile = "/profile/my-profile",
	Chats = "/profile/chants",

	// Provider
	Role = "/provider/role",
	CreateRole = "/provider/role/create",
	UpdateRole = "/provider/role/update/:roleId",
	ProviderInfo = "/provider/info",

	// Profession
	Vendors = "/profession/vendors",
	AddBusiness = "/profession/vendors/add",
	UpdateBusiness = "/profession/vendors/update/:businessId",
	ProfessionInfo = "/profession/info",

	// History
	HistoryInfo = "/history/info",
	PatientRecord = "/history/patient/:patientId",
	HistoryRequestData = "/history/request-data",
	CancelHistory = "/history/cancel",
	PatientHistory = "/history/patient",
}
