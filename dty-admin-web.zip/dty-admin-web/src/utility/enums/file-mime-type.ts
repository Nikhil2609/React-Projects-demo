export enum FileMimeTypes {
	pdf = "pdf",
	txt = "txt",
	image = "img",
}
