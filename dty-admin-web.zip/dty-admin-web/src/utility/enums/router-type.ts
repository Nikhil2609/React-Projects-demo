export enum RouterType {
	protectedRoute = 1,
	unprotectedRoute = 2,
	both = 3,
}
