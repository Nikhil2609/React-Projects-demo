export enum Constants {
	// Values -------
	DefaultTablePageSize = 20,
	AppTokenKey = "app_token",
	UserDetails = "user_details",
	MenuPermissions = "menu_permissions",
	DtySecretKey = "dty_secret",
	LocalAppEncryptkey = "123456789",
}
