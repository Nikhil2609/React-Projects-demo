export enum SortOrder {
	ascending = "asc",
	descending = "desc",
}
