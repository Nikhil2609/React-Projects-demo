export interface IProfessionInfo {
	status: string;
	professionName: string;
	professionId?: number;
}
export interface IProfessions {
	professions: IProfessionInfo[];
	totalRecords: number;
}
