export interface IProviderInfo {
	providers: IProvider[];
	totalRecords: number;
}

export interface IProvider {
	queryString: string;
	providerId: string;
	providerName: string;
	role: string;
	onCallStatus: string;
	isNotificationStoped: boolean;
}
