export interface IContactProvider {
	communicationBy: string;
	message: string;
}
