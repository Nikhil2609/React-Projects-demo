export interface IRoleInfo {
	roles: IRole[];
	totalRecords: number;
}

export interface IRole {
	roleId: number;
	queryString: string;
	name: string;
	accountTypeName: string;
}
