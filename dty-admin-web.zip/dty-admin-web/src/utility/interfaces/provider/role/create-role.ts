import { IDropDownList } from "utility/interfaces";
export interface IRoleDetails {
	role: ICreateRoleRole;
	accountTypes: IAccountType[];
	menus: ICreateRoleMenu[];
}
export interface ICreateRoleRole {
	name: string;
	roleId: number;
}

export interface IAccountType {
	value: number;
	text: string;
	isSelected: boolean;
}

export interface ICreateRole {
	roleId: number;
	name: string;
	accountType: number;
	roleMenus: ICreateRoleMenu[];
	accountTypes: IDropDownList[];
}

export interface ICreateRoleMenu {
	menuId: number;
	name: string;
	isChecked: boolean;
	accountType: number;
}

export interface ICreatUpdateRoleRequest {
	roleId?: number;
	name: string;
	accountType: number;
	roleMenuIds: string;
}
