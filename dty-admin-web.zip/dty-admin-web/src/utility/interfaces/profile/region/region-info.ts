export interface IRegionInfo {
	requestCounts: IRegionRequestCount;
	requests: IRegionRequest[] | undefined;
	gridButtons: IRegionGridButtons;
	gridColumns: IRegionGridColumns;
	totalRecords: number;
}

export interface IRegionRequestCount {
	unAssignedCount: number;
	followupCount: number;
	workingCount: number;
	closeCount: number;
}

export interface IRegionRequest {
	queryString: string;
	requestId: string;
	waitTime: string;
	clientMember: string;
	business: string;
	address: string;
	requestStatus: string;
	requestStatusId: number;
	physicianId: number;
	physicianName: string;
	regionId: number;
	phoneNumber: string;
	regionName: string;
}

export interface IRegionGridButtons {
	isEdit: boolean;
	isCall: boolean;
	isHouseCall: boolean;
	isFollowup: boolean;
	isCloseCase: boolean;
}

export interface IRegionGridColumns {
	isDisplayWaitTime: boolean;
	isDisplayClientMember: boolean;
	isDisplayBusiness: boolean;
	isDisplayAddress: boolean;
	isDisplayRequestStatus: boolean;
	isDisplayPhysician: boolean;
	isDisplayRegion: boolean;
}
