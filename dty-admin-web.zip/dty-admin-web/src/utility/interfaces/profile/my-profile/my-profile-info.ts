export interface IMyProfileInfo {
	userName: string;
	password: string;
	status: number | null;
	role: number | null;

	firstName: string;
	lastName: string;
	email: string;
	confirmEmail: string;
	mobileNumber: string;
	districtOfColumbia: boolean;
	newYork: boolean;
	virginia: boolean;
	maryland: boolean;

	city: string;
	state: number | null;
	zip: string;
	alternativePhone: string;
	address1: string;
	address2: string;
}
