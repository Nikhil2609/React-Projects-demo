export interface ILoginResponse {
	dtySecret: string;
	accessToken: string;
	tokenType: string;
	email: string;
	firstName: string;
	isOnCall: boolean;
	lastName: string;
	photo: string;
	regionId: number;
	regionName: string;
	signature: string;
	encUserName: string;
	userRoleId: number;
	menuPermission: string;
}
