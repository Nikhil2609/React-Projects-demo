export interface IUserDetails {
	email: string;
	firstName: string;
	isOnCall: boolean;
	lastName: string;
	photo: string;
	regionId: number;
	regionName: string;
	signature: string;
	encUserName: string;
	userRoleId: number;
	menuPermissions: string;
}
export interface IMenuPermissions {
	Id: number;
	ParentId: number | undefined;
	Title: string;
	URL: string | undefined | null;
	MenuKey: string;
}
export interface IMenu {
	selectedMenuKey: string;
	menus: IMenuPermissions[];
}
