export interface IPatientHistory {
	history: IHistoryData[] | undefined;
	totalRecords: number;
}

export interface IHistoryData {
	id: number;
	queryString: string;
	firstName: string;
	lastName: string;
	email: string;
	phoneNumber: string;
	address: string;
}
