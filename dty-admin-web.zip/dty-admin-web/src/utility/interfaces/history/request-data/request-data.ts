import { IDropDownList } from "utility/interfaces";

export interface IHistoryRequestData {
	requests: IHistoryRequest[] | undefined;
	totalRecords: number;
}

export interface IHistoryRequest {
	id: number;
	queryString: string;
	patientName: string;
	requestor: string;
	dateOfService: string;
	email: string;
	caseCloseDate: string;
	providerName: string;
	confirmation: string;
	zipCode: string;
	phoneNumber: string;
	transactionId: string;
	status: string;
	address: string;
	transactionStatus: string;
	requestStatus: string;
	providerNote: string;
	cancelledByproviderNote: string;
	adminNote: string;
	patientNote: string;
}

export interface IRequestDataSearchFields {
	requestPaymentStatus: IDropDownList[];
	requestType: IDropDownList[];
}
