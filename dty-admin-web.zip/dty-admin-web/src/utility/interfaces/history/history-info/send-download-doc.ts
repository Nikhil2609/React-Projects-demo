export interface ISendMail {
	email: string;
	isSelectEncounter: boolean;
	isSelectInsurance: boolean;
}

export interface IDownload {
	isSelectEncounter: boolean;
	isSelectInsurance: boolean;
}
