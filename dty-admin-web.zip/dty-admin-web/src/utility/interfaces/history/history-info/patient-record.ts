export interface IPatientRecord {
	history: IPatientRecordHistory[];
	totalRecords: number;
}

export interface IPatientRecordHistory {
	queryString: string;
	client: string;
	createdDate: string;
	conformation: string;
	providerName: string;
	concludedDate: string;
	status: string;
}
