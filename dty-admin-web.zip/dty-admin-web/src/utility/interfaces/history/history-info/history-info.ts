import { IDropDownList } from "utility/interfaces";

export interface IHistoryInfo {
	histories: IHistory[] | undefined;
	totalRecords: number;
}

export interface IHistory {
	id: number;
	queryString: string;
	patientName: string;
	phoneNumber: string;
	email: string;
	dateOfService: string;
	caseCloseDate: string;
	requestor: string;
	provider: string;
	confirmation: string;
	zipCode: string;
	transactionId: string;
	status: string;
}

export interface IHistorySearchFields {
	requestPaymentStatus: IDropDownList[];
	requestType: IDropDownList[];
}
