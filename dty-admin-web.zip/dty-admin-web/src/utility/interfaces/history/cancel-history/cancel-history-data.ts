export interface ICancelHistoryList {
	histories: ICancelHistory[] | undefined;
	totalRecords: number;
}

export interface ICancelHistory {
	id: number;
	queryString: string;
	patientName: string;
	phoneNumber: string;
	email: string;
	modifiedDate: string;
	cancelledByAdminNote: string;
	cancelledByPhysicianNote: string;
}
