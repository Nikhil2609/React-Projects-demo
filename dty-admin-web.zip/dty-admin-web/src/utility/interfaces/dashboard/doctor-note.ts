export interface IDoctorNote {
	firstName: string;
	lastName: string;
	dateOfBirth: string;
	dateOfExamination: string;
	mayResume: number;
	travel: boolean;
	flight: boolean;
	school: boolean;
	work: boolean;
	sports: boolean;
	other: string;
	onDate: string;
	improveDayAfter: number;
	restriction: string;
}
