export interface IViewCaseInfo {
	requestId: number;
	requestTypeId: number;
	physicianId: number;
	regionId: number;
	queryString: string;
	requestTypeName: string;
	firstName: string;
	lastName: string;
	phoneNumber: string;
	email: string;
	dateOfBirth: string;
	physicianName: string;
	confirmationNumber: string;
	patientNotes: string;
	regionName: string;
	address: string;
	roomNumber: string;
	requesterName: string;
	requesterPhoneNumber: string;
}
