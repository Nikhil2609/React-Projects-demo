export interface IItemizedCost {
	houseCallCost: number;
	travelCost: number;
	weekendCost: number;
	afterHoursCost: number;
	holidayCost: number;
	medicationCost: number;
	suppliesCost: number;
	proceduresCost: number;
	diagnosticsCost: number;
	otherCost: number;
	houseCallDescription: string;
	travelDescription: string;
	weekendDescription: string;
	afterHoursDescription: string;
	holidayDescription: string;
	medicationDescription: string;
	suppliesDescription: string;
	proceduresDescription: string;
	diagnosticsDescription: string;
	otherDescription: string;
}
