import { IDropDownList } from "../common/drop-down-list";

export interface ICancelCaseInfo {
	requestId: number;
	fullName: string;
	selectedCaseTags: string;
	notes: string;
	physicianNotes: string;
	adminCaseTags: IDropDownList[];
}

export interface ICancelCaseRequest {
	requestId: string;
	reasonsForCancellationIds: string;
	additionalNotes: string;
}
