export interface ICreateRequest {
	firstName: string;
	lastName: string;
	phoneNumber: string;
	email: string;
	dateOfBirth: string | undefined;
	street: string;
	city: string;
	state: string;
	zipCode: string;
	room: string;
	physicianNote: string;
	adminNote: string;
}
