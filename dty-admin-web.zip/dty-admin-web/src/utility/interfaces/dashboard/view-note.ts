export interface IViewNoteInfo {
	queryString: string;
	requestId: number;
	patientNotes: string;
	physicianNotes: string;
	adminNotes: string;
	transferNotes: string;
	notes: string;
	adminSelectedCancellationNotes: string;
	physicianSelectedCancellationNotes: string;
	patientSelectedCancellationNotes: string;
}
