export interface IDocumentInfo {
	id: number;
	name: string;
	url: string;
	type: string;
	uploadDate: string;
}
