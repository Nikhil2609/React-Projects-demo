export interface IDashboardInfo {
	requestCounts: IRequestCount;
	requests: IRequest[] | undefined;
	gridButtons: IGridButtons;
	gridColumns: IGridColumns;
	totalRecords: number;
}

export interface IRequestCount {
	name: string;
	urgentCount: number;
	unAssignedCount: number;
	newCount: number;
	workingCount: number;
	pendingCount: number;
	declinedCount: number;
	reservedCount: number;
	closeCount: number;
	followupCount: number;
	concludeCount: number;
	physicianDashboardStatus: string;
	page: string;
}

export interface IRequest {
	queryString: string;
	requestId: number;
	regionId: number;
	regionName: string;
	name: string;
	waitTime: string;
	waitTimeMobile: string;
	requestedDate: string;
	phone: string;
	phoneText: string;
	address: string;
	requestStatusId: number;
	requestStatus: string;
	patientChatCount: string;
	physicianChatCount: string;
	adminChatCount: string;
	physicianId: number;
	physicianName: string;
	requestor: string;
	requestorEmail: string;
	requestorPhone: string;
	requestorPhoneText: string;
	declineBy: string;
	requestTypeId: number;
	requestType: string;
	email: string;
	dateOfBirth: string;
	acceptedDate: string;
	isTransactionDeclined: string;
}

export interface IGridButtons {
	isViewCase: boolean;
	isViewNotes: boolean;
	isCancelCase: boolean;
	isAssignCase: boolean;
	isBlockCase: boolean;
	isViewUploads: boolean;
	isOrders: boolean;
	isClear: boolean;
	isTransfer: boolean;
	isSendAgreement: boolean;
	isEncounter: boolean;
	isDoctorNotes: boolean;
	isCloseCase: boolean;
	isReCharge: boolean;
	isSettleOffline: boolean;
	isCoseReceipt: boolean;
	isInsuranceForm: boolean;
	isConcludeCare: boolean;
}

export interface IGridColumns {
	isDisplayWaitTime: boolean;
	isDisplayRequestedDate: boolean;
	isDisplayName: boolean;
	isDisplayDateOfBirth: boolean;
	isDisplayRequestorName: boolean;
	isDisplayPhone: boolean;
	isDisplayAddress: boolean;
	isDisplayRegion: boolean;
	isDisplayEmail: boolean;
	isDisplayPhysicianName: boolean;
	isDisplayAcceptedDate: boolean;
	isDisplayRequestStatus: boolean;
	isDisplayModifiedDate: boolean;
	isDisplayChatWithPatient: boolean;
	isDisplayChatWithPhysician: boolean;
	isDisplayChatWithAdmin: boolean;
}
