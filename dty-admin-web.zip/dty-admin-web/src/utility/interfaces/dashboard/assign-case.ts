import {
	IDropDownList,
	IDropDownListWithParent,
} from "../common/drop-down-list";

export interface IAssignCaseInfo {
	regionList: IDropDownList[];
	physicianList: IDropDownListWithParent[];
	description: string;
}
export interface IAssignCaseRequest {
	requestId: string;
	physicianId: number;
	description: string;
}
