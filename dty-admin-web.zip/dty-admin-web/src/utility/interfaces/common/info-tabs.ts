export interface IInformationTab {
	id: number;
	type: number;
	defaultIcon: any;
	activeIcon: any;
	title: string;
	class: string;
	count: number;
}
