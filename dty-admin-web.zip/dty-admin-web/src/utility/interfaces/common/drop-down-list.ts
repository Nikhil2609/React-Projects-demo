export interface IDropDownList {
	value: number;
	text: string;
	isSelected?: boolean;
}

export interface IDropDownListWithParent extends IDropDownList {
	parentId: number;
}
