export interface IChatBoxInfo {
	senderId: number;
	senderName: string;
	receiverId: number;
	receiverName: string;
	isMinimized: boolean;
}
