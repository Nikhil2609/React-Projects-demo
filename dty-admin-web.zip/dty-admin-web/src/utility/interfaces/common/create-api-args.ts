export interface ICreateCommonAPIArgs {
	requestBody?: any;
	apiService: any;
	showSuccessMessage?: boolean;
	showErrorMessage?: boolean;
	setSuccessErrorContext?: any;
	successMessage?: string;
	errorMessage?: string;
	isHideLoader?: boolean;
}
