export interface IHttpsResponse<T> {
	isSuccessfull: boolean;
	dtyStatusCode: number;
	statusMessage: string;
	message: string;
	data: T;
	doCacheResult: false;
}
