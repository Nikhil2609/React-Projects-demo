export interface ISearchCriteria {
	PageIndexId: number;
	PageSize: number;
	SortOrder: "asc" | "desc";
	SortBy: string;
	SearchBy: string;
}

export interface IDashboardSearchCriteria extends ISearchCriteria {
	RequestStatusId: number;
	RequestTypeId: number;
}
export interface IRegionSearchCriteria extends ISearchCriteria {
	RequestStatusId: number;
	RegionId: number;
}
export interface IProviderInfoSearchCriteria extends ISearchCriteria {
	RegionId: number;
}
export interface IHistoryInfoSearchCriteria extends ISearchCriteria {
	paymentStatus: number;
	name: string;
	date: string;
	requestType: number;
	providerName: string;
	email: string;
	phoneNumber: string;
}
export interface IRequestDataSearchCriteria extends ISearchCriteria {
	paymentStatus: number;
	patientName: string;
	requestType: number;
	fromDateOfService: string;
	toDateOfService: string;
	email: string;
	phoneNumber: string;
	providerName: string;
}
export interface ICancelHistorySearchCriteria extends ISearchCriteria {
	name: string;
	date: string;
	email: string;
	phoneNumber: string;
}
export interface IPatientHistorySearchCriteria extends ISearchCriteria {
	firstName: string;
	lastName: string;
	email: string;
	phoneNumber: string;
}
