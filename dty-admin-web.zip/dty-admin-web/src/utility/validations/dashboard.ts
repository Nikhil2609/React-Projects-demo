import * as yup from "yup";
import { phoneNumberRegExp } from "utility/helpers";

export const createRequestSchema = yup.object().shape({
	firstName: yup.string().required("First name is required."),
	lastName: yup.string().required("Last name is required."),
	street: yup.string().required("Street is required."),
	city: yup.string().required("City is required."),
	state: yup.string().required("State is required."),
	phoneNumber: yup
		.string()
		.matches(phoneNumberRegExp, "Phone number is not valid")
		.required("Phone number is required."),
	email: yup
		.string()
		.email("Please provide a valid email address")
		.required("Email address is required"),
});

export const sendLinkSchema = yup.object().shape({
	firstName: yup.string().required("First name is required."),
	lastName: yup.string().required("Last name is required."),
	phoneNumber: yup
		.string()
		.required("Phone number is required.")
		.matches(phoneNumberRegExp, "Phone number is not valid"),
	email: yup
		.string()
		.email("Email is not valid.")
		.required("Email is required."),
});

export const sendEmailSchema = yup.object().shape({
	message: yup.string().required("Message is required."),
});

export const blockRequestSchema = yup.object().shape({
	reason: yup.string().required("Reason is required."),
});

export const assignCaseSchema = yup.object().shape({
	physician: yup.string().required("Please select physician"),
	description: yup.string().required("Description is required."),
});

export const cancelCaseSchema = yup.object().shape({
	reasons: yup
		.array()
		.required("Please select at least one reason.")
		.nullable(),
	note: yup.string().required("Note is required."),
});

export const sendOrderSchema = yup.object().shape({
	business: yup.string().required("Please select business type."),
	prescription: yup.string().required("Prescription is required."),
	email: yup.string().email("Email is not valid."),
});

export const closeCaseSchema = yup.object().shape({
	updatedPhoneNumber: yup
		.string()
		.required("Phone number is required.")
		.matches(phoneNumberRegExp, "Phone number is not valid"),
	updatedEmail: yup
		.string()
		.email("Email is not valid.")
		.required("Email is required."),
});
export const sendAgreementSchema = yup.object().shape({
	phoneNumber: yup
		.string()
		.required("Phone number is required.")
		.matches(phoneNumberRegExp, "Phone number is not valid"),
	email: yup
		.string()
		.email("Email is not valid.")
		.required("Email is required."),
});
