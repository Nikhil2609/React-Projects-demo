import * as yup from "yup";

export const requestDTYSupportSchema = yup.object().shape({
	message: yup.string().required("Message is required."),
});
