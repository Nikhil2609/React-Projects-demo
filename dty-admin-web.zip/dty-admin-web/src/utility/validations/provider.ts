import * as yup from "yup";

export const cresteRoleSchema = yup.object().shape({
	name: yup.string().required("Role name is required."),
	accountType: yup.string().required("Please select account type"),
});

export const contactProviderSchema = yup.object().shape({
	message: yup.string().required("Message is required."),
});
